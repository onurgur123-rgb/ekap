# -*- coding: utf-8 -*-
"""Sartname Okuma Modulu.

Tek giris noktasi:  analiz_et(pdf_yollari) -> list[Sartname]

Modul arayuze bagimli DEGILDIR; her alt modul kendi basina test edilebilir.
    ortam.py        binary / dil paketi kontrolu
    cikarim.py      B2, B3  metin cikarma, yon ve sira duzeltme
    kurallar.py     C1-C8   regex'ler ve celiski motoru
    model.py        E1      veri modeli
    karsilastir.py  D       diff
    rapor.py        E2      Excel / JSON / ham metin
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from . import cikarim, karsilastir, kurallar, model, ortam, rapor
from .model import Sartname

__all__ = ["analiz_et", "onbellek_temizle", "ortam", "model", "cikarim",
           "kurallar", "karsilastir", "rapor", "Sartname"]

# Analiz sonuclari dosya SHA-256'sina gore onbelleklenir: ayni PDF ikinci
# kez analiz edilmez (Spesifikasyon ASAMA 6).
ONBELLEK_SURUM = 3        # kural degisince artir, eski onbellek gecersiz olur


def _onbellek_klasoru(kok: Path | None = None) -> Path:
    kok = Path(kok) if kok else Path(__file__).resolve().parent.parent
    yol = kok / "sartname_onbellek"
    yol.mkdir(exist_ok=True)
    return yol


def _onbellekten(hash_: str, klasor: Path) -> Sartname | None:
    dosya = klasor / f"{hash_}_{ONBELLEK_SURUM}.json"
    if not dosya.exists():
        return None
    try:
        veri = json.loads(dosya.read_text(encoding="utf-8"))
    except Exception:
        return None
    return _sozlukten(veri)


def _onbellege(sn: Sartname, klasor: Path) -> None:
    dosya = klasor / f"{sn.dosya_hash}_{ONBELLEK_SURUM}.json"
    try:
        veri = sn.sozluk()
        veri["ham_metin"] = sn.ham_metin
        dosya.write_text(json.dumps(veri, ensure_ascii=False),
                         encoding="utf-8")
    except Exception:
        pass


def _sozlukten(veri: dict) -> Sartname:
    """JSON sozlugunu Sartname nesnesine geri cevirir."""
    from dataclasses import fields, is_dataclass

    def cevir(tur, deger):
        if is_dataclass(tur) and isinstance(deger, dict):
            return tur(**{f.name: deger.get(f.name) for f in fields(tur)})
        return deger

    sn = Sartname(dosya_adi=veri.get("dosya_adi", ""))
    for alan in fields(Sartname):
        if alan.name not in veri:
            continue
        deger = veri[alan.name]
        if alan.name == "sayfalar":
            deger = [model.Sayfa(**d) for d in deger]
        elif alan.name == "maddeler":
            deger = [model.Madde(**d) for d in deger]
        elif alan.name == "cihazlar":
            deger = [model.Cihaz(**d) for d in deger]
        elif alan.name == "ek_kalemler":
            deger = [model.EkKalem(**d) for d in deger]
        elif alan.name == "belgeler":
            deger = [model.Belge(**d) for d in deger]
        elif alan.name == "uyarilar":
            deger = [model.Uyari(**d) for d in deger]
        elif alan.name == "kapsam":
            deger = model.Kapsam(**deger) if isinstance(deger, dict) else deger
        elif alan.name == "standartlar":
            deger = {k: [model.Isabet(**i) for i in v]
                     for k, v in (deger or {}).items()}
        elif alan.name == "sorumluluk":
            deger = {k: [model.Isabet(**i) for i in v]
                     for k, v in (deger or {}).items()}
        setattr(sn, alan.name, deger)
    return sn


def analiz_et(pdf_yollari, ilerleme=None, onbellek: bool = True,
              onbellek_klasoru: Path | None = None) -> list[Sartname]:
    """Bir veya birden cok sartname PDF'ini analiz eder.

    ilerleme(dosya_adi, sayfa, toplam_sayfa, dosya_sirasi, dosya_sayisi)
    seklinde cagrilir; arayuz ilerleme cubugunu buradan besler.

    OrtamHatasi: Turkce OCR dil paketi yoksa (taranmis belge okunacaksa)
    analiz HIC baslatilmaz - sessizce yanlis sonuc uretmektense durur.
    """
    if isinstance(pdf_yollari, (str, Path)):
        pdf_yollari = [pdf_yollari]
    yollar = [Path(y) for y in pdf_yollari]
    if not yollar:
        return []

    ortam.dogrula(ocr_gerekli=True)
    klasor = _onbellek_klasoru(onbellek_klasoru)
    sonuclar: list[Sartname] = []

    for sira, yol in enumerate(yollar, start=1):
        hash_ = cikarim.dosya_hash(yol)
        if onbellek:
            eski = _onbellekten(hash_, klasor)
            if eski is not None:
                eski.dosya_adi = yol.name
                if ilerleme:
                    ilerleme(yol.name, 1, 1, sira, len(yollar))
                sonuclar.append(eski)
                continue

        def sayfa_ilerleme(n, toplam, _yol=yol, _sira=sira):
            if ilerleme:
                ilerleme(_yol.name, n, toplam, _sira, len(yollar))

        t0 = time.time()
        sn = cikarim.metin_cikar(yol, ilerleme=sayfa_ilerleme)
        kurallar.uygula(sn)
        sn.kurum = _kurum_bul(sn)
        sn.sure_sn = round(time.time() - t0, 1)
        if onbellek:
            _onbellege(sn, klasor)
        sonuclar.append(sn)
    return sonuclar


# Ilk sayfadaki kurum adi: "... HASTANESI / BAKANLIGI / BASKANLIGI ..." satiri
_KURUM_ANAHTAR = ("HASTANE", "BAKANLI", "BAŞKANLI", "BASKANLI", "ÜNİVERSİTE",
                  "UNIVERSITE", "MÜDÜRLÜ", "MUDURLU", "BELEDİYE", "BELEDIYE")


def _kurum_bul(sn: Sartname) -> str | None:
    if not sn.sayfalar:
        return None
    for satir in sn.sayfalar[0].metin.split("\n")[:25]:
        temiz = satir.strip()
        if 6 < len(temiz) < 120 and any(a in temiz.upper()
                                        for a in _KURUM_ANAHTAR):
            return temiz
    return None


def onbellek_temizle(onbellek_klasoru: Path | None = None) -> int:
    """Onbellegi siler; kural degisikliginden sonra yeniden analiz icin."""
    klasor = _onbellek_klasoru(onbellek_klasoru)
    n = 0
    for dosya in klasor.glob("*.json"):
        try:
            dosya.unlink()
            n += 1
        except OSError:
            pass
    return n
