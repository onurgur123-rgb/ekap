# -*- coding: utf-8 -*-
"""Ortam kontrolu: gerekli kutuphaneler, Tesseract ve Turkce dil paketi.

Spesifikasyon B2/F5 geregi Turkce dil paketi YOKSA analiz BASLATILMAZ.
Sebep olculdu: -l eng ile Turkce sartname "cihaz türü" yerine "cihaz tiirii"
uretiyor; butun anahtar kelime aramalari bos donuyor ve modul yanlislikla
"hukum yok" diyor. Sessiz yanlis sonuc, hatadan kotudur.

Bu projede poppler komut satiri araclari (pdfinfo/pdftoppm/pdfimages/
pdffonts) KURULU DEGIL; hepsinin isi PyMuPDF ile yapiliyor:
    pdfinfo   -> doc.page_count, doc.metadata["producer"]
    pdffonts  -> page.get_text() uzunlugu
    pdftotext -> page.get_text("text")
    pdftoppm  -> page.get_pixmap(Matrix(z, z), colorspace=csGRAY)
    pdfimages -> page.get_images() + doc.extract_image(xref)
Boylece ek binary bagimliligi yok ve ara PNG dosyasi hic olusmadigi icin
"mukerrer sayfa okuma" hatasi (Spesifikasyon F1) yapisal olarak imkansiz.
"""
from __future__ import annotations

import shutil
from pathlib import Path

# OCR cozunurlugu. Olculen Tesseract guven skorlari (gercek EKAP taranmis
# sartnamesi): 2x + eng = 42 | 3x + tur = 68 | 4x + gri + tur = 84.
OCR_ZOOM = 4
OCR_PSM = 6              # "tek tip blok" - sartname govdesi icin en iyisi
OCR_PSM_TABLO = 6

# Sinirlar (Spesifikasyon B1)
MAX_MB = 100
MAX_SAYFA = 300

_TESS_ADAYLAR = (
    Path("C:/Program Files/Tesseract-OCR/tesseract.exe"),
    Path("C:/Program Files (x86)/Tesseract-OCR/tesseract.exe"),
    Path.home() / "AppData/Local/Programs/Tesseract-OCR/tesseract.exe",
)

_onbellek: dict = {}


class OrtamHatasi(RuntimeError):
    """Analizin baslatilamayacagi durum (or. Turkce dil paketi yok)."""


def tesseract_yolu() -> str | None:
    """Tesseract calistirilabilir dosyasini bulur; yoksa None."""
    if "tess" in _onbellek:
        return _onbellek["tess"]
    yol = "tesseract" if shutil.which("tesseract") else None
    if yol is None:
        for aday in _TESS_ADAYLAR:
            if aday.exists():
                yol = str(aday)
                break
    _onbellek["tess"] = yol
    return yol


def _pytesseract():
    import pytesseract
    yol = tesseract_yolu()
    if yol:
        pytesseract.pytesseract.tesseract_cmd = yol
    return pytesseract


def diller() -> list[str]:
    """Tesseract'in kurulu dil paketleri."""
    if "diller" in _onbellek:
        return _onbellek["diller"]
    try:
        d = list(_pytesseract().get_languages(config=""))
    except Exception:
        d = []
    _onbellek["diller"] = d
    return d


def rapor() -> dict:
    """Ortamin durumunu tek sozlukte dondurur (arayuzde gosterilebilir)."""
    d = {}
    for ad, modul in (("pymupdf", "fitz"), ("pillow", "PIL"),
                      ("pytesseract", "pytesseract"), ("openpyxl", "openpyxl")):
        try:
            __import__(modul)
            d[ad] = True
        except ImportError:
            d[ad] = False
    d["tesseract"] = tesseract_yolu()
    d["diller"] = diller()
    d["turkce"] = "tur" in d["diller"]
    d["osd"] = "osd" in d["diller"]
    return d


def dogrula(ocr_gerekli: bool = True) -> dict:
    """Analiz oncesi zorunlu kontroller. Eksik varsa OrtamHatasi firlatir."""
    d = rapor()
    eksik = []
    if not d["pymupdf"]:
        eksik.append("PyMuPDF kurulu degil:  pip install pymupdf")
    if ocr_gerekli:
        if not d["pytesseract"] or not d["pillow"]:
            eksik.append("OCR paketleri eksik:  pip install pytesseract pillow")
        elif not d["tesseract"]:
            eksik.append("Tesseract bulunamadi:  "
                         "winget install UB-Mannheim.TesseractOCR")
        elif not d["turkce"]:
            # Spesifikasyon F5: sessizce ingilizceye dusmek yasak.
            eksik.append(
                "Tesseract TURKCE dil paketi (tur.traineddata) yok. Turkce "
                "sartname ingilizce OCR ile okunursa sonuclar sessizce yanlis "
                "cikar, bu yuzden analiz baslatilmiyor. Cozum: kurulum.bat "
                "calistirin veya tur.traineddata dosyasini Tesseract-OCR/"
                "tessdata klasorune kopyalayin.")
    if eksik:
        raise OrtamHatasi("\n".join(eksik))
    return d


def excel_var() -> bool:
    try:
        import openpyxl  # noqa: F401
        return True
    except ImportError:
        return False
