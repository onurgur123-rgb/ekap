@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"

rem ===== /kontrol : hicbir sey kurmaz, sadece ne yapacagini yazar =====
set "KONTROL=0"
if /i "%~1"=="/kontrol" set "KONTROL=1"

rem ===== /sessiz : sonda tusa basmayi bekleme =====
rem EKAP_Kurulum.bat bu betigi zincirin ortasinda cagiriyor; orada
rem kullaniciya soru sorulmuyor. HATA durumundaki beklemeler yerinde
rem kalir, yoksa hata mesaji okunmadan pencere kapanir.
set "SESSIZ=0"
if /i "%~1"=="/sessiz" set "SESSIZ=1"

echo.
echo ==========================================================
echo    EKAP Izleyici - Otomatik Kurulum
echo    UNIARCH Klinik Muhendislik
echo ==========================================================
if "%KONTROL%"=="1" echo    ** KONTROL MODU - hicbir sey kurulmayacak **
echo.

rem ---------- Calisma klasoru uygun mu? ----------
rem GERCEK VAKA: ZIP e-postayla gonderilip Outlook'un ek klasorunden
rem calistirildi. O yol daha basta ~160 karakterdi:
rem   ...\AppData\Local\Microsoft\Olk\Attachments\ooa-<guid>\<guid>\...
rem Playwright'in ic dosya adlari 100+ karakter daha ekleyince Windows'un
rem 260 karakter sinirini asti ve pip "No such file or directory" ile
rem coktu. Hata mesaji da sebebi gizliyordu. Onceden yakalayalim.
set "YOL_UZUNLUK=0"
for /f %%L in ('powershell -NoProfile -Command "('%~dp0').Length" 2^>nul') do set "YOL_UZUNLUK=%%L"

set "YOL_SORUNU="
if %YOL_UZUNLUK% GTR 100 set "YOL_SORUNU=Klasor yolu cok uzun (%YOL_UZUNLUK% karakter)."
echo %~dp0 | find /i "\Olk\Attachments\" >nul && set "YOL_SORUNU=Outlook ek klasorunden calisiyor."
echo %~dp0 | find /i "\AppData\Local\Temp\" >nul && set "YOL_SORUNU=Gecici (Temp) klasorden calisiyor."
echo %~dp0 | find /i "\INetCache\" >nul && set "YOL_SORUNU=Tarayici onbellek klasorunden calisiyor."

if defined YOL_SORUNU (
    if "%KONTROL%"=="1" (
        echo [not] YOL SORUNU: %YOL_SORUNU%
        echo.
    ) else (
        echo ==========================================================
        echo    KURULUM BASLATILAMAZ
        echo ==========================================================
        echo.
        echo    %YOL_SORUNU%
        echo.
        echo    Bulundugu yer:
        echo    %~dp0
        echo.
        echo    Windows'un 260 karakterlik yol siniri yuzunden Playwright
        echo    dosyalari buraya kurulamaz; kurulum yarida kalir.
        echo.
        echo    COZUM - ikisinden biri:
        echo.
        echo    1^) "EKAP_Kurulum.bat" dosyasini calistirin. Programi
        echo       kendisi indirip "C:\EKAP Izleyici" klasorune kurar.
        echo.
        echo    2^) Bu klasoru once KISA bir yere kopyalayin
        echo       ^(orn. C:\EKAP Izleyici^), sonra kurulum.bat'i
        echo       oradan calistirin.
        echo.
        echo    ZIP dosyasini e-postadan dogrudan acip calistirmayin;
        echo    Outlook onu cok uzun adli gecici bir klasore acar.
        echo.
        pause
        exit /b 1
    )
)

rem ---------- Yonetici yetkisi ----------
net session >nul 2>&1
if errorlevel 1 (
    if "%KONTROL%"=="1" (
        echo [not] Yonetici degil - gercek kurulumda yetki istenecek.
        echo.
    ) else (
        echo Yonetici yetkisi isteniyor... ^(program kurulumlari icin gerekli^)
        powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -WorkingDirectory '%~dp0' -Verb RunAs"
        exit /b 0
    )
)

rem ---------- winget var mi? ----------
set "WG=1"
where winget >nul 2>&1 || set "WG=0"
if "%WG%"=="0" (
    echo [not] winget bulunamadi. Otomatik program kurulumu yapilamayacak.
    echo     Microsoft Store'dan "App Installer" kurarsaniz otomatik olur.
    echo.
)

rem ================= 1) PYTHON =================
echo [1/6] Python...
set "PY="
where py >nul 2>&1 && set "PY=py -3"
if not defined PY ( where python >nul 2>&1 && set "PY=python" )

if not defined PY (
    if "%KONTROL%"=="1" (
        echo    [KURULACAK] Python 3.12
    ) else (
        if "%WG%"=="1" (
            echo    Python yok, kuruluyor...
            winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements --silent
            rem PATH tazelensin diye bilinen konumlara bak
            for %%P in ("%LOCALAPPDATA%\Programs\Python\Python312\python.exe" "%ProgramFiles%\Python312\python.exe") do (
                if exist "%%~P" set "PY=%%~P"
            )
            where py >nul 2>&1 && set "PY=py -3"
        ) else (
            echo    HATA: Python yok ve winget de yok.
            echo    https://www.python.org/downloads/ adresinden kurun
            echo    ^("Add python.exe to PATH" kutusunu isaretleyin^) ve tekrar calistirin.
            pause
            exit /b 1
        )
    )
)
if defined PY (
    for /f "tokens=2" %%v in ('%PY% -V 2^>^&1') do echo    Python %%v
) else (
    if "%KONTROL%"=="0" (
        echo    HATA: Python kurulumu dogrulanamadi. Bilgisayari yeniden baslatip
        echo    bu dosyayi tekrar calistirin.
        pause
        exit /b 1
    )
)
echo.

rem ================= 2) SANAL ORTAM =================
echo [2/6] Sanal ortam ^(.venv^)...
rem Var olan sanal ortam BOZUK olabilir (yarida kalmis bir kurulumdan).
rem Gercek vakada ".venv zaten var" denip gecildi, sonra pip
rem "Cannot uninstall pip - no RECORD file" ile coktu. Sadece dosya var mi
rem diye bakmak yetmiyor; calisiyor mu diye denemek gerekiyor.
set "VENV_SAGLAM=0"
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" -c "import sys, pip" >nul 2>&1 && set "VENV_SAGLAM=1"
)

if "%VENV_SAGLAM%"=="1" (
    echo    Zaten var.
) else (
    if "%KONTROL%"=="1" (
        echo    [OLUSTURULACAK]
    ) else (
        if exist ".venv" (
            echo    Mevcut sanal ortam bozuk, yeniden olusturuluyor...
            rmdir /s /q ".venv" 2>nul
        )
        %PY% -m venv .venv || ( echo    HATA: olusturulamadi & pause & exit /b 1 )
        echo    Olusturuldu.
    )
)
echo.

rem ================= 3) PYTHON PAKETLERI =================
echo [3/6] Python paketleri...
if "%KONTROL%"=="1" (
    echo    [KURULACAK] playwright, winotify, PyMuPDF, pytesseract, pillow, openpyxl
) else (
    rem pip'i tazelemek ZORUNLU DEGIL; basarisiz olsa da kuruluma devam
    rem edilmeli. Gercek vakada "Cannot uninstall pip - no RECORD file"
    rem hatasi verdi (bozuk pip kaydi). pip'in kendi onerdigi
    rem --ignore-installed yolu bunu asiyor.
    ".venv\Scripts\python.exe" -m pip install --upgrade pip --quiet >nul 2>&1
    if errorlevel 1 (
        ".venv\Scripts\python.exe" -m pip install --ignore-installed --no-deps pip --quiet >nul 2>&1
    )

    ".venv\Scripts\python.exe" -m pip install -r requirements.txt --quiet
    if errorlevel 1 (
        echo.
        echo    HATA: paketler kurulamadi.
        echo.
        echo    En sik sebep: klasor yolu cok uzun ^(Windows 260 karakter
        echo    siniri^). Programi "C:\EKAP Izleyici" gibi kisa bir yere
        echo    kurun ya da "EKAP_Kurulum.bat" dosyasini calistirin.
        echo.
        pause
        exit /b 1
    )
    echo    Tamam.
)
echo.

rem ================= 4) TARAYICI =================
echo [4/6] Playwright tarayicisi ^(~170 MB^)...
if "%KONTROL%"=="1" (
    echo    [INDIRILECEK] Chromium
) else (
    ".venv\Scripts\python.exe" -m playwright install chromium
    if errorlevel 1 ( echo    HATA: tarayici indirilemedi & pause & exit /b 1 )
    echo    Tamam.
)
echo.

rem ================= 5) YARDIMCI PROGRAMLAR =================
echo [5/6] Yardimci programlar...

rem --- Tesseract OCR ---
set "TESS=%ProgramFiles%\Tesseract-OCR\tesseract.exe"
if exist "%TESS%" (
    echo    [VAR] Tesseract OCR
) else (
    if "%KONTROL%"=="1" (
        echo    [KURULACAK] Tesseract OCR
    ) else if "%WG%"=="1" (
        echo    Tesseract OCR kuruluyor...
        winget install -e --id UB-Mannheim.TesseractOCR --accept-source-agreements --accept-package-agreements --silent
    ) else (
        echo    [ATLANDI] winget yok - Tesseract kurulamadi
    )
)

rem --- Turkce dil paketi ---
set "TURDATA=%ProgramFiles%\Tesseract-OCR\tessdata\tur.traineddata"
if exist "%TURDATA%" (
    echo    [VAR] Tesseract Turkce dil paketi
) else (
    if "%KONTROL%"=="1" (
        echo    [INDIRILECEK] tur.traineddata ^(github.com/tesseract-ocr/tessdata^)
    ) else if exist "%ProgramFiles%\Tesseract-OCR\tessdata\" (
        echo    Turkce dil paketi indiriliyor...
        curl -L -s -o "%TURDATA%" "https://github.com/tesseract-ocr/tessdata/raw/main/tur.traineddata"
        if exist "%TURDATA%" ( echo    Tamam. ) else ( echo    [ATLANDI] indirilemedi )
    ) else (
        echo    [ATLANDI] Tesseract kurulmadigi icin dil paketi konulamadi
    )
)

rem --- Arsiv programi ---
if exist "%ProgramFiles%\WinRAR\UnRAR.exe" (
    echo    [VAR] WinRAR
) else if exist "%ProgramFiles%\7-Zip\7z.exe" (
    echo    [VAR] 7-Zip
) else (
    if "%KONTROL%"=="1" (
        echo    [KURULACAK] 7-Zip
    ) else if "%WG%"=="1" (
        echo    7-Zip kuruluyor...
        winget install -e --id 7zip.7zip --accept-source-agreements --accept-package-agreements --silent
    ) else (
        echo    [ATLANDI] winget yok - 7-Zip kurulamadi
    )
)
echo.

rem ================= 6) KISAYOL =================
echo [6/6] Masaustu kisayolu...
if "%KONTROL%"=="1" (
    echo    [OLUSTURULACAK] "EKAP Izleyici"
) else (
    powershell -NoProfile -Command ^
      "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\EKAP Izleyici.lnk');" ^
      "$s.TargetPath='%~dp0EKAP_Baslat.bat'; $s.WorkingDirectory='%~dp0';" ^
      "$s.IconLocation='%SystemRoot%\System32\shell32.dll,13'; $s.Description='EKAP Ihale ve Dogrudan Temin Izleyici'; $s.Save()" >nul 2>&1
    if exist "%USERPROFILE%\Desktop\EKAP Izleyici.lnk" ( echo    Olusturuldu. ) else ( echo    [ATLANDI] )
)
echo.

echo ==========================================================
if "%KONTROL%"=="1" (
    echo    KONTROL BITTI - hicbir sey kurulmadi
) else (
    echo    KURULUM TAMAMLANDI
)
echo ==========================================================
echo.
echo    Baslatmak icin: masaustundeki "EKAP Izleyici" kisayolu
echo                    veya EKAP_Baslat.bat
echo.
if "%SESSIZ%"=="0" pause
exit /b 0
