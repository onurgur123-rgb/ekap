@echo off
rem Eski tek dosya kurulum (EKAP_Kurulum.bat) bu betigi yonetici olarak
rem "/sessiz" ile cagirir. Artik Python kurulmaz: derlenmis .exe surumu
rem bu klasore kurulur.
call "%~dp0EKAP_Kurulum_Exe.bat" /yukseltildi /sessiz /hedef "%~dp0."
exit /b %errorlevel%
