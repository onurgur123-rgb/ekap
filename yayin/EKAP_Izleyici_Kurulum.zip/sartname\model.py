# -*- coding: utf-8 -*-
"""Sartname Okuma Modulu - veri modeli (Spesifikasyon E1).

Bu dosya SADECE veri tasir; is mantigi icermez ve arayuze bagimli degildir.
Boylece cikarim/kurallar/rapor katmanlari birbirinden bagimsiz test edilebilir.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any


# ── Uyari turleri ──────────────────────────────────────────────────────────
# Sabit olarak burada durur; kurallar.py ve rapor.py bunlari kullanir.
U_SAYFA_UYUSMAZLIGI   = "SAYFA_UYUSMAZLIGI"
U_KUNYE_UYUSMAZLIGI   = "KUNYE_UYUSMAZLIGI"
U_ATLANAN_MADDE       = "ATLANAN_MADDE"
U_YARIM_CUMLE         = "YARIM_CUMLE"
U_CELISKI             = "CELISKI"
U_TANIMSIZ_SORUMLULUK = "TANIMSIZ_SORUMLULUK"
U_OCR_DIL_PAKETI      = "OCR_DIL_PAKETI"
U_SAYFA_SIRASI        = "SAYFA_SIRASI"
U_CAPRAZ_ATIF         = "CAPRAZ_ATIF"
U_EKSIK_CIHAZ_BILGISI = "EKSIK_CIHAZ_BILGISI"
U_SINIRSIZ_KAPSAM     = "SINIRSIZ_KAPSAM"

KIRMIZI = "KIRMIZI"
SARI    = "SARI"

# Sartnamede bulunamayan bilgi icin kullanilan sabit metin. Hucre bos
# birakilmaz (Spesifikasyon E2): "bilgi yok" ile "bakilmadi" ayrilmali.
YOK = "ŞARTNAMEDE YOK"


@dataclass
class Isabet:
    """Bir regex/anahtar kelime isabetinin kaynagiyla birlikte kaydi."""
    ifade: str                      # yakalanan metin
    madde: str | None = None        # en yakin onceki madde numarasi
    sayfa: int | None = None
    baglam: str = ""                # +/- 160 karakter cevre metin


@dataclass
class Madde:
    numara: str                     # "2.2.15"
    metin: str = ""
    sayfa: int | None = None
    tam_cumle: bool = True          # noktalama ile bitiyor mu (C1)
    atiflar: list[str] = field(default_factory=list)   # icinde gecen madde no


@dataclass
class Cihaz:
    kunye: str | None = None        # 10 hane, 1 ile baslar
    marka: str | None = None
    model: str | None = None
    tip: str | None = None          # ventilator / transport ventilator ...
    sayfa: int | None = None
    eksik_alanlar: list[str] = field(default_factory=list)


@dataclass
class EkKalem:
    """Ekli MKYS / cihaz listesi satiri: kod | tanim | nitelik."""
    kod: str = ""
    tanim: str = ""
    nitelik: str = ""               # SARF | AKSESUAR | YEDEK PARÇA
    sayfa: int | None = None


@dataclass
class Kapsam:
    """KONU / ISIN TANIMI VE KAPSAMI basligindaki temel kapsam hukmu."""
    dahil_haric: str | None = None  # "dahil" | "hariç" | None
    madde: str | None = None
    ifade: str = ""
    kaynak_baslik: str = ""


@dataclass
class Belge:
    """C7: teklifle/sozlesmede istenen belge."""
    ad: str
    madde: str | None = None
    ne_zaman: str = ""              # teklif | sözleşme | iş sırasında | talep halinde
    yaptirim: str = ""
    baglam: str = ""


@dataclass
class Uyari:
    tur: str
    seviye: str                     # KIRMIZI | SARI
    mesaj: str
    madde: str | None = None
    sayfa: int | None = None
    gorsel_kirpma: str | None = None   # dogrulama icin goruntu yolu
    dogrulandi: bool = False


@dataclass
class Sayfa:
    """Tek bir PDF sayfasinin cikarim sonucu."""
    pdf_sira: int                   # PDF icindeki gercek sira (1'den)
    metin: str = ""
    damga_sira: int | None = None   # "Sayfa X / Y" damgasindaki X
    damga_toplam: int | None = None # ... Y
    dondurme: int = 0               # OSD ile bulunan aci
    yontem: str = ""                # metin | ocr | ocr-gomulu
    guven: float = 0.0              # Tesseract ortalama guven skoru


@dataclass
class Sartname:
    dosya_adi: str
    dosya_hash: str = ""            # SHA-256, onbellek anahtari
    kurum: str | None = None
    sayfa_sayisi_pdf: int = 0
    sayfa_sayisi_govde: int | None = None   # "Sayfa X / Y" damgasindan
    ek_sayfa_sayisi: int = 0
    metin_katmani: bool = False
    ocr_dili: str | None = None
    ocr_guven: float = 0.0          # tum OCR sayfalarinin ortalamasi
    producer: str = ""
    telefon_fotografi: bool = False
    ham_metin: str = ""
    sayfalar: list[Sayfa] = field(default_factory=list)
    maddeler: list[Madde] = field(default_factory=list)
    cihazlar: list[Cihaz] = field(default_factory=list)
    ek_kalemler: list[EkKalem] = field(default_factory=list)
    standartlar: dict[str, list[Isabet]] = field(default_factory=dict)
    kapsam: Kapsam = field(default_factory=Kapsam)
    sorumluluk: dict[str, list[Isabet]] = field(default_factory=dict)
    sureler: dict[str, Any] = field(default_factory=dict)
    cezalar: dict[str, Any] = field(default_factory=dict)
    belgeler: list[Belge] = field(default_factory=list)
    cevapsiz_sorular: list[dict] = field(default_factory=list)   # C8
    uyarilar: list[Uyari] = field(default_factory=list)
    sure_sn: float = 0.0

    # ── yardimcilar ───────────────────────────────────────────────────────
    def uyari_ekle(self, tur: str, seviye: str, mesaj: str,
                   madde: str | None = None, sayfa: int | None = None,
                   gorsel: str | None = None) -> Uyari:
        u = Uyari(tur=tur, seviye=seviye, mesaj=mesaj, madde=madde,
                  sayfa=sayfa, gorsel_kirpma=gorsel)
        self.uyarilar.append(u)
        return u

    @property
    def kirmizi_sayisi(self) -> int:
        return sum(1 for u in self.uyarilar if u.seviye == KIRMIZI)

    @property
    def bekleyen_uyari(self) -> int:
        return sum(1 for u in self.uyarilar if not u.dogrulandi)

    def madde_bul(self, numara: str) -> Madde | None:
        for m in self.maddeler:
            if m.numara == numara:
                return m
        return None

    def nitelik_sayimi(self) -> dict[str, int]:
        """Ek listedeki nitelik dagilimi (SARF / AKSESUAR / YEDEK PARÇA)."""
        sayac: dict[str, int] = {}
        for k in self.ek_kalemler:
            sayac[k.nitelik] = sayac.get(k.nitelik, 0) + 1
        return sayac

    def sozluk(self) -> dict:
        """JSON ciktisi icin. Ham metin ayri dosyaya yazildigi icin kisaltilir."""
        d = asdict(self)
        d["ham_metin_uzunluk"] = len(self.ham_metin)
        d.pop("ham_metin", None)
        return d
