# -*- coding: utf-8 -*-
"""Metin cikarma ve sayfa duzeltme (Spesifikasyon B1, B2, B3).

Uc yol:
  YOL 1  Metin katmani var        -> dogrudan oku (en hizli, en dogru)
  YOL 2  Taranmis (tarayici)      -> 4x gri render + Tesseract
  YOL 3  Taranmis (telefon foto)  -> GOMULU goruntuyu dogrudan al, yeniden
                                     render ETME (Spesifikasyon F6)

F1'e (mukerrer sayfa okuma) karsi koruma: bu modul diske HIC ara goruntu
yazmaz. Render sonucu bellekte kalir, glob edilecek dosya olusmaz, dolayisiyla
ayni sayfanin iki kez okunmasi mumkun degildir. Gorsel kirpma istendiginde
dosya adi sayfa numarasiyla SABITLENIR (uzerine yazilir), birikmez.
"""
from __future__ import annotations

import hashlib
import io
import re
import time
import unicodedata
from pathlib import Path

from . import ortam
from .model import Sartname, Sayfa

SAYFA_ISARETI = "<<<<< SAYFA {n} >>>>>"
_SAYFA_ISARET_RE = re.compile(r"<<<<< SAYFA (\d+) >>>>>")

# Sayfa altindaki "Sayfa 3 / 6" damgasi (Spesifikasyon B3)
DAMGA_RE = re.compile(r"Sayfa\s*(\d+)\s*/\s*(\d+)", re.IGNORECASE)

# Metin katmani var sayilmasi icin sayfa basina gereken en az karakter.
# Taranmis PDF'lerde de bazen basliktan 20-30 karakter gelir; esik bunun
# uzerinde olmali yoksa OCR hic calismaz ve sayfa bos kalir.
METIN_ESIK = 120

# Telefonla cekildigini gosteren Producer imzalari
TELEFON_IMZA = ("quartz pdfcontext", "ios", "iphone", "ipad", "scanner pro",
                "camscanner", "adobe scan")

# Gomulu goruntunun "zaten yuksek cozunurluklu" sayilmasi icin esik.
# Telefon fotografi tipik olarak 2000x3000; 300 dpi A4 render ~2480x3508.
GOMULU_ESIK_PX = 1400


# Gercekten gorunmez olan, silinmesi gereken karakterler: sifir genislikli
# birlestiriciler ve BOM. Yumusak tire (U+00AD) BU LISTEDE DEGIL -- asagiya
# bakin.
#
# NEDEN GEREKLI: gercek PDF metin katmani normal bosluk yerine kirilmaz
# bosluk (U+00A0) donduruyor. Bu modulun kendi test verisinde olculdu:
# "TS 12426" duz metin aramasi tam da bu yuzden BULUNAMIYORDU. Normalize
# edilmezse modul sessizce "hukum yok" der; bu, hata vermekten kotudur
# (F5 ile ayni sinif hata). NFKC, U+00A0'yi normal boslukla degistirir.
_GORUNMEZ = dict.fromkeys((0x200B, 0x200C, 0x200D, 0x2060, 0xFEFF), None)

# Yumusak tire (U+00AD) iki farkli anlamda gelir ve AYIRT EDILMELIDIR:
#   satir sonunda  -> heceleme artigi; kaldirilir, kelime birlestirilir
#   satir icinde   -> gorunur bir tiredir; normal "-" karakterine cevrilir
# PDF metin cikariminda gorunur "-" cok sik U+00AD olarak donuyor. Hepsini
# silmek olculebilir zarar veriyordu: "01.01.2027 - 31.12.2027" tarih
# araligi "01.01.2027  31.12.2027" olup sozlesme suresi "SARTNAMEDE YOK"
# gorundu; "EK-1", "bakim-onarim" gibi ifadeler de sessizce bozuldu.
_SATIR_SONU_TIRE = re.compile("\u00ad\n")


def temizle(metin: str) -> str:
    """Cikarilan metni normalize eder (Unicode NFKC + gorunmez karakterler)."""
    if not metin:
        return ""
    metin = unicodedata.normalize("NFKC", metin)
    metin = metin.replace("\r\n", "\n").replace("\r", "\n")
    metin = _SATIR_SONU_TIRE.sub("", metin)     # heceleme: kelimeyi birlestir
    metin = metin.replace("\u00ad", "-")        # gorunur tire
    metin = metin.translate(_GORUNMEZ)
    # Satir sonlarindaki bosluklari kirp; madde metni karsilastirmasi (diff)
    # gorunmez bosluk farkindan patlamasin.
    return "\n".join(satir.rstrip() for satir in metin.split("\n"))



def dosya_hash(yol: Path) -> str:
    h = hashlib.sha256()
    with open(yol, "rb") as f:
        for blok in iter(lambda: f.read(1 << 20), b""):
            h.update(blok)
    return h.hexdigest()


def pdf_mi(yol: Path) -> bool:
    """Uzantiya degil ILK BAYTLARA bakar (Spesifikasyon B1)."""
    try:
        with open(yol, "rb") as f:
            return f.read(5) == b"%PDF-"
    except OSError:
        return False


def _fitz():
    import fitz
    return fitz


# -- B1: giris dogrulama ---------------------------------------------------
def giris_dogrula(yol: Path) -> dict:
    """PDF'i acar ve temel bilgileri dondurur. Hatali dosyada ValueError."""
    yol = Path(yol)
    if not yol.exists():
        raise ValueError(f"Dosya yok: {yol}")
    if not pdf_mi(yol):
        raise ValueError(
            f"Bu dosya PDF degil (ilk baytlar '%PDF-' degil): {yol.name}")
    fitz = _fitz()
    try:
        doc = fitz.open(str(yol))
    except Exception as e:
        raise ValueError(f"PDF acilamadi: {yol.name} ({e})") from e

    meta = doc.metadata or {}
    producer = f"{meta.get('producer', '')} {meta.get('creator', '')}".strip()
    boyut_mb = yol.stat().st_size / (1024 * 1024)
    bilgi = {
        "doc": doc,
        "sayfa_sayisi": doc.page_count,
        "producer": producer,
        "telefon": any(im in producer.lower() for im in TELEFON_IMZA),
        "boyut_mb": round(boyut_mb, 1),
        "uyarilar": [],
    }
    if boyut_mb > ortam.MAX_MB:
        bilgi["uyarilar"].append(
            f"Dosya buyuk ({boyut_mb:.0f} MB > {ortam.MAX_MB} MB); "
            f"analiz uzun surebilir.")
    if doc.page_count > ortam.MAX_SAYFA:
        bilgi["uyarilar"].append(
            f"Sayfa sayisi yuksek ({doc.page_count} > {ortam.MAX_SAYFA}).")
    return bilgi


def metin_katmani_var(doc, ornek: int = 5) -> bool:
    """pdffonts karsiligi: ilk sayfalarda anlamli metin var mi?"""
    bakilan = min(ornek, doc.page_count)
    if bakilan == 0:
        return False
    toplam = sum(len((doc[i].get_text("text") or "").strip())
                 for i in range(bakilan))
    return (toplam / bakilan) >= METIN_ESIK


# -- B2 YOL 3: gomulu goruntu ----------------------------------------------
def _gomulu_goruntu(doc, sayfa_no: int):
    """Sayfadaki baskin gomulu goruntuyu PIL Image olarak dondurur.

    Telefon fotografinda sayfa zaten tek bir buyuk JPEG'dir; onu yeniden
    render etmek hem 3-4 kat yavas hem de kalite kazandirmaz (F6).
    """
    from PIL import Image
    try:
        gorseller = doc[sayfa_no].get_images(full=True)
    except Exception:
        return None
    if not gorseller:
        return None
    en_iyi, en_alan = None, 0
    for g in gorseller:
        try:
            bilgi = doc.extract_image(g[0])
        except Exception:
            continue
        alan = bilgi.get("width", 0) * bilgi.get("height", 0)
        if alan > en_alan:
            en_alan, en_iyi = alan, bilgi
    if not en_iyi:
        return None
    if max(en_iyi.get("width", 0), en_iyi.get("height", 0)) < GOMULU_ESIK_PX:
        return None                     # kucuk logo vb. -> render daha iyi
    try:
        return Image.open(io.BytesIO(en_iyi["image"]))
    except Exception:
        return None


def _render(doc, sayfa_no: int, zoom: int = ortam.OCR_ZOOM):
    """pdftoppm karsiligi: sayfayi BELLEKTE gri tonlamali goruntuye cevirir."""
    from PIL import Image
    fitz = _fitz()
    pix = doc[sayfa_no].get_pixmap(matrix=fitz.Matrix(zoom, zoom),
                                   colorspace=fitz.csGRAY)
    return Image.open(io.BytesIO(pix.tobytes("png")))


# -- B3: sayfa yonu --------------------------------------------------------
# OSD (yon tespiti) TEK BASINA GUVENILMEZ. Olculdu: sade, yatay bir ek liste
# sayfasi icin Tesseract "Rotate: 180" dedi; sayfa cevrilince OCR ciktisi
# tamamen bozuldu ("YEDEK PARCA" -> "VO4YVd YAAGAA") ve hicbir uyari
# uretilmedi. Bu, F5 ile ayni sinif "sessizce yanlis sonuc" hatasidir.
#
# Bu yuzden dondurme ONERI olarak alinir, sonra DOGRULANIR: hem orijinal hem
# dondurulmus goruntu OCR'lanip Tesseract'in kendi ortalama guven skoru
# karsilastirilir, yuksek olan kazanir. Maliyet sadece OSD'nin "donuk" dedigi
# nadir sayfalarda iki kat OCR'dir.
OSD_GUVEN_ESIK = 1.0      # bunun altindaki OSD onerisi hic denenmez
DUSUK_GUVEN = 60          # ortalama OCR guveni bunun altindaysa uyari


def _osd_aci(img) -> tuple[int, float]:
    """Onerilen dondurme acisi ve OSD'nin kendi guven skoru."""
    if not ortam.rapor()["osd"]:
        return 0, 0.0
    try:
        import pytesseract
        from pytesseract import Output
        pytesseract.pytesseract.tesseract_cmd = (ortam.tesseract_yolu()
                                                 or "tesseract")
        kucuk = img
        if max(img.size) > 2000:                   # OSD kucukte de yeterli
            oran = 2000 / max(img.size)
            kucuk = img.resize((max(1, int(img.width * oran)),
                                max(1, int(img.height * oran))))
        d = pytesseract.image_to_osd(kucuk, output_type=Output.DICT)
        return int(d.get("rotate", 0)) % 360, float(d.get("orientation_conf", 0))
    except Exception:
        return 0, 0.0


def _ocr_guven(img, psm: int = ortam.OCR_PSM) -> tuple[str, float]:
    """Goruntuyu OCR'lar; metni ve Tesseract'in ortalama guven skorunu doner."""
    import pytesseract
    from pytesseract import Output
    pytesseract.pytesseract.tesseract_cmd = (ortam.tesseract_yolu()
                                             or "tesseract")
    cfg = f"--psm {psm}"
    try:
        d = pytesseract.image_to_data(img, lang="tur", config=cfg,
                                      output_type=Output.DICT)
    except Exception:
        return "", 0.0
    # Metin, ikinci bir OCR cagrisi yapmadan bu ciktidan yeniden kurulur:
    # image_to_data zaten her kelimenin blok/paragraf/satir numarasini verir.
    # Ayrica image_to_string cagirmak sureyi iki katina cikariyordu (olculdu:
    # 7 sayfalik taranmis dosyada 9.3 sn -> 20.4 sn).
    satirlar: dict[tuple, list[str]] = {}
    guvenler = []
    n = len(d.get("text", []))
    for i in range(n):
        kelime = str(d["text"][i]).strip()
        try:
            g = float(d["conf"][i])
        except (TypeError, ValueError, KeyError):
            continue
        if not kelime:
            continue
        if g >= 0:
            guvenler.append(g)
        anahtar = (d["page_num"][i], d["block_num"][i],
                   d["par_num"][i], d["line_num"][i])
        satirlar.setdefault(anahtar, []).append(kelime)
    if not guvenler:
        return "", 0.0
    metin = "\n".join(" ".join(kelimeler)
                      for _, kelimeler in sorted(satirlar.items()))
    return metin, sum(guvenler) / len(guvenler)


def _ocr(img, psm: int = ortam.OCR_PSM) -> str:
    return _ocr_guven(img, psm)[0]


def sayfa_metni(doc, sayfa_no: int, telefon: bool, metinli: bool) -> Sayfa:
    """Tek sayfayi uc yoldan uygun olaniyla okur."""
    s = Sayfa(pdf_sira=sayfa_no + 1)
    ham = temizle(doc[sayfa_no].get_text("text") or "")
    if metinli and len(ham.strip()) >= METIN_ESIK:
        s.metin, s.yontem = ham, "metin"           # YOL 1
        return s

    img = _gomulu_goruntu(doc, sayfa_no) if telefon else None
    if img is not None:
        s.yontem = "ocr-gomulu"                    # YOL 3
    else:
        img = _render(doc, sayfa_no)               # YOL 2
        s.yontem = "ocr"

    aci, osd_guven = _osd_aci(img)
    metin, guven = _ocr_guven(img)
    if aci and osd_guven >= OSD_GUVEN_ESIK:
        # PIL saat yonunun tersine dondurur; OSD saat yonunde soyler.
        d_metin, d_guven = _ocr_guven(img.rotate(-aci, expand=True))
        if d_guven > guven:                  # dondurme GERCEKTEN iyilestirdi
            metin, guven, s.dondurme = d_metin, d_guven, aci
    s.metin, s.guven = temizle(metin), round(guven, 1)
    if len(s.metin.strip()) < 20 and len(ham.strip()) > len(s.metin.strip()):
        s.metin, s.yontem = ham, "metin"     # OCR bos dondu, eldekini kullan
    return s


# -- Ana giris -------------------------------------------------------------
def metin_cikar(yol: Path, ilerleme=None) -> Sartname:
    """B1-B3'u uygular ve doldurulmus (ham) Sartname nesnesi dondurur."""
    t0 = time.time()
    yol = Path(yol)
    bilgi = giris_dogrula(yol)
    doc = bilgi["doc"]

    sn = Sartname(dosya_adi=yol.name, dosya_hash=dosya_hash(yol))
    sn.sayfa_sayisi_pdf = bilgi["sayfa_sayisi"]
    sn.producer = bilgi["producer"]
    sn.telefon_fotografi = bilgi["telefon"]
    sn.metin_katmani = metin_katmani_var(doc)
    sn.ocr_dili = None if sn.metin_katmani else "tur"

    for uyari in bilgi["uyarilar"]:
        sn.uyari_ekle("GIRIS", "SARI", uyari)

    for i in range(doc.page_count):
        if ilerleme:
            ilerleme(i + 1, doc.page_count)
        try:
            sn.sayfalar.append(sayfa_metni(doc, i, sn.telefon_fotografi,
                                           sn.metin_katmani))
        except Exception as e:
            sn.sayfalar.append(Sayfa(pdf_sira=i + 1, yontem="hata"))
            sn.uyari_ekle("GIRIS", "KIRMIZI",
                          f"Sayfa {i + 1} okunamadi: {e}", sayfa=i + 1)

    # F4: pdfinfo sayisi ile okunan sayfa sayisi HER ZAMAN karsilastirilir
    if len(sn.sayfalar) != sn.sayfa_sayisi_pdf:
        raise ValueError(
            f"Sayfa sayisi uyusmuyor: PDF {sn.sayfa_sayisi_pdf}, "
            f"okunan {len(sn.sayfalar)}. Analiz guvenilir degil.")

    # OCR kalitesi dusukse sessiz kalma: kullanici "hukum yok" sanmasin.
    ocr_sayfalari = [x for x in sn.sayfalar
                     if x.yontem.startswith("ocr") and x.guven]
    if ocr_sayfalari:
        ort = sum(x.guven for x in ocr_sayfalari) / len(ocr_sayfalari)
        sn.ocr_guven = round(ort, 1)
        kotu = [x.pdf_sira for x in ocr_sayfalari if x.guven < DUSUK_GUVEN]
        if kotu:
            sn.uyari_ekle(
                "OCR_KALITE", "SARI",
                f"OCR guveni dusuk (ortalama {ort:.0f}, esik {DUSUK_GUVEN}). "
                f"Su sayfalarda metin eksik/yanlis okunmus olabilir: "
                f"{', '.join(map(str, kotu[:12]))}"
                f"{' ...' if len(kotu) > 12 else ''}. Bu sayfalardaki "
                f"bulgular gozle dogrulanmali.",
                sayfa=kotu[0])

    _damgalari_isle(sn)
    sn.ham_metin = birlestir(sn.sayfalar)
    sn.sure_sn = round(time.time() - t0, 1)
    try:
        doc.close()
    except Exception:
        pass
    return sn


def _damgalari_isle(sn: Sartname) -> None:
    """'Sayfa X / Y' damgasindan govde/ek ayrimi ve sira kontrolu (B3)."""
    for s in sn.sayfalar:
        m = DAMGA_RE.search(s.metin)
        if m:
            s.damga_sira, s.damga_toplam = int(m.group(1)), int(m.group(2))

    damgali = [s for s in sn.sayfalar if s.damga_toplam]
    if not damgali:
        return
    # En sik gorulen Y degeri govde sayfa sayisidir
    sayac: dict[int, int] = {}
    for s in damgali:
        sayac[s.damga_toplam] = sayac.get(s.damga_toplam, 0) + 1
    govde = max(sayac, key=sayac.get)
    sn.sayfa_sayisi_govde = govde
    sn.ek_sayfa_sayisi = max(0, sn.sayfa_sayisi_pdf - govde)

    # Damga sirasi PDF sirasiyla uyusuyor mu? Telefonla cekilen dosyalarda
    # ek sayfalari sirasiz cekilir; metin damgadaki siraya gore dizilmeli.
    govde_sayfalari = [s for s in damgali if s.damga_toplam == govde]
    sira = [s.damga_sira for s in govde_sayfalari]
    if sira != sorted(sira):
        sn.uyari_ekle(
            "SAYFA_SIRASI", "SARI",
            f"Sayfa damgalari sirasiz geldi ({sira}). Metin damgadaki siraya "
            f"gore yeniden dizildi; madde numaralari yine de gozle kontrol "
            f"edilmeli.")
        digerleri = [s for s in sn.sayfalar if s not in govde_sayfalari]
        govde_sayfalari.sort(key=lambda s: s.damga_sira or 0)
        sn.sayfalar = govde_sayfalari + digerleri


def birlestir(sayfalar: list[Sayfa]) -> str:
    """Sayfa isaretleriyle tek metin. Bulgular sayfaya baglanabilsin diye."""
    parcalar = []
    for s in sayfalar:
        parcalar.append(SAYFA_ISARETI.format(n=s.pdf_sira))
        parcalar.append(s.metin)
    return "\n".join(parcalar)


def sayfa_no_bul(metin: str, konum: int) -> int | None:
    """Birlestirilmis metinde verilen karakter konumunun sayfa numarasi."""
    son = None
    for m in _SAYFA_ISARET_RE.finditer(metin):
        if m.start() > konum:
            break
        son = int(m.group(1))
    return son


def gorsel_kirp(pdf_yolu: Path, sayfa_no: int, hedef_klasor: Path,
                zoom: int = 2) -> str | None:
    """Bir sayfanin goruntusunu dogrulama icin diske yazar (C4 kunye vakasi).

    Dosya adi sayfa numarasiyla SABIT; tekrar calistirilinca uzerine yazilir,
    birikmez (F1 regresyonu).
    """
    try:
        fitz = _fitz()
        hedef_klasor = Path(hedef_klasor)
        hedef_klasor.mkdir(parents=True, exist_ok=True)
        doc = fitz.open(str(pdf_yolu))
        pix = doc[sayfa_no - 1].get_pixmap(matrix=fitz.Matrix(zoom, zoom))
        hedef = hedef_klasor / f"sayfa_{sayfa_no:03d}.png"
        pix.save(str(hedef))
        doc.close()
        return str(hedef)
    except Exception:
        return None
