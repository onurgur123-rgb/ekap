@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

rem ==========================================================
rem   EKAP Izleyici - Otomatik Kurulum
rem   UNIARCH Klinik Muhendislik
rem
rem   Bu TEK dosyayi paylasmaniz yeterlidir. Cift tiklandiginda
rem   hicbir soru sormadan programi indirir, kurar, masaustune
rem   kisayol koyar ve uygulamayi acar.
rem
rem   Kullanicidan istenen TEK sey Windows'un yonetici izni
rem   penceresidir; Python ve Tesseract kurulumu icin zorunlu,
rem   atlanamaz.
rem
rem   Paket adresi asagida tanimlidir. Depo degisirse yalnizca
rem   bu satiri guncellemek yeterlidir.
rem ==========================================================

set "PAKET_ADRESI=https://raw.githubusercontent.com/onurgur123-rgb/ekap/main/yayin/EKAP_Izleyici_Kurulum.zip"

rem Kurulum klasoru artik SORULMAZ. Yol KISA olmali: Playwright'in ic
rem dosya adlari uzundur ve Windows'un 260 karakter sinirina takilabilir.
set "HEDEF=C:\EKAP Izleyici"

echo.
echo ==========================================================
echo    EKAP Izleyici - Kurulum
echo    UNIARCH Klinik Muhendislik
echo ==========================================================
echo.

rem ---------- Yonetici yetkisi: TEK seferde, EN BASTA ----------
rem Onemli: kurulum.bat yonetici degilse kendini yukseltip cikiyor.
rem O zaman bu betik kurulum daha bitmeden "tamamlandi" yaziyordu.
rem Yetkiyi en basta alirsak kurulum.bat ayni pencerede sirayla calisir.
net session >nul 2>&1
if errorlevel 1 (
    if /i "%~1"=="/yukseltildi" (
        echo  [HATA] Yonetici yetkisi alinamadi.
        echo  Dosyaya sag tiklayip "Yonetici olarak calistir" deneyin.
        echo.
        pause
        exit /b 1
    )
    echo  Yonetici izni isteniyor...
    echo  ^(Python ve Tesseract kurulumu icin gerekli^)
    echo.
    powershell -NoProfile -Command ^
      "try { Start-Process -FilePath '%~f0' -ArgumentList '/yukseltildi' -Verb RunAs; exit 0 } catch { exit 1 }"
    if errorlevel 1 (
        echo  [HATA] Izin verilmedi; kurulum yapilamaz.
        echo.
        pause
    )
    exit /b 0
)

echo  Kurulum klasoru : %HEDEF%
echo.

if not exist "%HEDEF%" (
    mkdir "%HEDEF%" 2>nul
    if errorlevel 1 (
        echo  [HATA] Klasor olusturulamadi: %HEDEF%
        echo.
        pause
        exit /b 1
    )
)

rem Klasor yonetici olarak olusturuluyor. Uygulama daha sonra NORMAL
rem kullanici olarak calisip buraya durum dosyasi yazacak; yazma izni
rem verilmezse "erisim engellendi" ile karsilasilir.
icacls "%HEDEF%" /grant "%USERNAME%":(OI)(CI)F /T >nul 2>&1

rem ---------- 1) Paketi indir ----------
set "GECICI=%TEMP%\ekap_paket_%RANDOM%.zip"
echo  [1/4] Paket indiriliyor...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "try {" ^
  "  [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;" ^
  "  Invoke-WebRequest -Uri '%PAKET_ADRESI%' -OutFile '%GECICI%' -UseBasicParsing;" ^
  "  exit 0" ^
  "} catch { Write-Host $_.Exception.Message; exit 1 }"
if errorlevel 1 (
    echo.
    echo  [HATA] Paket indirilemedi.
    echo  - Internet baglantinizi kontrol edin.
    echo  - Adresin tarayicida acilip acilmadigina bakin.
    echo.
    pause
    exit /b 1
)

rem ---------- 2) Dogrula ve ac ----------
echo  [2/4] Paket dogrulanip aciliyor...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "try {" ^
  "  Add-Type -AssemblyName System.IO.Compression.FileSystem;" ^
  "  $z=[IO.Compression.ZipFile]::OpenRead('%GECICI%');" ^
  "  $ok=$z.Entries | Where-Object { $_.Name -eq 'ekap_monitor.py' };" ^
  "  $z.Dispose();" ^
  "  if (-not $ok) { throw 'Pakette ekap_monitor.py yok - yanlis dosya indirilmis.' }" ^
  "  Expand-Archive -LiteralPath '%GECICI%' -DestinationPath '%HEDEF%' -Force;" ^
  "  exit 0" ^
  "} catch { Write-Host $_.Exception.Message; exit 1 }"
if errorlevel 1 (
    echo.
    echo  [HATA] Paket acilamadi veya gecerli bir EKAP paketi degil.
    del "%GECICI%" >nul 2>&1
    echo.
    pause
    exit /b 1
)
del "%GECICI%" >nul 2>&1

rem ZIP tek bir ust klasorle gelmis olabilir; icerigi yukari tasi.
if not exist "%HEDEF%\ekap_monitor.py" (
    for /d %%K in ("%HEDEF%\*") do (
        if exist "%%K\ekap_monitor.py" (
            robocopy "%%K" "%HEDEF%" /E /MOVE /NFL /NDL /NJH /NJS /NP >nul
        )
    )
)

if not exist "%HEDEF%\kurulum.bat" (
    echo  [HATA] kurulum.bat bulunamadi; paket eksik gorunuyor.
    echo.
    pause
    exit /b 1
)

rem ---------- 3) Python, paketler, tarayici ----------
echo  [3/4] Python, paketler ve tarayici kuruluyor...
echo        Ilk kurulumda 5-15 dakika surebilir, lutfen bekleyin.
echo.
cd /d "%HEDEF%"
call "%HEDEF%\kurulum.bat" /sessiz
set "SONUC=%errorlevel%"

if not "%SONUC%"=="0" (
    echo.
    echo  [HATA] Kurulum yarida kaldi. Yukaridaki mesaja bakin.
    echo.
    pause
    exit /b 1
)

rem Kurulumda olusan dosyalar (.venv vb.) da normal kullanici
rem tarafindan yazilabilir olmali.
icacls "%HEDEF%" /grant "%USERNAME%":(OI)(CI)F /T >nul 2>&1

rem ---------- 4) Uygulamayi ac ----------
echo  [4/4] Uygulama baslatiliyor...
rem explorer uzerinden acilir: boylece uygulama YONETICI olarak degil
rem normal kullanici olarak calisir. Yonetici olarak calisirsa urettigi
rem dosyalar sonraki normal calistirmalarda erisilemez olabilir.
start "" explorer.exe "%HEDEF%\EKAP_Baslat.bat"

echo.
echo ==========================================================
echo    KURULUM TAMAMLANDI
echo ==========================================================
echo.
echo    Klasor   : %HEDEF%
echo    Kisayol  : Masaustunde "EKAP Izleyici"
echo.
echo    Guncellemeler uygulama icinden gelir; yeni surum
echo    ciktiginda ust tarafta bir serit belirir.
echo.
echo    Bu pencere 12 saniye icinde kapanacak.
timeout /t 12 >nul
endlocal
exit /b 0
