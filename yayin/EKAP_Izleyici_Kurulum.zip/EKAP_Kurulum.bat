@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

rem ==========================================================
rem   EKAP Izleyici - Tek Dosyalik Kurulum
rem   UNIARCH Klinik Muhendislik
rem
rem   Bu TEK dosyayi paylasmaniz yeterlidir. Program paketini
rem   internetten indirir, kurar ve masaustune kisayol koyar.
rem
rem   Paket adresi asagida tanimlidir. Depo degisirse yalnizca
rem   bu satiri guncellemek yeterlidir.
rem ==========================================================

set "PAKET_ADRESI=https://raw.githubusercontent.com/onurgur123-rgb/ekap/main/EKAP_Izleyici_Kurulum.zip"

rem Varsayilan kurulum klasoru. Yol KISA olmali: Playwright'in ic dosya
rem adlari uzundur ve Windows'un 260 karakter sinirina takilabilir.
set "VARSAYILAN=C:\EKAP Izleyici"

echo.
echo ==========================================================
echo    EKAP Izleyici - Kurulum
echo    UNIARCH Klinik Muhendislik
echo ==========================================================
echo.

rem ---------- Kurulum klasoru ----------
echo  Program nereye kurulsun?
echo  Bos birakip Enter'a basarsaniz: %VARSAYILAN%
echo.
set "HEDEF="
set /p "HEDEF=Klasor: "
if "%HEDEF%"=="" set "HEDEF=%VARSAYILAN%"
rem Basta/sonda tirnak varsa temizle
set "HEDEF=%HEDEF:"=%"

echo.
echo  Kurulum klasoru : %HEDEF%
echo  Paket adresi    : %PAKET_ADRESI%
echo.

if not exist "%HEDEF%" (
    mkdir "%HEDEF%" 2>nul
    if errorlevel 1 (
        echo  [HATA] Klasor olusturulamadi: %HEDEF%
        echo  Baska bir konum deneyin ^(orn. C:\EKAP Izleyici^).
        pause
        exit /b 1
    )
)

rem ---------- Paketi indir ----------
set "GECICI=%TEMP%\ekap_paket_%RANDOM%.zip"
echo  [1/3] Paket indiriliyor...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "try {" ^
  "  [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;" ^
  "  Invoke-WebRequest -Uri '%PAKET_ADRESI%' -OutFile '%GECICI%' -UseBasicParsing;" ^
  "  exit 0" ^
  "} catch { Write-Host $_.Exception.Message; exit 1 }"
if errorlevel 1 (
    echo.
    echo  [HATA] Paket indirilemedi.
    echo  - Internet baglantinizi kontrol edin.
    echo  - Adresin tarayicida acilip acilmadigina bakin.
    echo  - Depo "private" ise "public" yapmaniz gerekir.
    pause
    exit /b 1
)

rem ---------- Paketi ac ----------
echo  [2/3] Paket aciliyor...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "try {" ^
  "  Add-Type -AssemblyName System.IO.Compression.FileSystem;" ^
  "  $z=[IO.Compression.ZipFile]::OpenRead('%GECICI%');" ^
  "  $ok=$z.Entries | Where-Object { $_.Name -eq 'ekap_monitor.py' };" ^
  "  if (-not $ok) { $z.Dispose(); throw 'Pakette ekap_monitor.py yok - yanlis dosya indirilmis.' }" ^
  "  $z.Dispose();" ^
  "  Expand-Archive -LiteralPath '%GECICI%' -DestinationPath '%HEDEF%' -Force;" ^
  "  exit 0" ^
  "} catch { Write-Host $_.Exception.Message; exit 1 }"
if errorlevel 1 (
    echo.
    echo  [HATA] Paket acilamadi veya gecerli bir EKAP paketi degil.
    del "%GECICI%" >nul 2>&1
    pause
    exit /b 1
)
del "%GECICI%" >nul 2>&1

rem GitHub ZIP'leri bazen tek bir ust klasorle gelir; icerigi yukari tasi.
if not exist "%HEDEF%\ekap_monitor.py" (
    for /d %%K in ("%HEDEF%\*") do (
        if exist "%%K\ekap_monitor.py" (
            echo  Paket ic klasorden cikariliyor...
            robocopy "%%K" "%HEDEF%" /E /MOVE /NFL /NDL /NJH /NJS /NP >nul
        )
    )
)

if not exist "%HEDEF%\kurulum.bat" (
    echo  [HATA] kurulum.bat bulunamadi. Paket eksik gorunuyor.
    pause
    exit /b 1
)

rem ---------- Kurulumu calistir ----------
echo  [3/3] Python, paketler ve tarayici kuruluyor...
echo.
echo  Bu adim ilk kurulumda 5-15 dakika surebilir.
echo  Yonetici izni isterse "Evet" deyin.
echo.
cd /d "%HEDEF%"
call "%HEDEF%\kurulum.bat"

echo.
echo ==========================================================
echo    Kurulum tamamlandi.
echo    Klasor: %HEDEF%
echo ==========================================================
echo.
echo  Bundan sonraki guncellemeler uygulama icinden gelir:
echo  yeni surum ciktiginda ust tarafta bir serit belirir ve
echo  "Simdi Guncelle" dugmesine basmaniz yeterlidir.
echo.
pause
endlocal
