# -*- coding: utf-8 -*-
"""Cikarim kurallari (Spesifikasyon C1-C8) ve celiski motoru.

Butun regex'ler bu dosyada SABIT olarak toplanir; koda gomulmez. Yeni kurum
kaliplari ciktikca sadece buradaki sozlukler genisletilir.

Temel ilke: modul YORUM YAPMAZ, veri cikarir ve tutarsizlik isaretler.
Uretilen her bulgu bir madde numarasina baglidir; kaynagi gosterilemeyen
bulgu uretilmez.
"""
from __future__ import annotations

import re

from . import cikarim
from .model import (Belge, Cihaz, EkKalem, Isabet, Kapsam, Madde, Sartname,
                    KIRMIZI, SARI, YOK,
                    U_ATLANAN_MADDE, U_CAPRAZ_ATIF, U_CELISKI,
                    U_EKSIK_CIHAZ_BILGISI, U_KUNYE_UYUSMAZLIGI,
                    U_SINIRSIZ_KAPSAM, U_TANIMSIZ_SORUMLULUK, U_YARIM_CUMLE)

BAGLAM = 160

# Cikarim katmaninin sayfa isareti; baglam metninden ayiklanir.
_SAYFA_ISARET_RE = re.compile(r"<<<<< SAYFA \d+ >>>>>")          # isabet cevresinde saklanacak karakter sayisi


# ── Turkce kucuk harf ──────────────────────────────────────────────────────
# Python'da "İ".lower() -> "i" + U+0307 birlesik isaret uretir ve eslesmeyi
# bozar. Bu yuzden Turkce'ye ozgu harfler once elle esleniyor.
_TR_ESLEME = str.maketrans("İIÇĞÖŞÜ", "iiçğöşü")


def tr_kucuk(metin: str) -> str:
    return metin.translate(_TR_ESLEME).lower()


def sadelestir(metin: str) -> str:
    """Turkce harfleri ASCII karsiligina indirger (OCR toleransi icin)."""
    return tr_kucuk(metin).translate(
        str.maketrans("çğıöşü", "cgiosu"))


# ── C1: madde envanteri ────────────────────────────────────────────────────
# Madde numarasi SADECE SATIR BASINDA aranir. Serbest arama iki tur yanlis
# pozitif uretiyordu (olculdu):
#   1) Tarihler: "01.01.2027" icindeki "01.01" madde saniliyordu.
#   2) Metin ici atiflar: "... 2.2.16 maddesi uygulanir" cumleyi ikiye
#      boluyor, oncesindeki madde yarim gorunuyor ve YARIM_CUMLE yanlis
#      tetikleniyordu (14 uyaridan 12'si bu yuzdendi).
# Gercek sartnamelerde madde numarasi daima satir basindadir; metin ici
# gecisler ATIF_RE ile ayrica toplanir.
MADDE_RE = re.compile(
    r"^[ \t]*(\d{1,2}(?:\.\d{1,3}){1,3})[\.\)]?(?=[\s:])", re.MULTILINE)
ATIF_RE = re.compile(r"\b\d{1,2}(?:\.\d{1,3}){1,3}\b")

# Bazi sartnameler duz numaralandirma kullanir: "1.", "2.", "3.". Bu kalip
# hiyerarsik olandan cok daha gevsek (her satir basindaki sayi eslesir), o
# yuzden YALNIZCA hiyerarsik numara neredeyse hic bulunamadiginda kullanilir.
DUZ_MADDE_RE = re.compile(r"^[ \t]*(\d{1,3})[\.\)](?=[ \t])", re.MULTILINE)

# Hiyerarsik numara sayisi bunun altindaysa duz numaralandirmaya dusulur.
HIYERARSIK_ESIK = 5

# Bir maddenin tamamlanmis sayilmasi icin bitmesi gereken isaretler
BITIS_ISARETLERI = (".", ":", ";", ")", "?", "!")

# Madde metninden ayiklanacaklar: sayfa isareti, "Sayfa X / Y" damgasi ve
# metnin sonuna takilan BOLUM BASLIKLARI ("2. GENEL HUKUMLER" gibi). Bunlar
# temizlenmezse madde noktalama ile bitmiyor gorunur.
_SAYFA_ISARET_TEMIZ = re.compile(r"<<<<< SAYFA \d+ >>>>>")
_DAMGA_TEMIZ = re.compile(r"Sayfa\s*\d+\s*/\s*\d+", re.IGNORECASE)
_BASLIK_SATIR = re.compile(
    r"^[ \t]*(?:\d{1,2}[\.\)]\s*)?[A-ZÇĞİÖŞÜ][A-ZÇĞİÖŞÜ0-9\s\-/\.]{3,}$")


def madde_metni_temizle(govde: str) -> str:
    """Madde govdesinden sayfa damgasi ve sondaki bolum basliklarini atar."""
    govde = _SAYFA_ISARET_TEMIZ.sub("", govde)
    govde = _DAMGA_TEMIZ.sub("", govde)
    satirlar = govde.split("\n")
    while satirlar and (not satirlar[-1].strip()
                        or _BASLIK_SATIR.match(satirlar[-1])):
        satirlar.pop()
    return "\n".join(satirlar).strip()


# ── C2: standart taramasi ──────────────────────────────────────────────────
TS_RE = re.compile(r"\bTS[\s\-]?(?:EN[\s\-]?)?(\d{4,5})", re.IGNORECASE)

# Aranip BULUNAMAYAN da raporlanir: "TS 13703 -> YOK" bilgisi "VAR" kadar
# degerlidir (Spesifikasyon C2).
SABIT_SORGULAR = ("TS 12426", "TS 13703", "ISO 13485", "ISO 9001",
                  "IEC 60601", "CE")

DIGER_STANDART_RE = {
    "ISO 13485": re.compile(r"\bISO\s*[\-]?\s*13485", re.IGNORECASE),
    "ISO 9001":  re.compile(r"\bISO\s*[\-]?\s*9001", re.IGNORECASE),
    "IEC 60601": re.compile(r"\bIEC\s*[\-]?\s*60601", re.IGNORECASE),
    "CE":        re.compile(r"\bCE\b"),
}

# Marka bazli belge sarti: rekabeti dogrudan etkiler.
MARKA_BAZLI_RE = re.compile(
    r"marka|cihaz\s*t[uü]r[uü]|cihaz\s*baz[ıi]nda|model\s*baz[ıi]nda",
    re.IGNORECASE)

# "TS 12426 veya TS 13703" ile "... ve ..." arasindaki fark rekabet acisindan
# belirleyicidir; bu yuzden baglac ayrica kaydedilir.
BAGLAC_RE = re.compile(r"\b(veya|ya\s*da|ile|ve)\b", re.IGNORECASE)


# ── C3: kapsam ve sorumluluk ───────────────────────────────────────────────
PATTERNS: dict[str, str] = {
    "kapsam_dahil_haric": r"yedek\s*par[çc]a\s*/?\s*malzeme?\s*(temini\s*)?(dahil|hari[çc])",
    "yedek_parca":        r"yedek\s*par[çc]a",
    "sarf":               r"sarf\s*malzeme",
    "aksesuar":           r"aksesuar",
    "bakim_kiti":         r"bak[ıi]m\s*kiti",
    "filtre":             r"filtre",
    "idare_karsilar":     r"[İIi]dare\s*taraf[ıi]ndan\s*(kar[şs][ıi]lanacak|tedarik|sa[ğg]lanacak)",
    "yuklenici_karsilar": r"[Yy][üu]klenici\s*taraf[ıi]ndan\s*kar[şs][ıi]lanacak",
    "ucretsiz":           r"[üu]cretsiz|bedelsiz|ilave\s*[üu]cret\s*talep\s*et",
    "teklifle_birlikte":  r"teklif(?:le|\s*mektubu)\s*(?:ile\s*)?(?:birlikte|beraber)",
    "yetkili_servis":     r"yetkili\s*servis",
    "kismi_teklif":       r"k[ıi]sm[ıi]\s*teklif",
    "alt_yuklenici":      r"alt\s*y[üu]klenici",
    "ceza":               r"binde\s*bir|%\s*\d+['`’]?\s*(?:i|si|u|unu)?\s*(?:oran[ıi]nda)?\s*ceza",
    "uptime":             r"uptime|%\s*9\d",
    "sozlesme_tarihi":    r"\d{2}\.\d{2}\.\d{4}\s*[-–]\s*\d{2}\.\d{2}\.\d{4}",
}
_DERLI = {ad: re.compile(kalip, re.IGNORECASE) for ad, kalip in PATTERNS.items()}

# KONU / ISIN TANIMI VE KAPSAMI basligi: buradaki dahil/haric sozlesmenin
# TEMEL kapsam hukmudur, govde metnindeki diger isabetlerle karistirilmaz.
# Gercek belgelerde baslik cok cesitli yaziliyor: "1. KONU", "KONU:",
# "İŞİN KONUSU", "AMAÇ VE KAPSAM", "1.1 İŞİN TANIMI VE KAPSAMI"...
# Numara zorunlu degil (uc belgede de kapsam bu yuzden bulunamamisti).
KONU_BASLIK_RE = re.compile(
    r"^[ \t]*(?:\d{1,2}(?:\.\d{1,3})*[\.\)]?[ \t]*)?"
    r"((?:[İI][ŞS][İI]N[ \t]+)?KONU(?:SU)?|AMA[ÇC]|KAPSAM|"
    r"[İI][ŞS][İI]N[ \t]+TANIMI|[İI][ŞS][İI]N[ \t]+ADI)"
    r"(?:[ \t]+VE[ \t]+(?:KAPSAM|[İI][ŞS][İI]N[ \t]+TANIMI|AMA[ÇC]))?"
    r"[ \t]*:?[ \t]*$",
    re.IGNORECASE | re.MULTILINE)
DAHIL_HARIC_RE = re.compile(r"\b(dahil|hari[çc])\b", re.IGNORECASE)


# ── C4: envanter ───────────────────────────────────────────────────────────
KUNYE_RE = re.compile(r"\b1\d{9}\b")
ADET_RE = re.compile(r"(\d+)\s*adet", re.IGNORECASE)
# "Toplam 23 adet" gibi acik bir toplam ifadesi; belgedeki rastgele
# "5 adet filtre" ifadelerinden ayirt edilmesi gerekiyor.
TOPLAM_ADET_RE = re.compile(
    r"(?:toplam|toplamda)\s*(?:olarak\s*)?(\d+)\s*adet", re.IGNORECASE)
DONEM_RE = re.compile(
    r"Bak[ıi]m\s*D[öo]nemi[\s:.\-–—]*"
    r"([A-Za-zÇĞİÖŞÜçğıöşü]+[\s\-–—]*\d{4})", re.IGNORECASE)
CIHAZ_SATIR_RE = re.compile(
    r"^(?P<marka>.*?)\s*marka\s*ve\s*model\s*,?\s*"
    r"(?P<kunye>1\d{9})\s*k[üu]nye", re.IGNORECASE | re.MULTILINE)
CIHAZ_TIPI_RE = re.compile(
    r"(transport\s+ventilat[öo]r|ventilat[öo]r|monit[öo]r|defibrilat[öo]r|"
    r"anestezi\s+cihaz[ıi]|ultrason|dializ)", re.IGNORECASE)


# ── C5: ekli liste ─────────────────────────────────────────────────────────
# KRITIK: nitelik SADECE satir sonunda sayilir. Govdedeki "7. YEDEK PARCA/SARF"
# gibi bir madde basligi basit count() ile her nitelikten 1 fazla saydiriyordu
# (olculdu: 224 yerine 227).
EK_SATIR_RE = re.compile(
    r"^(?P<govde>.*?)\b(?P<nitelik>SARF|AKSESUAR|YEDEK\s*PAR[ÇC]A)\s*$",
    re.IGNORECASE | re.MULTILINE)
EK_KOD_RE = re.compile(r"^\s*([A-Z0-9][A-Z0-9\-\./]{2,})\s+")


# ── C6: sure, ceza, taahhut ────────────────────────────────────────────────
SURE_KALIPLARI = {
    "mudahale_suresi": r"m[üu]dahale\s*s[üu]resi[^.\n]{0,60}",
    "onarim_parcasiz": r"par[çc]a\s*gerektirmeyen\s*onar[ıi]m[^.\n]{0,60}",
    "onarim_parcali":  r"par[çc]a\s*gerektiren\s*onar[ıi]m[^.\n]{0,60}",
    "garanti":         r"garanti\s*s[üu]resi[^.\n]{0,60}|\d+\s*y[ıi]l\s*garantili",
    "uptime":          r"uptime[^.\n]{0,40}|%\s*9\d[^.\n]{0,40}",
    "sozlesme_araligi": r"\d{2}\.\d{2}\.\d{4}\s*[-–]\s*\d{2}\.\d{2}\.\d{4}",
}
CEZA_KALIPLARI = {
    "ceza_orani": r"binde\s*bir[^.\n]{0,60}|%\s*\d+[^.\n]{0,30}ceza[^.\n]{0,30}",
    "ceza_tavani": r"ceza[^.\n]{0,40}(ge[çc]emez|a[şs]amaz)[^.\n]{0,30}|"
                   r"%\s*\d+[^.\n]{0,20}ge[çc]emez",
    "fesih": r"fesh?edilir|feshi[^.\n]{0,50}|s[öo]zle[şs]me\s*feshedilir",
}
_SURE_DERLI = {a: re.compile(k, re.IGNORECASE) for a, k in SURE_KALIPLARI.items()}
_CEZA_DERLI = {a: re.compile(k, re.IGNORECASE) for a, k in CEZA_KALIPLARI.items()}


# ── C7: belge talepleri ────────────────────────────────────────────────────
BELGE_TETIK_RE = re.compile(
    r"teklifle\s*birlikte|teklif\s*mektubu\s*ile|idareye\s*sunulacak|"
    r"belgelendirecek|belgesini\s*sunacak|belgesini\s*verecek|"
    r"talep\s*halinde", re.IGNORECASE)
BELGE_ADI_RE = re.compile(
    r"\b((?:TS|ISO|IEC)\s*[\-]?\s*\d{3,5}|yetkili\s*servis\s*belgesi|"
    r"CE\s*belgesi|kalibrasyon\s*belgesi|[A-ZÇĞİÖŞÜ][\wçğıöşü]*\s*belgesi)",
    re.IGNORECASE)
ZAMAN_ESLEME = (
    (r"teklifle\s*birlikte|teklif\s*mektubu", "teklif"),
    (r"s[öo]zle[şs]me\s*(imzas[ıi]|a[şs]amas[ıi]|sonras[ıi])", "sözleşme"),
    (r"talep\s*halinde", "talep halinde"),
    (r"i[şs]\s*s[ıi]ras[ıi]nda|bak[ıi]m\s*sonras[ıi]", "iş sırasında"),
)

# ── C8: cevabi BU belgede olmayan sorular ──────────────────────────────────
CEVAPSIZ_SORULAR = (
    ("Kısmi teklif verilebilir mi?", "kismi_teklif",
     "İdari şartname + ihale ilanı"),
    ("Alt yüklenici çalıştırılabilir mi?", "alt_yuklenici",
     "İdari şartname md. 18"),
    ("Yeterlik kriterleri (iş deneyimi, ciro)", None, "İdari şartname"),
    ("Yaklaşık maliyet, İKN, ihale usulü", None, "İhale ilanı / EKAP"),
)


# Tarih parcalari atif sanilmasin: "01.01.2027 - 31.12.2027" icinden
# "01.01" ve "31.12" atif olarak toplaniyordu (olculdu).
TARIH_RE = re.compile(r"\b\d{1,2}\.\d{1,2}\.\d{4}\b")


def _atiflari_bul(govde: str, kendi_numarasi: str) -> list[str]:
    tarih_araliklari = [(m.start(), m.end()) for m in TARIH_RE.finditer(govde)]
    bulunan = []
    for m in ATIF_RE.finditer(govde):
        if m.group(0) == kendi_numarasi:
            continue
        if any(b <= m.start() < s for b, s in tarih_araliklari):
            continue
        if m.group(0) not in bulunan:
            bulunan.append(m.group(0))
    return bulunan


# ══════════════════════════════════════════════════════════════════════════
# Yardimcilar
# ══════════════════════════════════════════════════════════════════════════
def _baglam(metin: str, bas: int, son: int, yaricap: int = BAGLAM) -> str:
    """Isabetin cevresindeki metni dondurur (rapor ve arayuzde gosterilir).

    Sayfa isaretleri ("<<<<< SAYFA 4 >>>>>") ic kullanim icindir; baglam
    metnine karisirsa Excel raporunda ve C8 cevaplarinda kullaniciya
    gorunur hale geliyordu. Burada temizlenir.
    """
    parca = metin[max(0, bas - yaricap): son + yaricap]
    parca = _SAYFA_ISARET_RE.sub(" ", parca)
    return " ".join(parca.split())


def _onceki_madde(metin: str, konum: int) -> str | None:
    """Verilen konumdan ONCEKI en yakin madde numarasi (bulgu -> kaynak).

    Once hiyerarsik numara aranir; belge duz numaralandirma kullaniyorsa
    (hic hiyerarsik numara yoksa) duz numaraya dusulur. Boylece duz
    numarali belgelerde de her bulgu bir maddeye baglanabilir.
    """
    son = None
    for m in MADDE_RE.finditer(metin, 0, konum + 1):
        son = m.group(1)
    if son is not None:
        return son
    for m in DUZ_MADDE_RE.finditer(metin, 0, konum + 1):
        son = m.group(1)
    return son


def _isabet(metin: str, m: re.Match) -> Isabet:
    return Isabet(ifade=m.group(0).strip(),
                  madde=_onceki_madde(metin, m.start()),
                  sayfa=cikarim.sayfa_no_bul(metin, m.start()),
                  baglam=_baglam(metin, m.start(), m.end()))


# ══════════════════════════════════════════════════════════════════════════
# C1 - Madde envanteri
# ══════════════════════════════════════════════════════════════════════════
def maddeleri_cikar(sn: Sartname) -> None:
    metin = sn.ham_metin
    bulunanlar = list(MADDE_RE.finditer(metin))
    if len(bulunanlar) < HIYERARSIK_ESIK:
        duz = list(DUZ_MADDE_RE.finditer(metin))
        if len(duz) > len(bulunanlar):
            bulunanlar = duz
            sn.uyari_ekle(
                "DUZ_NUMARALANDIRMA", SARI,
                f"Belgede hiyerarsik madde numarasi (2.2.15 gibi) "
                f"bulunamadi; duz numaralandirma (1., 2., 3.) varsayildi ve "
                f"{len(duz)} madde cikarildi. Madde atiflari bu varsayima "
                f"dayaniyor, gozle dogrulayin.")
    for i, m in enumerate(bulunanlar):
        bas = m.end()
        son = bulunanlar[i + 1].start() if i + 1 < len(bulunanlar) else len(metin)
        govde = madde_metni_temizle(metin[bas:son])
        madde = Madde(
            numara=m.group(1),
            metin=govde,
            sayfa=cikarim.sayfa_no_bul(metin, m.start()),
            tam_cumle=bool(govde) and govde.rstrip()[-1:] in BITIS_ISARETLERI,
            atiflar=_atiflari_bul(govde, m.group(1)),
        )
        sn.maddeler.append(madde)


# Atlanan madde tespiti kolayca yanlis pozitif uretir. Gercek belgelerde
# olculen sinirlar:
MIN_GRUP = 4          # bu kadar maddesi olmayan grupta bosluk anlamsiz
MAX_BOSLUK = 4        # ust uste en fazla bu kadar eksik "atlanmis" sayilir
MAX_BOSLUK_ORANI = 0.4  # grubun bu kadarindan fazlasi eksikse liste degildir
MAX_UYARI = 25        # bundan fazlasi tek toplu uyariya indirilir


def atlanan_maddeler(sn: Sartname) -> list[str]:
    """Ayni onekteki numaralarda atlanan olanlari bulur.

    ONEMLI: bu liste dogrudan rapora YAZILMAZ. OCR bir madde numarasini
    okuyamazsa yanlis pozitif uretir; her bosluk "dogrulama gerekiyor"
    isaretiyle kullaniciya gosterilir (Spesifikasyon C1/F3).

    Uc filtre, gercek belgelerde olculen gurultuyu keser:
      1) Grup en az MIN_GRUP maddeden olusmali. Iki maddelik bir grupta
         "arada bir sey eksik" demek anlamsiz.
      2) Bosluk MAX_BOSLUK'tan uzunsa atlanan madde degildir; numaralandirma
         orada zaten atliyordur (or. 2.2.5'ten sonra 2.2.40'a gecen belge).
      3) Grubun %40'indan fazlasi eksik gorunuyorsa bu bir madde listesi
         degil, OCR'in sayi sandigi baska bir seydir (tablo, olcu, tarih).
    """
    gruplar: dict[str, set[int]] = {}
    for m in sn.maddeler:
        parcalar = m.numara.split(".")
        onek, son = ".".join(parcalar[:-1]), parcalar[-1]
        if not son.isdigit():
            continue
        gruplar.setdefault(onek, set()).add(int(son))

    eksikler = []
    for onek, sayilar in gruplar.items():
        if len(sayilar) < MIN_GRUP:
            continue
        bas, son = min(sayilar), max(sayilar)
        aralik = son - bas + 1
        eksik_sayisi = aralik - len(sayilar)
        if eksik_sayisi == 0:
            continue
        if eksik_sayisi / aralik > MAX_BOSLUK_ORANI:
            continue                      # liste degil, gurultu

        # Ardisik bosluklari grupla; uzun olanlari ele
        n = bas
        while n <= son:
            if n in sayilar:
                n += 1
                continue
            bosluk = []
            while n <= son and n not in sayilar:
                bosluk.append(n)
                n += 1
            if len(bosluk) <= MAX_BOSLUK:
                eksikler.extend(f"{onek}.{k}" for k in bosluk)
    return sorted(eksikler, key=lambda s: [int(p) for p in s.split(".")])


def madde_uyarilari(sn: Sartname) -> None:
    # Atlanan madde -> DOGRULAMA KUYRUGU (yanlis pozitif olabilir).
    # Cok sayida bosluk varsa tek tek yazmak paneli kullanilamaz hale
    # getiriyor; MAX_UYARI'yi asinca tek toplu uyari uretilir.
    eksikler = atlanan_maddeler(sn)
    if len(eksikler) > MAX_UYARI:
        sn.uyari_ekle(
            U_ATLANAN_MADDE, SARI,
            f"{len(eksikler)} madde numarasi atlanmis gorunuyor "
            f"({', '.join(eksikler[:10])} …). Bu kadar cok bosluk genellikle "
            f"madde numaralarinin OCR ile eksik okunmasindan kaynaklanir; "
            f"belgeyi gozle kontrol edin."
            + (f" Belgenin OCR guveni {sn.ocr_guven:.0f}."
               if sn.ocr_guven else ""),
            madde=eksikler[0])
    else:
        for eksik in eksikler:
            onceki = sn.madde_bul(_bir_onceki(eksik, sn))
            kirpma = (onceki.metin[:200] if onceki else "")
            sn.uyari_ekle(
                U_ATLANAN_MADDE, SARI,
                f"Madde {eksik} numarasi bulunamadi. OCR okuyamamis olabilir; "
                f"belgede gozle kontrol edin. Onceki maddenin metni: "
                f"“{kirpma[:120]}…”",
                madde=eksik, sayfa=(onceki.sayfa if onceki else None))

    # Yarim cumle. Iki ayrim yapilir:
    #   KIRMIZI: metin KISA ve harfle bitiyor -> cumle gercekten kesilmis
    #            (spesifikasyondaki gercek vaka: "...bakim-onarimi sonrasi")
    #   SARI   : uzun metnin sonunda nokta yok -> genellikle OCR noktayi
    #            okuyamamistir; 71 sayfalik gercek belgede 110 tane cikti,
    #            hepsini kirmizi yapmak paneli anlamsiz kilardi.
    yarim_sari = []
    for m in sn.maddeler:
        if not m.metin or m.tam_cumle or len(m.metin) <= 15:
            continue
        son_kar = m.metin.rstrip()[-1:]
        if son_kar.isalpha() and len(m.metin) < 200:
            sn.uyari_ekle(
                U_YARIM_CUMLE, KIRMIZI,
                f"Madde {m.numara} noktalama ile bitmiyor, metin yarim kalmis "
                f"olabilir: “…{m.metin[-70:]}”",
                madde=m.numara, sayfa=m.sayfa)
        else:
            yarim_sari.append(m)

    if len(yarim_sari) > MAX_UYARI:
        sn.uyari_ekle(
            U_YARIM_CUMLE, SARI,
            f"{len(yarim_sari)} maddenin metni noktalama ile bitmiyor "
            f"({', '.join(m.numara for m in yarim_sari[:10])} …). Uzun "
            f"metinlerde bu genellikle OCR'in noktayi okuyamamasindandir, "
            f"yine de son cumleleri gozle kontrol edin.",
            madde=yarim_sari[0].numara, sayfa=yarim_sari[0].sayfa)
    else:
        for m in yarim_sari:
            sn.uyari_ekle(
                U_YARIM_CUMLE, SARI,
                f"Madde {m.numara} noktalama ile bitmiyor: "
                f"“…{m.metin[-70:]}”",
                madde=m.numara, sayfa=m.sayfa)

    # Capraz atif. Belgede BULUNMAYAN bir maddeye atif gercek bir sorundur,
    # tek tek yazilir. Var olan maddeye atif ise yalnizca "dogrulanmali"
    # notudur; 58 ayri satir yerine tek toplu uyariya indirilir.
    mevcut = {m.numara for m in sn.maddeler}
    dogrulanacak, eksik_hedef = [], []
    for m in sn.maddeler:
        for atif in m.atiflar:
            (eksik_hedef if atif not in mevcut else dogrulanacak).append(
                (m, atif))

    if len(eksik_hedef) > MAX_UYARI:
        ornek = ", ".join(f"{m.numara}→{a}" for m, a in eksik_hedef[:10])
        sn.uyari_ekle(
            U_CAPRAZ_ATIF, SARI,
            f"{len(eksik_hedef)} atif, belgede bulunmayan maddelere yapiliyor "
            f"({ornek} …). Bu kadar cok eksik hedef genellikle madde "
            f"numaralarinin OCR ile bozuk okunmasindandir; birkacini gozle "
            f"kontrol edin.",
            madde=eksik_hedef[0][0].numara, sayfa=eksik_hedef[0][0].sayfa)
    else:
        for m, atif in eksik_hedef:
            sn.uyari_ekle(
                U_CAPRAZ_ATIF, SARI,
                f"Madde {m.numara}, belgede BULUNMAYAN {atif} maddesine "
                f"atif yapiyor.", madde=m.numara, sayfa=m.sayfa)

    if len(dogrulanacak) > MAX_UYARI:
        ornek = ", ".join(f"{m.numara}→{a}" for m, a in dogrulanacak[:10])
        sn.uyari_ekle(
            U_CAPRAZ_ATIF, SARI,
            f"{len(dogrulanacak)} madde baska maddelere atif yapiyor "
            f"({ornek} …). Atif yapilan maddelerin gercekten o konuyu "
            f"duzenledigi gozle dogrulanmali.",
            madde=dogrulanacak[0][0].numara,
            sayfa=dogrulanacak[0][0].sayfa)
    else:
        for m, atif in dogrulanacak:
            hedef = sn.madde_bul(atif)
            sn.uyari_ekle(
                U_CAPRAZ_ATIF, SARI,
                f"Madde {m.numara} -> {atif} atfi: atif yapilan maddenin "
                f"bu konuyu duzenledigi dogrulanmali. {atif}: "
                f"“{(hedef.metin[:90] if hedef else '')}…”",
                madde=m.numara, sayfa=m.sayfa)


def _bir_onceki(numara: str, sn: Sartname) -> str:
    parcalar = numara.split(".")
    try:
        parcalar[-1] = str(int(parcalar[-1]) - 1)
    except ValueError:
        return numara
    return ".".join(parcalar)


# ══════════════════════════════════════════════════════════════════════════
# C2 - Standartlar
# ══════════════════════════════════════════════════════════════════════════
def standartlari_cikar(sn: Sartname) -> None:
    metin = sn.ham_metin
    bulunan: dict[str, list[Isabet]] = {}

    for m in TS_RE.finditer(metin):
        ad = f"TS {m.group(1)}"
        bulunan.setdefault(ad, []).append(_isabet(metin, m))
    for ad, kalip in DIGER_STANDART_RE.items():
        for m in kalip.finditer(metin):
            bulunan.setdefault(ad, []).append(_isabet(metin, m))

    # Sabit sorgu listesi: bulunamayanlar da raporlanir
    for sorgu in SABIT_SORGULAR:
        bulunan.setdefault(sorgu, [])
    sn.standartlar = bulunan

    # "VEYA" kontrolu ve marka bazlilik
    for ad, isabetler in bulunan.items():
        for isabet in isabetler:
            digerleri = [d for d in TS_RE.findall(isabet.baglam)]
            if len(digerleri) > 1:
                baglac = BAGLAC_RE.search(isabet.baglam)
                isabet.baglam += (f"   [BAĞLAÇ: "
                                  f"{baglac.group(1).upper() if baglac else '?'}]")
            if MARKA_BAZLI_RE.search(isabet.baglam):
                isabet.baglam += "   [MARKA BAZLI BELGE ŞARTI]"


def marka_bazli_mi(sn: Sartname) -> list[Isabet]:
    return [i for isabetler in sn.standartlar.values() for i in isabetler
            if "[MARKA BAZLI BELGE ŞARTI]" in i.baglam]


# ══════════════════════════════════════════════════════════════════════════
# C3 - Kapsam ve sorumluluk
# ══════════════════════════════════════════════════════════════════════════
def sorumluluk_cikar(sn: Sartname) -> None:
    metin = sn.ham_metin
    sonuc: dict[str, list[Isabet]] = {}
    for ad, kalip in _DERLI.items():
        sonuc[ad] = [_isabet(metin, m) for m in kalip.finditer(metin)]
    sn.sorumluluk = sonuc


def kapsam_cikar(sn: Sartname) -> None:
    """KONU basligi altindaki ilk maddedeki dahil/haric = temel kapsam hukmu."""
    metin = sn.ham_metin
    baslik = KONU_BASLIK_RE.search(metin)
    if baslik:
        pencere = metin[baslik.start(): baslik.start() + 1200]
        dh = DAHIL_HARIC_RE.search(pencere)
        if dh:
            konum = baslik.start() + dh.start()
            sn.kapsam = Kapsam(
                dahil_haric=tr_kucuk(dh.group(1)),
                madde=_onceki_madde(metin, konum),
                ifade=_baglam(metin, konum, konum + len(dh.group(1)), 120),
                kaynak_baslik=" ".join(baslik.group(0).split()))
            return
    # Baslik yoksa govdedeki kapsam kalibina bak
    m = _DERLI["kapsam_dahil_haric"].search(metin)
    if m:
        sn.kapsam = Kapsam(
            dahil_haric=tr_kucuk(m.group(2)) if m.lastindex else None,
            madde=_onceki_madde(metin, m.start()),
            ifade=_baglam(metin, m.start(), m.end(), 120),
            kaynak_baslik="(başlık bulunamadı, gövde metninden)")


# ══════════════════════════════════════════════════════════════════════════
# C4 - Envanter cikarimi
# ══════════════════════════════════════════════════════════════════════════
def envanter_cikar(sn: Sartname) -> None:
    metin = sn.ham_metin

    # Cihaz satirlari: "Marka/Model marka ve model, KUNYE kunye numarali"
    for m in CIHAZ_SATIR_RE.finditer(metin):
        marka_ham = " ".join(m.group("marka").split())
        # Satirin basindaki artik metni at (onceki satirdan tasmis olabilir)
        marka_ham = marka_ham.split(",")[-1].strip()
        cihaz = Cihaz(
            kunye=m.group("kunye"),
            marka=marka_ham or None,
            sayfa=cikarim.sayfa_no_bul(metin, m.start()),
        )
        tip = CIHAZ_TIPI_RE.search(m.group(0)) or CIHAZ_TIPI_RE.search(
            _baglam(metin, m.start(), m.end(), 200))
        cihaz.tip = tip.group(1) if tip else None
        if not cihaz.marka:
            cihaz.eksik_alanlar.append("marka/model")
        sn.cihazlar.append(cihaz)

    # Kunye numaralari (cihaz satirina baglanmamis olanlar dahil)
    kunyeler = set(KUNYE_RE.findall(metin))
    bagli = {c.kunye for c in sn.cihazlar if c.kunye}
    for k in sorted(kunyeler - bagli):
        konum = metin.find(k)
        sn.cihazlar.append(Cihaz(kunye=k, eksik_alanlar=["marka/model"],
                                 sayfa=cikarim.sayfa_no_bul(metin, konum)))

    # "Toplam N adet" ile kunye sayisini KARSILASTIR.
    #
    # Karsilastirma YALNIZCA belgede kunye numarasi varsa yapilir. Kunye
    # kullanmayan bir sartnamede (or. sarf malzeme alimi) "186 adet"
    # ifadesi cihaz sayisi degildir; karsilastirmak kirmizi bir yanlis
    # pozitif uretiyordu.
    toplam_m = TOPLAM_ADET_RE.search(metin)
    if toplam_m:
        iddia = int(toplam_m.group(1))           # acik "Toplam N adet"
    else:
        adetler = [int(a) for a in ADET_RE.findall(metin) if a.isdigit()]
        iddia = max(adetler) if adetler else None
    sn.sureler["metinde_gecen_adet"] = iddia
    if kunyeler and iddia and iddia != len(kunyeler):
        # Gercek vaka: kunye numaralari gri vurgu kutucugundaydi, OCR 23'ten
        # 18'ini okudu. Bu yuzden kunye sayfasinin GORUNTUSU uyariya iliskir.
        sayfa = None
        for c in sn.cihazlar:
            if c.sayfa:
                sayfa = c.sayfa
                break
        sn.uyari_ekle(
            U_KUNYE_UYUSMAZLIGI, KIRMIZI,
            f"Metin “{iddia} adet” diyor, belgede {len(kunyeler)} künye "
            f"numarası bulundu. İki olasılık var: (a) şartname kendi içinde "
            f"tutarsız, (b) OCR bazı numaraları okuyamadı. Ekteki sayfa "
            f"görüntüsünden gözle sayın.",
            sayfa=sayfa)

    # Marka/model bos kalan satirlar teklif hazirlamayi engeller
    eksikler = [c for c in sn.cihazlar if c.eksik_alanlar]
    if eksikler:
        sn.uyari_ekle(
            U_EKSIK_CIHAZ_BILGISI, SARI,
            f"{len(eksikler)} cihaz satırında marka/model bilgisi yok "
            f"(künye: {', '.join(str(c.kunye) for c in eksikler[:6])}"
            f"{' …' if len(eksikler) > 6 else ''}). Bu eksiklik teklif "
            f"hazırlamayı engeller; idareden açıklama istenmeli.",
            sayfa=eksikler[0].sayfa)

    # Bakim donemleri
    sn.sureler["bakim_donemleri"] = [" ".join(d.split())
                                     for d in DONEM_RE.findall(metin)]

    # Cihaz tipi dagilimi
    dagilim: dict[str, int] = {}
    for c in sn.cihazlar:
        if c.tip:
            anahtar = tr_kucuk(c.tip)
            dagilim[anahtar] = dagilim.get(anahtar, 0) + 1
    sn.sureler["cihaz_tipi_dagilimi"] = dagilim


# ══════════════════════════════════════════════════════════════════════════
# C5 - Ekli liste (MKYS / cihaz listesi)
# ══════════════════════════════════════════════════════════════════════════
def ek_liste_cikar(sn: Sartname) -> None:
    """Nitelik SADECE satir sonunda sayilir (govde basliklari sayima girmesin).

    Ek sayfalari biliniyorsa yalnizca onlarda aranir; boylece govdedeki
    "7. YEDEK PARCA/SARF" basligi hicbir kosulda kaleme donusmez.
    """
    if sn.sayfa_sayisi_govde:
        kaynak_sayfalar = [s for s in sn.sayfalar
                           if not s.damga_toplam]      # damgasiz = ek sayfa
    else:
        kaynak_sayfalar = list(sn.sayfalar)
    if not kaynak_sayfalar:
        kaynak_sayfalar = list(sn.sayfalar)

    for sayfa in kaynak_sayfalar:
        for m in EK_SATIR_RE.finditer(sayfa.metin):
            govde = m.group("govde").strip(" \t|-–—")
            if not govde:
                continue                    # tek basina nitelik kelimesi
            kod_m = EK_KOD_RE.match(govde)
            kod = kod_m.group(1) if kod_m else ""
            tanim = govde[len(kod):].strip(" \t|-–—") if kod else govde
            nitelik = " ".join(m.group("nitelik").upper().split())
            sn.ek_kalemler.append(EkKalem(kod=kod, tanim=tanim,
                                          nitelik=nitelik,
                                          sayfa=sayfa.pdf_sira))


# ══════════════════════════════════════════════════════════════════════════
# C6 - Sure, ceza, taahhut
# ══════════════════════════════════════════════════════════════════════════
def sure_ceza_cikar(sn: Sartname) -> None:
    metin = sn.ham_metin
    for ad, kalip in _SURE_DERLI.items():
        m = kalip.search(metin)
        sn.sureler[ad] = ({"ifade": " ".join(m.group(0).split()),
                           "madde": _onceki_madde(metin, m.start()),
                           "sayfa": cikarim.sayfa_no_bul(metin, m.start())}
                          if m else YOK)
    for ad, kalip in _CEZA_DERLI.items():
        m = kalip.search(metin)
        sn.cezalar[ad] = ({"ifade": " ".join(m.group(0).split()),
                           "madde": _onceki_madde(metin, m.start()),
                           "sayfa": cikarim.sayfa_no_bul(metin, m.start())}
                          if m else YOK)
    sn.sureler["bakim_donemi_sayisi"] = len(sn.sureler.get("bakim_donemleri", []))


# ══════════════════════════════════════════════════════════════════════════
# C7 - Belge talepleri
# ══════════════════════════════════════════════════════════════════════════
def belgeleri_cikar(sn: Sartname) -> None:
    metin = sn.ham_metin
    gorulen = set()
    for m in BELGE_TETIK_RE.finditer(metin):
        baglam = _baglam(metin, m.start(), m.end(), 200)
        madde = _onceki_madde(metin, m.start())
        ne_zaman = ""
        for kalip, etiket in ZAMAN_ESLEME:
            if re.search(kalip, baglam, re.IGNORECASE):
                ne_zaman = etiket
                break
        ad_m = BELGE_ADI_RE.search(baglam)
        ad = " ".join(ad_m.group(1).split()) if ad_m else "(belge adı belirsiz)"
        anahtar = (ad.lower(), madde)
        if anahtar in gorulen:
            continue
        gorulen.add(anahtar)
        sn.belgeler.append(Belge(
            ad=ad, madde=madde, ne_zaman=ne_zaman or "belirtilmemiş",
            yaptirim=YOK, baglam=baglam,
        ))


# ══════════════════════════════════════════════════════════════════════════
# C8 - Cevabi BU belgede olmayan sorular
# ══════════════════════════════════════════════════════════════════════════
def _cumle_bul(metin: str, ifade: str) -> str:
    """Verilen ifadeyi iceren TAM CUMLEYI dondurur.

    Ham baglam penceresi (+/-160 karakter) cumle ortasindan baslayip
    ortasinda bitiyor; rapora "cevap" olarak yazilinca okunamaz oluyordu.
    """
    metin = " ".join((metin or "").split())
    if not metin or not ifade:
        return metin
    iz = " ".join(ifade.split())[:30].lower()
    konum = metin.lower().find(iz)
    if konum < 0:
        return metin
    bas = metin.rfind(". ", 0, konum)
    bas = bas + 2 if bas >= 0 else 0
    son = metin.find(". ", konum)
    son = son + 1 if son >= 0 else len(metin)
    return metin[bas:son].strip()


def cevapsiz_sorular(sn: Sartname) -> None:
    for soru, anahtar, kaynak in CEVAPSIZ_SORULAR:
        isabetler = sn.sorumluluk.get(anahtar, []) if anahtar else []
        cevap = "teknik şartnamede hüküm yok"
        if isabetler:
            isabet = isabetler[0]
            madde = sn.madde_bul(isabet.madde) if isabet.madde else None
            # Once maddenin kendi metni denenir (en dogru kaynak), yoksa
            # isabetin baglami; her iki durumda da CUMLE sinirina kirpilir.
            cevap = _cumle_bul(madde.metin if madde else isabet.baglam,
                               isabet.ifade)[:300]
        sn.cevapsiz_sorular.append({
            "soru": soru,
            "teknik_sartnamede": bool(isabetler),
            "isabet_sayisi": len(isabetler),
            "madde": isabetler[0].madde if isabetler else None,
            "cevap": cevap,
            "kaynak": kaynak,
        })


# ══════════════════════════════════════════════════════════════════════════
# CELISKI MOTORU - uc sabit kontrol (Spesifikasyon C3)
# ══════════════════════════════════════════════════════════════════════════
def celiski_filtre(sn: Sartname) -> bool:
    """1) Filtreler idare tarafindan tedarik edilecek DENIYOR, ama ekli
    listede FILTRE iceren kalemler YEDEK PARCA nitelikli -> CELISKI."""
    idare_filtre = None
    for isabet in sn.sorumluluk.get("idare_karsilar", []):
        if re.search(r"filtre", isabet.baglam, re.IGNORECASE):
            idare_filtre = isabet
            break
    if not idare_filtre:
        return False
    catisan = [k for k in sn.ek_kalemler
               if "filtre" in tr_kucuk(k.tanim)
               and "YEDEK" in k.nitelik.upper()]
    if not catisan:
        return False
    sn.uyari_ekle(
        U_CELISKI, KIRMIZI,
        f"ÇELİŞKİ: Madde {idare_filtre.madde or '?'} filtrelerin İDARE "
        f"tarafından tedarik edileceğini söylüyor, ancak ekli listede "
        f"{len(catisan)} adet filtre kalemi YEDEK PARÇA olarak tanımlı "
        f"(örn. {catisan[0].kod} {catisan[0].tanim}). Yedek parça yüklenici "
        f"sorumluluğunda ise bu kalemleri kim karşılayacak belirsizdir.",
        madde=idare_filtre.madde, sayfa=idare_filtre.sayfa)
    return True


def celiski_aksesuar(sn: Sartname) -> bool:
    """2) Sorumluluk maddesi yalnizca SARF ve YEDEK PARCA tanimliyor, ama
    ekli listede AKSESUAR nitelikli kalem var -> TANIMSIZ SORUMLULUK."""
    aksesuar_kalemleri = [k for k in sn.ek_kalemler
                          if "AKSESUAR" in k.nitelik.upper()]
    if not aksesuar_kalemleri:
        return False
    # Govdede aksesuarin sorumlulugunu duzenleyen bir hukum var mi?
    tanimli = False
    for isabet in sn.sorumluluk.get("aksesuar", []):
        if re.search(r"kar[şs][ıi]lanacak|tedarik|sa[ğg]lanacak|"
                     r"y[üu]klenici|idare", isabet.baglam, re.IGNORECASE):
            tanimli = True
            break
    if tanimli:
        return False
    sn.uyari_ekle(
        U_TANIMSIZ_SORUMLULUK, KIRMIZI,
        f"TANIMSIZ SORUMLULUK: Ekli listede {len(aksesuar_kalemleri)} adet "
        f"AKSESUAR nitelikli kalem var, ancak gövdedeki sorumluluk maddeleri "
        f"yalnızca sarf ve yedek parçayı tanımlıyor. Aksesuarları kimin "
        f"karşılayacağı belirsiz; bu kalemler genelde pahalıdır ve "
        f"fiyatlandırmayı doğrudan etkiler.",
        sayfa=aksesuar_kalemleri[0].sayfa)
    return True


def celiski_sinirsiz_kapsam(sn: Sartname) -> bool:
    """3) KONU'da "yedek parca dahil" var + sarf/yedek parca ayrimi yapan
    madde YOK + ekli liste YOK -> FIYATLANAMAZ RISK."""
    if sn.kapsam.dahil_haric != "dahil":
        return False
    ayrim_var = bool(sn.sorumluluk.get("sarf")) and bool(
        sn.sorumluluk.get("yedek_parca"))
    if ayrim_var or sn.ek_kalemler:
        return False
    sn.uyari_ekle(
        U_SINIRSIZ_KAPSAM, KIRMIZI,
        f"FİYATLANAMAZ RİSK: Kapsam maddesi ({sn.kapsam.madde or '?'}) "
        f"“yedek parça dahil” diyor, ancak sarf/yedek parça ayrımı yapan bir "
        f"madde ve ekli malzeme listesi yok. Kapsam sınırsız kalıyor; "
        f"teklif öncesi idareden liste istenmeli.",
        madde=sn.kapsam.madde)
    return True


def celiskileri_bul(sn: Sartname) -> None:
    celiski_filtre(sn)
    celiski_aksesuar(sn)
    celiski_sinirsiz_kapsam(sn)


# ══════════════════════════════════════════════════════════════════════════
# Tum kurallari uygula
# ══════════════════════════════════════════════════════════════════════════
def uygula(sn: Sartname) -> Sartname:
    """C1-C8 + celiski motoru. Sirali calisir; sonraki adimlar oncekine dayanir."""
    maddeleri_cikar(sn)
    standartlari_cikar(sn)
    sorumluluk_cikar(sn)
    kapsam_cikar(sn)
    ek_liste_cikar(sn)
    envanter_cikar(sn)
    sure_ceza_cikar(sn)
    belgeleri_cikar(sn)
    cevapsiz_sorular(sn)
    madde_uyarilari(sn)
    celiskileri_bul(sn)
    return sn
