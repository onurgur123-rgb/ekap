# -*- coding: utf-8 -*-
"""Duyuru/reklam seridi ve destek ayarlari.

TASARIM KARARI: reklam icerigi UYGULAMANIN ICINDE DURMAZ. Icerik uzak bir
adresteki tek bir JSON dosyasindan okunur; boylece o dosyayi guncellemek
butun kurulumlarda otomatik olarak gorunur, yeni surum dagitmak gerekmez.

Saglamlik kurallari (arayuz asla bunlara takilmamali):
  - Ag islemleri HER ZAMAN ayri bir is parcaciginda yapilir.
  - Basarili her okuma yerel onbellege yazilir; internet yoksa son bilinen
    hal gosterilir, alan bos kalmaz.
  - Adres tanimsizsa, ag hatasi varsa veya JSON bozuksa modul sessizce bos
    liste doner; uygulama calismaya devam eder.

GUVENLIK: dosyadaki icerik VERIDIR, komut degildir. Yalnizca metin gosterilir
ve link SADECE kullanici tiklarsa acilir; acilmadan once http/https oldugu
dogrulanir (file:, javascript: gibi semalar reddedilir).
"""
from __future__ import annotations

import json
import threading
import urllib.request
from datetime import date, datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
AYAR_DOSYASI = BASE_DIR / "ayarlar.json"
ONBELLEK_DOSYASI = BASE_DIR / "duyuru_onbellek.json"
KAPATILAN_DOSYASI = BASE_DIR / "duyuru_kapatilan.json"
GORSEL_KLASORU = BASE_DIR / "duyuru_gorseller"

ZAMAN_ASIMI = 8          # saniye; arayuz beklemedigi icin cömert olabilir
MAX_BOYUT = 512 * 1024   # 512 KB'tan buyuk JSON kabul edilmez

VARSAYILAN_AYAR = {
    "_aciklama": [
        "Bu dosya ilk calistirmada varsayilanlarla olusturulur.",
        "reklam_adresi: duyuru/reklam iceriginin okunacagi JSON adresi.",
        "  Bos birakilirsa duyuru seridi hic gosterilmez.",
        "guncelleme_adresi: surum.json adresi. Bos birakilirsa guncelleme",
        "  denetlenmez.",
        "destek_eposta: Yardim penceresindeki 'E-posta Gonder' dugmesi bu",
        "  adrese yazar. Bos birakilirsa adres yerine 'tanimlanmamis' yazar.",
        "reklam_yenileme_dk: duyurularin kac dakikada bir kontrol edilecegi.",
    ],
    "reklam_adresi": "https://raw.githubusercontent.com/onurgur123-rgb/ekap/main/duyuru.json",
    "guncelleme_adresi": "https://raw.githubusercontent.com/onurgur123-rgb/ekap/main/surum.json",
    "destek_eposta": "",
    "destek_konu": "EKAP İzleyici — Destek Talebi",
    "reklam_yenileme_dk": 60,
}


# ── Ayarlar ────────────────────────────────────────────────────────────────
def ayarlari_oku() -> dict:
    """ayarlar.json'u okur; yoksa varsayilanlarla olusturur."""
    ayar = dict(VARSAYILAN_AYAR)
    try:
        if AYAR_DOSYASI.exists():
            veri = json.loads(AYAR_DOSYASI.read_text(encoding="utf-8"))
            if isinstance(veri, dict):
                ayar.update({k: v for k, v in veri.items()
                             if k in VARSAYILAN_AYAR})
        else:
            AYAR_DOSYASI.write_text(
                json.dumps(VARSAYILAN_AYAR, ensure_ascii=False, indent=2),
                encoding="utf-8")
    except Exception:
        pass
    return ayar


def destek_eposta() -> str:
    return str(ayarlari_oku().get("destek_eposta") or "").strip()


# ── Kapatilan duyurular ────────────────────────────────────────────────────
def _kapatilanlar() -> set[str]:
    try:
        veri = json.loads(KAPATILAN_DOSYASI.read_text(encoding="utf-8"))
        return set(veri) if isinstance(veri, list) else set()
    except Exception:
        return set()


def kapat(duyuru_id: str) -> None:
    """Kullanici bir duyuruyu kapatti; bir daha gosterilmez.

    Kimlik bazlidir: siz YENI kimlikli bir duyuru yayinladiginizda serit
    yeniden gorunur, eskisi gizli kalir.
    """
    if not duyuru_id:
        return
    kume = _kapatilanlar()
    kume.add(str(duyuru_id))
    try:
        KAPATILAN_DOSYASI.write_text(
            json.dumps(sorted(kume), ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


# ── Duyurulari cozumle ─────────────────────────────────────────────────────
def _tarih(deger) -> date | None:
    if not deger:
        return None
    try:
        return datetime.fromisoformat(str(deger)[:10]).date()
    except Exception:
        return None


def _gecerli(kayit: dict, bugun: date) -> bool:
    """Tarih araligi bugunu kapsiyor mu? (Kampanya kendi kendine biter.)"""
    bas, bit = _tarih(kayit.get("baslangic")), _tarih(kayit.get("bitis"))
    if bas and bugun < bas:
        return False
    if bit and bugun > bit:
        return False
    return True


def guvenli_link(link: str) -> str | None:
    """Yalnizca http/https adreslerine izin verir."""
    link = str(link or "").strip()
    return link if link[:7].lower() in ("http://",) or \
        link[:8].lower() == "https://" else None


def _cozumle(veri) -> list[dict]:
    """Hem {"duyurular": [...]} hem de duz liste bicimini kabul eder."""
    if isinstance(veri, dict):
        veri = (veri.get("duyurular") or veri.get("reklamlar")
                or veri.get("items") or [])
    if not isinstance(veri, list):
        return []
    temiz = []
    for k in veri:
        if not isinstance(k, dict):
            continue
        temiz.append({
            "id": str(k.get("id") or k.get("kimlik") or "").strip(),
            "baslik": str(k.get("baslik") or "").strip(),
            "metin": str(k.get("metin") or k.get("aciklama") or "").strip(),
            "link": guvenli_link(k.get("link") or k.get("adres") or ""),
            "gorsel": str(k.get("gorsel") or "").strip(),
            "renk": str(k.get("renk") or "").strip(),
            "baslangic": k.get("baslangic"),
            "bitis": k.get("bitis"),
        })
    return temiz


def _onbellege_yaz(kayitlar: list[dict]) -> None:
    try:
        ONBELLEK_DOSYASI.write_text(
            json.dumps(kayitlar, ensure_ascii=False, indent=2),
            encoding="utf-8")
    except Exception:
        pass


def onbellekten_oku() -> list[dict]:
    try:
        return _cozumle(json.loads(
            ONBELLEK_DOSYASI.read_text(encoding="utf-8")))
    except Exception:
        return []


def _indir(adres: str) -> list[dict]:
    istek = urllib.request.Request(
        adres, headers={"User-Agent": "EKAP-Izleyici/1.0"})
    with urllib.request.urlopen(istek, timeout=ZAMAN_ASIMI) as yanit:
        ham = yanit.read(MAX_BOYUT + 1)
    if len(ham) > MAX_BOYUT:
        raise ValueError("duyuru dosyasi cok buyuk")
    return _cozumle(json.loads(ham.decode("utf-8")))


def gorsel_indir(adres: str) -> Path | None:
    """Duyuru gorselini onbellege indirir; yerel yolu doner.

    Ayni adres tekrar istenirse yeniden indirilmez.
    """
    if not guvenli_link(adres):
        return None
    try:
        import hashlib
        ad = hashlib.sha256(adres.encode("utf-8")).hexdigest()[:16]
        # Dosya ne bicimde gelirse gelsin diske OLDUGU GIBI yazilir; olcekleme
        # ve bicim donusumu arayuz tarafinda Pillow ile yapilir. tkinter tek
        # basina yalnizca PNG/GIF acabildigi icin eskiden JPEG reddediliyordu.
        uzanti = Path(adres.split("?")[0]).suffix.lower()
        if uzanti not in (".png", ".gif", ".jpg", ".jpeg", ".webp", ".bmp"):
            uzanti = ".img"
        hedef = GORSEL_KLASORU / f"{ad}{uzanti}"
        if hedef.exists():
            return hedef
        GORSEL_KLASORU.mkdir(exist_ok=True)
        istek = urllib.request.Request(
            adres, headers={"User-Agent": "EKAP-Izleyici/1.0"})
        with urllib.request.urlopen(istek, timeout=ZAMAN_ASIMI) as yanit:
            veri = yanit.read(2 * 1024 * 1024)      # en fazla 2 MB
        hedef.write_bytes(veri)
        return hedef
    except Exception:
        return None


# ── Dis dunyaya acilan iki fonksiyon ───────────────────────────────────────
def gosterilecekler(kayitlar: list[dict] | None = None) -> list[dict]:
    """Tarihi gecerli, kullanici tarafindan kapatilmamis duyurular."""
    kayitlar = onbellekten_oku() if kayitlar is None else kayitlar
    kapali, bugun = _kapatilanlar(), date.today()
    return [k for k in kayitlar
            if _gecerli(k, bugun) and k.get("id") not in kapali
            and (k.get("baslik") or k.get("metin") or k.get("gorsel"))]


def arka_planda_yenile(bitince=None) -> None:
    """Duyurulari ayri is parcaciginda tazeler; arayuzu asla bekletmez.

    bitince(kayitlar) geri cagrisi ag islemi bittiginde calisir. Arayuzden
    cagrilirken tkinter'in after() ile ana is parcacigina donmesi gerekir.
    """
    adres = guvenli_link(ayarlari_oku().get("reklam_adresi", ""))
    if not adres:
        if bitince:
            bitince(gosterilecekler())
        return

    def calis():
        try:
            kayitlar = _indir(adres)
            if kayitlar:
                _onbellege_yaz(kayitlar)
        except Exception:
            kayitlar = None          # ag yok / bozuk dosya -> onbellek kalsin
        if bitince:
            bitince(gosterilecekler(kayitlar if kayitlar else None))

    threading.Thread(target=calis, daemon=True).start()
