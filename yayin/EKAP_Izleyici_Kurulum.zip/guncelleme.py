# -*- coding: utf-8 -*-
"""GitHub uzerinden surum kontrolu ve guncelleme.

CALISMA MANTIGI
    Depodaki surum.json okunur, icindeki surum numarasi uygulamanin
    kendi surumuyle karsilastirilir. Yenisi varsa kullaniciya bildirilir;
    paket ANCAK KULLANICI ONAYLARSA indirilir ve kurulur.

GUVENLIK (bu modul uzaktan KOD indirip calistirdigi icin onemli)
    - Yalnizca https adresleri kabul edilir.
    - Indirilen dosyanin gercekten ZIP oldugu ve beklenen dosyalari
      (ekap_monitor.py) icerdigi kurulumdan ONCE dogrulanir.
    - ZIP icindeki yollar tek tek kontrol edilir; ".." veya mutlak yol
      iceren girdi reddedilir (zip-slip saldirisi).
    - Kurulum ONCESINDE mevcut dosyalar yedeklenir.
    - Kullanici ayarlari, durum dosyalari ve indirilen belgeler ASLA
      uzerine yazilmaz.
    - Hicbir sey kullanici onayi olmadan kurulmaz.
"""
from __future__ import annotations

import json
import shutil
import threading
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
ZAMAN_ASIMI = 15
MAX_JSON = 64 * 1024
MAX_PAKET = 40 * 1024 * 1024        # 40 MB'tan buyuk paket kabul edilmez

# Guncellemede ASLA uzerine yazilmayacak dosya/klasorler. Kullanicinin
# kendi verisi ve ayarlari buradadir.
KORUNAN = {
    "ayarlar.json",
    "ekap_state.json",
    "ekap_dt_state.json",
    "duyuru_onbellek.json",
    "duyuru_kapatilan.json",
    "indirilen_dokumanlar",
    "sartname_raporlari",
    "duyuru_gorseller",
    ".venv",
}

# Pakette bulunmasi ZORUNLU dosya; yoksa indirilen sey bizim paketimiz
# degildir ve kurulum yapilmaz.
ZORUNLU_DOSYA = "ekap_monitor.py"


class GuncellemeHatasi(RuntimeError):
    pass


# ── Surum karsilastirma ────────────────────────────────────────────────────
def surum_sayisi(s: str) -> tuple:
    """'1.10.2' -> (1, 10, 2). Metin karsilastirmasi yanlis sonuc verir:
    '1.10' < '1.9' olurdu."""
    parcalar = []
    for p in str(s or "0").strip().split("."):
        rakam = "".join(k for k in p if k.isdigit())
        parcalar.append(int(rakam) if rakam else 0)
    while len(parcalar) < 3:
        parcalar.append(0)
    return tuple(parcalar[:3])


def daha_yeni(uzak: str, yerel: str) -> bool:
    return surum_sayisi(uzak) > surum_sayisi(yerel)


def _https(adres: str) -> str | None:
    adres = str(adres or "").strip()
    return adres if adres.lower().startswith("https://") else None


# ── Surum bilgisini oku ────────────────────────────────────────────────────
def surum_bilgisi(adres: str) -> dict:
    """surum.json'u indirir ve cozumler."""
    guvenli = _https(adres)
    if not guvenli:
        raise GuncellemeHatasi("Güncelleme adresi https ile başlamalı.")
    istek = urllib.request.Request(
        guvenli, headers={"User-Agent": "EKAP-Izleyici"})
    with urllib.request.urlopen(istek, timeout=ZAMAN_ASIMI) as yanit:
        ham = yanit.read(MAX_JSON + 1)
    if len(ham) > MAX_JSON:
        raise GuncellemeHatasi("surum.json beklenenden büyük.")
    veri = json.loads(ham.decode("utf-8"))
    if not isinstance(veri, dict):
        raise GuncellemeHatasi("surum.json biçimi hatalı.")
    return {
        "surum": str(veri.get("surum") or veri.get("version") or "").strip(),
        "notlar": str(veri.get("notlar") or veri.get("notes") or "").strip(),
        "paket": _https(veri.get("paket") or veri.get("url") or ""),
        "tarih": str(veri.get("tarih") or "").strip(),
    }


def kontrol_et(adres: str, yerel_surum: str) -> dict | None:
    """Yeni surum varsa bilgisini, yoksa None doner."""
    bilgi = surum_bilgisi(adres)
    if not bilgi["surum"] or not daha_yeni(bilgi["surum"], yerel_surum):
        return None
    if not bilgi["paket"]:
        raise GuncellemeHatasi(
            f"Sürüm {bilgi['surum']} duyurulmuş ama paket adresi yok.")
    return bilgi


def arka_planda_kontrol(adres: str, yerel_surum: str, bitince) -> None:
    """Surum kontrolunu ayri is parcaciginda yapar; arayuzu bekletmez.

    bitince(bilgi, hata) seklinde cagrilir. Ag yoksa sessizce hata doner;
    kullaniciya uyari gosterilmez (her acilista hata penceresi cikmasin).
    """
    def calis():
        try:
            bitince(kontrol_et(adres, yerel_surum), None)
        except Exception as e:
            bitince(None, e)

    if _https(adres):
        threading.Thread(target=calis, daemon=True).start()


# ── Paketi indir ve dogrula ────────────────────────────────────────────────
def paket_indir(adres: str, hedef: Path, ilerleme=None) -> Path:
    """Paketi indirir. ilerleme(inen_bayt, toplam_bayt) cagrilir."""
    guvenli = _https(adres)
    if not guvenli:
        raise GuncellemeHatasi("Paket adresi https ile başlamalı.")
    hedef = Path(hedef)
    hedef.parent.mkdir(parents=True, exist_ok=True)
    istek = urllib.request.Request(
        guvenli, headers={"User-Agent": "EKAP-Izleyici"})
    with urllib.request.urlopen(istek, timeout=ZAMAN_ASIMI) as yanit:
        toplam = int(yanit.headers.get("Content-Length") or 0)
        if toplam > MAX_PAKET:
            raise GuncellemeHatasi(
                f"Paket çok büyük ({toplam / 1048576:.0f} MB).")
        inen = 0
        with open(hedef, "wb") as f:
            while True:
                blok = yanit.read(256 * 1024)
                if not blok:
                    break
                inen += len(blok)
                if inen > MAX_PAKET:
                    raise GuncellemeHatasi("Paket çok büyük.")
                f.write(blok)
                if ilerleme:
                    ilerleme(inen, toplam)
    return hedef


def paketi_dogrula(zip_yolu: Path) -> list[str]:
    """ZIP'i acmadan once inceler; guvenli degilse hata firlatir.

    Doner: pakette bulunan dosya yollari.
    """
    if not zipfile.is_zipfile(zip_yolu):
        raise GuncellemeHatasi(
            "İndirilen dosya geçerli bir ZIP değil. Güncelleme iptal edildi.")
    with zipfile.ZipFile(zip_yolu) as z:
        adlar = z.namelist()
        for ad in adlar:
            # zip-slip: paket ".." veya mutlak yol icererek uygulama
            # klasorunun DISINA dosya yazabilir. Once reddet, sonra ac.
            yol = Path(ad)
            if yol.is_absolute() or ".." in yol.parts or ad.startswith("/"):
                raise GuncellemeHatasi(
                    f"Pakette güvenli olmayan dosya yolu var: {ad}")
        if not any(Path(a).name == ZORUNLU_DOSYA for a in adlar):
            raise GuncellemeHatasi(
                f"Pakette {ZORUNLU_DOSYA} yok; bu bir EKAP İzleyici "
                f"paketi değil. Güncelleme iptal edildi.")
    return adlar


# ── Kurulum ────────────────────────────────────────────────────────────────
def yedekle(hedef_klasor: Path) -> Path:
    """Mevcut program dosyalarini zaman damgali bir klasore kopyalar."""
    yedek = hedef_klasor / "yedek" / datetime.now().strftime("%Y%m%d_%H%M%S")
    yedek.mkdir(parents=True, exist_ok=True)
    for ad in (ZORUNLU_DOSYA, "duyuru.py", "guncelleme.py",
               "requirements.txt", "kurulum.bat", "EKAP_Baslat.bat",
               "OKUBENI.txt"):
        kaynak = hedef_klasor / ad
        if kaynak.exists():
            shutil.copy2(kaynak, yedek / ad)
    if (hedef_klasor / "sartname").is_dir():
        shutil.copytree(hedef_klasor / "sartname", yedek / "sartname",
                        dirs_exist_ok=True)
    return yedek


def kur(zip_yolu: Path, hedef_klasor: Path = BASE_DIR) -> tuple[Path, int]:
    """Dogrulanmis paketi uygulama klasorune acar.

    Doner: (yedek klasoru, yazilan dosya sayisi)
    """
    paketi_dogrula(zip_yolu)
    hedef_klasor = Path(hedef_klasor)
    yedek = yedekle(hedef_klasor)

    yazilan = 0
    with zipfile.ZipFile(zip_yolu) as z:
        for bilgi in z.infolist():
            if bilgi.is_dir():
                continue
            yol = Path(bilgi.filename)
            # Paketin en ustunde tek bir klasor varsa (GitHub ZIP'leri
            # boyle gelir) o katman atlanir.
            parcalar = yol.parts
            if parcalar and parcalar[0] in KORUNAN:
                continue
            if any(p in KORUNAN for p in parcalar):
                continue
            hedef = hedef_klasor / yol
            hedef.parent.mkdir(parents=True, exist_ok=True)
            with z.open(bilgi) as kaynak, open(hedef, "wb") as f:
                shutil.copyfileobj(kaynak, f)
            yazilan += 1
    return yedek, yazilan
