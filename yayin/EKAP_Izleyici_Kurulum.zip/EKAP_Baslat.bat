@echo off
chcp 65001 >nul
cd /d "%~dp0"

if not exist ".venv\Scripts\pythonw.exe" (
    echo.
    echo   Uygulama henuz kurulmamis.
    echo   Once "kurulum.bat" dosyasini calistirin.
    echo.
    pause
    exit /b 1
)

if not exist "ekap_monitor.py" (
    echo.
    echo   ekap_monitor.py bulunamadi. Dosyalar eksik kopyalanmis olabilir.
    echo.
    pause
    exit /b 1
)

start "" ".venv\Scripts\pythonw.exe" "ekap_monitor.py"
