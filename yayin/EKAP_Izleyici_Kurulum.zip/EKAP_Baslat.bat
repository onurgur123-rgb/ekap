@echo off
cd /d "%~dp0"
if exist "EKAP_Izleyici.exe" (
    start "" "EKAP_Izleyici.exe"
    exit /b 0
)
start "" ".venv\Scripts\pythonw.exe" "ekap_monitor.py"
