# -*- coding: utf-8 -*-
"""EKAP Izleyici - .py surumunden derlenmis .exe surumune GECIS.

Eski (.py) kurulumlar bu dosyayi uygulama ici guncelleme ile alir. Program
kodu icermez: kullaniciya gecisi anlatir, ayni klasorde duran
EKAP_Kurulum_Exe.bat'i yonetici olarak bu klasore kurmak uzere calistirir.
Kayitlar (veritabani, ayarlar, indirilen belgeler) yerinde kalir.
"""
import ctypes
import sys
import tkinter as tk
from pathlib import Path
from tkinter import messagebox

SURUM = "1.0.7"
BASE_DIR = Path(__file__).resolve().parent
KURULUM = BASE_DIR / "EKAP_Kurulum_Exe.bat"


def gecis_baslat(win) -> None:
    if not KURULUM.exists():
        messagebox.showerror(
            "EKAP İzleyici", "Kurulum dosyası bulunamadı:\n"
            f"{KURULUM}\n\nLütfen destekle iletişime geçin.", parent=win)
        return
    # cmd /c ""bat" args": cmd ilk ve son tirnagi atar, ic tirnaklar kalir.
    parametre = (f'/c ""{KURULUM}" /yukseltildi /hedef "{BASE_DIR}""')
    sonuc = ctypes.windll.shell32.ShellExecuteW(
        None, "runas", "cmd.exe", parametre, str(BASE_DIR), 1)
    if sonuc <= 32:
        messagebox.showwarning(
            "EKAP İzleyici", "Yönetici izni verilmedi; geçiş başlamadı.\n"
            "Programı yeniden açıp tekrar deneyebilirsiniz.", parent=win)
        return
    win.destroy()
    sys.exit(0)


def main() -> None:
    win = tk.Tk()
    win.title("EKAP İzleyici — Yeni Sürüm")
    win.configure(bg="#0f1419")
    win.resizable(False, False)
    tk.Label(win, text="Güvenlik güncellemesi", bg="#0f1419", fg="#e6edf3",
             font=("Segoe UI", 14, "bold")).pack(padx=28, pady=(22, 6),
                                                 anchor="w")
    tk.Label(
        win, bg="#0f1419", fg="#c9d1d9", justify="left", wraplength=440,
        font=("Segoe UI", 10),
        text=("EKAP İzleyici yeni ve daha güvenli bir sürüme geçiyor.\n\n"
              "• Kayıtlarınız, ayarlarınız ve indirdiğiniz belgeler korunur.\n"
              "• Python artık gerekmez; program tek dosya olarak çalışır.\n"
              "• Kurulum için yönetici izni istenecek (birkaç dakika sürer).\n"
              "• İlk açılışta lisans anahtarınız sorulacak.")
    ).pack(padx=28, anchor="w")
    tk.Label(win, text="Lisans için: onurgur123@gmail.com", bg="#0f1419",
             fg="#6e7681", font=("Segoe UI", 8)).pack(padx=28, pady=(12, 0),
                                                      anchor="w")
    alt = tk.Frame(win, bg="#0f1419")
    alt.pack(fill="x", padx=28, pady=(16, 22))
    tk.Button(alt, text="Şimdi Geç", command=lambda: gecis_baslat(win),
              bg="#2f81f7", fg="#fff", relief="flat", padx=16, pady=4,
              cursor="hand2", font=("Segoe UI", 10, "bold")).pack(side="right")
    tk.Button(alt, text="Kapat", command=win.destroy, bg="#21262d",
              fg="#e6edf3", relief="flat", padx=14, pady=4, cursor="hand2",
              font=("Segoe UI", 10)).pack(side="right", padx=(0, 8))
    win.update_idletasks()
    win.geometry(f"+{(win.winfo_screenwidth() - win.winfo_width()) // 2}"
                 f"+{(win.winfo_screenheight() - win.winfo_height()) // 3}")
    win.mainloop()


if __name__ == "__main__":
    main()
