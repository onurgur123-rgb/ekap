#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EKAP İhale İzleyici — Masaüstü Uygulaması
==========================================
* Uygulama açıkken EKAP arama sayfasını periyodik olarak tarar.
* Yeni ihale bulunduğunda hem pencerede hem de Windows bildiriminde gösterir.
* Pencere kapatılınca tarama durur; tekrar açılınca kaldığı yerden devam eder.
* Listede bir satıra çift tıklayınca ihale dokümanı indirilir;
  sağ tıklayınca ihale sayfası tarayıcıda açılır.
"""

import asyncio
import io
import json
import os
import queue
import re
import shutil
import subprocess
import threading
import time
import unicodedata
import zipfile
import webbrowser
from datetime import datetime
from pathlib import Path
import sys

import tkinter as tk
from tkinter import ttk, messagebox

# ── Bağımlılık kontrolleri ────────────────────────────────────────────────────
# Duyuru/reklam seridi ve destek ayarlari. Ayri bir dosyada durur ve ana
# uygulamayi hic tanimaz; yoksa yalnizca duyuru seridi ile yardim
# penceresindeki e-posta dugmesi devre disi kalir.
try:
    import duyuru
except Exception:
    duyuru = None

# GitHub uzerinden surum kontrolu. Yoksa uygulama calisir, yalnizca
# guncelleme bildirimi gosterilmez.
try:
    import guncelleme
except Exception:
    guncelleme = None

try:
    from playwright.async_api import async_playwright
    HAS_PLAYWRIGHT = True
except ImportError:
    HAS_PLAYWRIGHT = False

try:
    from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError
    HAS_PLAYWRIGHT_SYNC = True
except ImportError:
    HAS_PLAYWRIGHT_SYNC = False
    PlaywrightTimeoutError = Exception

try:
    from winotify import Notification as WinNotify
    HAS_WINOTIFY = True
except ImportError:
    HAS_WINOTIFY = False

try:
    import fitz  # pymupdf
    HAS_PDF_TEXT = True
except ImportError:
    HAS_PDF_TEXT = False

try:
    import pytesseract
    from PIL import Image, ImageTk
    HAS_OCR = True
except ImportError:
    HAS_OCR = False

# ── Sabitler ──────────────────────────────────────────────────────────────────
BASE_DIR        = Path(__file__).resolve().parent
DOWNLOAD_DIR    = BASE_DIR / "indirilen_dokumanlar"
SARTNAME_DIR    = BASE_DIR / "sartname_raporlari"   # Excel/JSON/ham metin ciktilari

# ── Calisma modlari ───────────────────────────────────────────────────────────
# Uygulama iki ayri kaynagi izleyebilir. Ikisi TAMAMEN farkli sistemler:
#   ihale : ekapv2 (Angular + JSON API)          -> ihale ilanlari
#   dt    : eski EKAP (YeniIhaleAramaData.ashx)  -> dogrudan temin duyurulari
# Her modun kendi durum dosyasi ve kendi logu var; kayitlar karismasin.
MODE_IHALE = "ihale"
MODE_DT    = "dt"
MODE_LABELS = {MODE_IHALE: "İhaleler", MODE_DT: "Doğrudan Temin"}

MODE_STATE_FILES = {
    MODE_IHALE: BASE_DIR / "ekap_state.json",
    MODE_DT:    BASE_DIR / "ekap_dt_state.json",
}
MODE_LOG_FILES = {
    MODE_IHALE: BASE_DIR / "ekap_new_items.log",
    MODE_DT:    BASE_DIR / "ekap_dt_new_items.log",
}

# ── Dogrudan Temin (eski EKAP) ────────────────────────────────────────────────
# Duz GET + JSON dondurur; Angular bootstrap gerekmedigi icin bu mod
# GORUNUR PENCERE ACMADAN, headless calisir.
DT_SEARCH_PAGE = "https://ekap.kik.gov.tr/EKAP/YeniIhaleArama.aspx"
DT_DATA_URL    = "https://ekap.kik.gov.tr/EKAP/Ortak/YeniIhaleAramaData.ashx"
DT_DETAIL_URL  = ("https://ekap.kik.gov.tr/EKAP/Ortak/DogrudanTeminDetay.aspx"
                  "?IdareId={idare_id}&IhaleId={dt_id}&IlanVarMi={ilan}&DosyaVarMi={dosya}")
# EKAP'in kendi main.js'inde DT dokuman indirme sudur:
#   window.open("/EKAP/YeniIhaleArama.aspx?qs=1&dokumanIndir=1&dogrudanTeminId=" + item.E10)
# VatandasIlanGoruntuleme.aspx?aramaDownload=... yolu ayni dosyada YORUM
# satirina alinmis eski yontem; o adres bos sayfaya dusuruyor.
DT_DOC_URL     = ("https://ekap.kik.gov.tr/EKAP/YeniIhaleArama.aspx"
                  "?qs=1&dokumanIndir=1&dogrudanTeminId={dt_id}")
# Duyuru (ilan) goruntuleme — dokuman degil, ilan metni icin:
DT_ILAN_URL    = ("https://ekap.kik.gov.tr/EKAP/Ortak/VatandasIlanGoruntuleme.aspx"
                  "?dogrudanTeminId={dt_id}&ilanTip=1")
DT_STATUS_OPEN = "202"      # "Doğrudan Temin Duyurusu Yayımlanmış"
# Sayfalama. Olculen degerler: dtDurum=202 ("Duyurusu Yayimlanmis")
# sonuclarinin TAMAMININ teklif tarihi gelecekte; yani EKAP suresi gecenleri
# bu durumdan cikariyor. Toplam ~3400 kayit / 29 sayfa / ~85 sn.
#   - Her taramada HIZLI tarama yapilir (en yeni DTN'ler, yeni duyurular
#     hemen yakalansin diye).
#   - Belirli araliklarla TAM tarama yapilir (teklif tarihi gecmemis
#     butun duyurular).
# Ihale tarafi: liste servisi istekte ne yazarsak yazalim sayfa basina
# 50 kayit donduruyor; acik ihale toplami ~1700 (34 sayfa, ~2 dk). Sayfa
# yuklemesi pahali oldugu icin (~13 sn) sayfa BIR KEZ acilir, sonraki
# sayfalar sitenin kendi "Filtrele" dugmesi tetiklenerek alinir (~3 sn).
IHALE_TAM_SAYFA     = 45    # tam taramada ust sinir (erken biter)
IHALE_TAM_SURE_SN   = 150   # sayfalama icin toplam sure butcesi
IHALE_TAM_ARALIK_DK = 20    # tam tarama araligi (dakika)

DT_HIZLI_SAYFA   = 3        # her taramada (sayfa basina 128 kayit)
DT_TAM_SAYFA     = 40       # tam taramada ust sinir (erken biter)
# "Ilan icinde ara" EKAP'a suzulmus sorgu gonderir, sonuc az olur; yine de
# tek sayfayla sinirlamamak icin ust sinir genis tutulur (bos sayfada biter).
DT_ARAMA_SAYFA   = 20
DT_TAM_ARALIK_DK = 20       # tam tarama araligi (dakika)
# OCR ayarlari. Olculen degerler (gercek EKAP taranmis sartnamesi, Tesseract
# guven skoru): 2x + ingilizce = 42 | 3x + turkce = 68 | 4x + gri + turkce = 84.
# Cozunurluk en belirleyici etken; 4x yaklasik 288 DPI eder.
OCR_ZOOM = 4
_OCR_DIL_ONBELLEK = None


def ocr_dili() -> str:
    """Kullanilacak OCR dilini secer: Turkce paketi varsa 'tur', yoksa 'eng'.

    Kodda "tur+eng" yazmak yaniltici: Turkce paketi yoksa Tesseract sessizce
    ingilizceye dusuyor ve Turkce belge sacma cikiyordu ("MUDURLUGU" ->
    "MODORLOGO"). Ayrica ikisi birlikte verildiginde ingilizce model araya
    girip Turkce harfleri bozuyor, o yuzden tek dil kullaniliyor.
    """
    global _OCR_DIL_ONBELLEK
    if _OCR_DIL_ONBELLEK:
        return _OCR_DIL_ONBELLEK
    dil = "eng"
    try:
        if "tur" in pytesseract.get_languages(config=""):
            dil = "tur"
    except Exception:
        pass
    _OCR_DIL_ONBELLEK = dil
    return dil


DT_TURLER      = {"1": "Mal", "2": "Yapım", "3": "Hizmet", "4": "Danışmanlık"}

# Turkiye'nin 7 cografi bolgesi ve illeri. Filtre panelinde iller bu
# basliklarin altinda gruplanir; bir bolge secilince altindaki tum iller
# secilmis sayilir.
TR_BOLGELER = {
    "MARMARA": ("BALIKESİR", "BİLECİK", "BURSA", "ÇANAKKALE", "EDİRNE",
                "İSTANBUL", "KIRKLARELİ", "KOCAELİ", "SAKARYA", "TEKİRDAĞ",
                "YALOVA"),
    "EGE": ("AFYONKARAHİSAR", "AYDIN", "DENİZLİ", "İZMİR", "KÜTAHYA",
            "MANİSA", "MUĞLA", "UŞAK"),
    "AKDENİZ": ("ADANA", "ANTALYA", "BURDUR", "HATAY", "ISPARTA",
                "KAHRAMANMARAŞ", "MERSİN", "OSMANİYE"),
    "İÇ ANADOLU": ("AKSARAY", "ANKARA", "ÇANKIRI", "ESKİŞEHİR", "KARAMAN",
                   "KAYSERİ", "KIRIKKALE", "KIRŞEHİR", "KONYA", "NEVŞEHİR",
                   "NİĞDE", "SİVAS", "YOZGAT"),
    "KARADENİZ": ("AMASYA", "ARTVİN", "BARTIN", "BAYBURT", "BOLU", "ÇORUM",
                  "DÜZCE", "GİRESUN", "GÜMÜŞHANE", "KARABÜK", "KASTAMONU",
                  "ORDU", "RİZE", "SAMSUN", "SİNOP", "TOKAT", "TRABZON",
                  "ZONGULDAK"),
    "DOĞU ANADOLU": ("AĞRI", "ARDAHAN", "BİNGÖL", "BİTLİS", "ELAZIĞ",
                     "ERZİNCAN", "ERZURUM", "HAKKARİ", "IĞDIR", "KARS",
                     "MALATYA", "MUŞ", "TUNCELİ", "VAN"),
    "GÜNEYDOĞU ANADOLU": ("ADIYAMAN", "BATMAN", "DİYARBAKIR", "GAZİANTEP",
                          "KİLİS", "MARDİN", "SİİRT", "ŞANLIURFA", "ŞIRNAK"),
}

BOLGE_DISI = "DİĞER"

# Il adi (sadelestirilmis) -> bolge esleme tablosu. tr_fold bu noktadan
# sonra tanimlandigi icin ilk kullanimda kurulur.
_IL_BOLGE = None


def teklif_suresi_gecti(kayit: dict) -> bool:
    """Kaydin son teklif / ihale tarihi gecmis mi?

    EKAP acik durumdaki kayitlarda suresi gecenleri zaten listeden cikariyor;
    bu kontrol, onceki taramalardan tasinan eski kayitlari ayiklamak icin.
    """
    ham = str(kayit.get("ihaleTarihSaat") or "").strip()
    if not ham:
        return False                      # bilinmiyorsa elemeyelim
    for bicim in ("%d.%m.%Y %H:%M", "%d.%m.%Y", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(ham, bicim) < datetime.now()
        except ValueError:
            continue
    try:
        return datetime.fromisoformat(ham.replace("Z", "")) < datetime.now()
    except Exception:
        return False


def il_bolgesi(il: str) -> str:
    """Verilen ilin cografi bolgesini dondurur; bilinmiyorsa DİĞER.

    EKAP yazimindaki kucuk farklar sorun cikarmasin diye eslestirme
    sadelestirilmis (tr_fold) adlar uzerinden yapilir.
    """
    global _IL_BOLGE
    if _IL_BOLGE is None:
        _IL_BOLGE = {tr_fold(i): b
                     for b, iller in TR_BOLGELER.items() for i in iller}
    return _IL_BOLGE.get(tr_fold(il or ""), BOLGE_DISI)


# EKAP il kodlari (dtEnum -> enumDtIller). Sabit veri oldugu icin gomulu
# tutuluyor; her acilista servise sormaya gerek yok.
DT_ILLER = {
    "1": "ADANA", "2": "ADIYAMAN", "3": "AFYONKARAHİSAR", "68": "AKSARAY",
    "5": "AMASYA", "6": "ANKARA", "7": "ANTALYA", "75": "ARDAHAN",
    "8": "ARTVİN", "9": "AYDIN", "4": "AĞRI", "10": "BALIKESİR",
    "74": "BARTIN", "72": "BATMAN", "69": "BAYBURT", "14": "BOLU",
    "15": "BURDUR", "16": "BURSA", "11": "BİLECİK", "12": "BİNGÖL",
    "13": "BİTLİS", "20": "DENİZLİ", "81": "DÜZCE", "21": "DİYARBAKIR",
    "22": "EDİRNE", "23": "ELAZIĞ", "25": "ERZURUM", "24": "ERZİNCAN",
    "26": "ESKİŞEHİR", "27": "GAZİANTEP", "29": "GÜMÜŞHANE", "28": "GİRESUN",
    "30": "HAKKARİ", "31": "HATAY", "32": "ISPARTA", "76": "IĞDIR",
    "46": "KAHRAMANMARAŞ", "78": "KARABÜK", "70": "KARAMAN", "36": "KARS",
    "37": "KASTAMONU", "38": "KAYSERİ", "71": "KIRIKKALE", "39": "KIRKLARELİ",
    "40": "KIRŞEHİR", "41": "KOCAELİ", "42": "KONYA", "43": "KÜTAHYA",
    "79": "KİLİS", "44": "MALATYA", "45": "MANİSA", "47": "MARDİN",
    "33": "MERSİN", "48": "MUĞLA", "49": "MUŞ", "50": "NEVŞEHİR",
    "51": "NİĞDE", "52": "ORDU", "80": "OSMANİYE", "53": "RİZE",
    "54": "SAKARYA", "55": "SAMSUN", "57": "SİNOP", "58": "SİVAS",
    "56": "SİİRT", "59": "TEKİRDAĞ", "60": "TOKAT", "61": "TRABZON",
    "62": "TUNCELİ", "64": "UŞAK", "65": "VAN", "77": "YALOVA",
    "66": "YOZGAT", "67": "ZONGULDAK", "17": "ÇANAKKALE", "18": "ÇANKIRI",
    "19": "ÇORUM", "34": "İSTANBUL", "35": "İZMİR", "63": "ŞANLIURFA",
    "73": "ŞIRNAK",
}
DT_DURUMLAR    = {
    "202": "Doğrudan Temin Duyurusu Yayımlanmış",
    "3":   "Teklifler Değerlendiriliyor",
    "4":   "Doğrudan Temin Sonuçlandırıldı",
    "5":   "Sonuç Bilgileri Gönderildi",
    "15":  "Sonuç Duyurusu Yayımlanmış",
}
EKAP_URL        = "https://ekapv2.kik.gov.tr/ekap/search"
EKAP_API_URL    = "https://ekapv2.kik.gov.tr/b_ihalearama/api/Ihale/GetListByParameters"
CHECK_INTERVAL  = 120       # saniye (varsayılan 2 dakika)

# EKAP "İhale Durumu" filtresi. Lookup servisi (TenderStatusCombo) degerleri:
#   "2" Teklif Vermeye Açık | "3" Teklifler Değerlendiriliyor
#   "4" Teklif Değerlendirme Tamamlanmış | "5" Sözleşme İmzalanmış
#   "6" İptal Edilmiş
# İstek gövdesine ihaleDurumIdList olarak METIN listesi halinde konur.
TENDER_STATUS_OPEN   = "2"
IHALE_DURUM_FILTRESI = [TENDER_STATUS_OPEN]

# EKAP'in Angular arayuzu headless Chromium'da HIC acilmiyor: sayfa 200
# donuyor ama uygulama bootstrap olmuyor, arama API'si (GetListByParameters)
# hic cagrilmiyor. "Yeni headless" (channel='chromium') de ayni sekilde bos
# kaliyor. Bu yuzden izleme gercek bir pencereyle calisir; pencere ekranin
# disina konumlandirilarak kullaniciyi rahatsiz etmesi onlenir.
BG_BROWSER_ARGS = [
    "--window-position=-32000,-32000",
    "--window-size=1600,1000",
]
MAX_HISTORY     = 6000      # hafızada tutulacak maks bildirim sayısı
NEW_ROW_TIMEOUT = 15_000    # ms — yeni satır vurgu süresi

# ── Renk paleti ───────────────────────────────────────────────────────────────
# UNIARCH marka mavisi (logodan alindi: RGB 19,74,142)
C_BRAND    = "#1E5AA8"     # marka lacivertinin bir tik acilmis hali
C_BRAND_LT = "#3D82D1"     # uzerine gelince / secili
C_BRAND_DK = "#14406F"     # basili durum
C_BRAND_SOFT = "#22304A"   # markanin cok soluk hali (secili satir zemini)

# Katmanlar: zemin -> panel -> yuzey -> yukseltilmis. Aralarindaki fark
# bilerek kucuk tutuldu; buyuk kontrast yerine golge hissi veren kademe.
C_BG       = "#10151F"     # en arka zemin
C_PANEL    = "#171D2A"     # kartlar / paneller
C_SURFACE  = "#1E2533"     # ikincil yuzey (giris kutulari, ghost buton)
C_ELEV     = "#28303F"     # uzerine gelince / yukseltilmis yuzey
C_BORDER   = "#2A3242"     # dusuk kontrastli kenarlik

# Uygulama surumu. Guncelleme kontrolu bunu depodaki surum.json ile
# karsilastirir; yeni surum yayinlarken HEM burayi HEM surum.json'u artirin.
SURUM = "1.0.0"

C_ACCENT   = C_BRAND_LT

# Duyuru seridindeki gorselin sigdirilacagi olcu. Gorsel bu kutuya oranini
# koruyarak KUCULTULUR, buyutulmez. Net gorunmesi icin iki kati cozunurlukte
# hazirlanmasi onerilir (bkz. OKUBENI.txt).
DUYURU_GORSEL_EN  = 240
DUYURU_GORSEL_BOY = 56

# BANNER modu: duyuruda yalnizca gorsel varsa (baslik/metin yoksa) gorsel
# tek basina ve cok daha buyuk gosterilir. Icinde okunacak metin bulunan
# reklam afisleri kucuk kutuda okunmuyordu.
DUYURU_BANNER_BOY = 132        # en fazla yukseklik
DUYURU_BANNER_EN  = 1180       # en fazla genislik
DUYURU_DONGU_SN   = 12         # birden fazla duyuru varsa gecis suresi


def _renk_rgb(onaltilik: str) -> tuple:
    """'#1E2533' -> (30, 37, 51). Filigran harmanlamasi icin gerekli."""
    h = (onaltilik or "").lstrip("#")
    if len(h) == 3:
        h = "".join(k * 2 for k in h)
    try:
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    except Exception:
        return (0, 0, 0)
# Vurgu renkleri: doygunlugu dusuk tonlar. Koyu zeminde tam doygun renkler
# titresiyor ve "ucuz" duruyor.
C_GREEN    = "#3DBE7A"
C_GREEN_LT = "#57D694"
C_YELLOW   = "#E0A33E"
C_RED      = "#E06B6B"
C_PURPLE   = "#8E7BD4"
C_PURPLE_LT = "#A594E4"
C_TEXT     = "#DFE5EF"     # saf beyaza yakin degil; goz yormaz
C_TEXT_DIM = "#B4BECD"     # ikincil metin
C_MUTED    = "#8792A5"     # etiketler, ipuclari
C_ROWHI    = C_BRAND_SOFT
C_ROWBASE  = "#171D2A"
C_ROWALT   = "#1B2230"     # zebra desen (fark bilerek cok az)

# Filigranin boyanacagi ton. Koyu zeminde gorunur olmasi icin metin
# renginden alinir; logonun KENDI rengi (siyah cizgi) kullanilmaz.
FILIGRAN_RENGI = C_TEXT

ASSET_DIR  = BASE_DIR / "assets"


# ── Turkce metin normalizasyonu ───────────────────────────────────────────────
# Python'da "İ".lower() -> "i" + U+0307 (birlesen nokta) uretir; bu yuzden
# "ETİ MADEN".lower() icinde "eti maden" ARANAMAZ. Asagidaki katlama hem bu
# sorunu cozer hem de aramayi aksana duyarsiz yapar (isletme -> İŞLETME).
_TR_FOLD_MAP = str.maketrans({
    "İ": "i", "I": "i", "ı": "i",
    "Ş": "s", "ş": "s",
    "Ğ": "g", "ğ": "g",
    "Ü": "u", "ü": "u",
    "Ö": "o", "ö": "o",
    "Ç": "c", "ç": "c",
})


def dt_to_record(it: dict, now) -> dict:
    """EKAP'in E1..E14 alanlarini uygulamanin kayit yapisina cevirir."""
    dtn       = str(it.get("E1") or "").strip()
    adi       = str(it.get("E2") or "-").strip()
    idare     = str(it.get("E3") or "").strip()
    tur       = DT_TURLER.get(str(it.get("E4") or ""), "")
    son_tarih = str(it.get("E7") or "").strip()
    duyuru    = str(it.get("E8") or "").strip()
    durum     = DT_DURUMLAR.get(str(it.get("E9") or ""), "")
    dt_id     = str(it.get("E10") or "")
    idare_id  = str(it.get("E11") or "")
    ilan_var  = bool(it.get("E13"))
    dosya_var = bool(it.get("E14"))
    aciklama  = durum + (" - " + tur if tur else "")
    return {
        "ikn": dtn,
        "ihaleAdi": adi,
        "idareAdi": idare,
        "ihaleTarihSaat": son_tarih,
        "ihaleDurum": str(it.get("E9") or ""),
        "ihaleDurumAciklama": aciklama,
        "dokumanSayisi": 1 if dosya_var else 0,
        "dokumanButonuGosterilsinMi": dosya_var,
        "url": DT_DETAIL_URL.format(idare_id=idare_id, dt_id=dt_id,
                                    ilan=str(ilan_var).lower(),
                                    dosya=str(dosya_var).lower()),
        "il": DT_ILLER.get(str(it.get("E12") or ""), ""),
        "tur": tur,
        "ilanTarihi": duyuru,
        "dt_id": dt_id,
        "dt_idare_id": idare_id,
        "dt_turu": tur,
        "dt_duyuru_tarihi": duyuru,
        "found_at": now.isoformat(),
    }


# ── Arsiv ve belge yardimcilari ───────────────────────────────────────────────
# EKAP "Ihale Dokumani" tek bir PDF degil, ZIP arsivi olarak gelir. Icinde
# ic ice ZIP, .docx teknik sartname, .doc (aslinda HTML) idari sartname ve
# bazen .rar ekler bulunur. Bu yuzden inen dosyanin turu ICERIGINDEN tespit
# edilip acilir; kelime aramasi gercek belgeler uzerinde calisir.
_MAGIC_EXT = [
    (b"PK\x03\x04", ".zip"),
    (b"Rar!", ".rar"),
    (b"%PDF", ".pdf"),
]


def detect_extension(path, fallback=""):
    """Dosya uzantisini icerige (magic bytes) gore belirler.

    EKAP dosyayi bazen uzantisiz bir GUID adiyla veriyor; uzantiya guvenip
    ".pdf" demek ZIP arsivini PDF sanmaya yol aciyordu.
    """
    try:
        with open(path, "rb") as f:
            head = f.read(8)
    except Exception:
        return fallback
    for magic, ext in _MAGIC_EXT:
        if head.startswith(magic):
            return ext
    low = head.lower()
    if low.startswith(b"<html") or low.startswith(b"<!doctype"):
        return ".html"
    return fallback


def find_unrar():
    """WinRAR/UnRAR/7-Zip yolunu bulur (RAR ekleri icin)."""
    exe = shutil.which("unrar") or shutil.which("7z")
    if exe:
        return exe
    adaylar = [
        Path("C:/Program Files/WinRAR/UnRAR.exe"),
        Path("C:/Program Files/WinRAR/WinRAR.exe"),
        Path("C:/Program Files (x86)/WinRAR/UnRAR.exe"),
        Path("C:/Program Files/7-Zip/7z.exe"),
    ]
    for c in adaylar:
        if c.exists():
            return str(c)
    return None


# Office belgeleri (.docx/.xlsx/.pptx) de ZIP formatindadir. Magic byte'a
# bakip "zip" diye icine girilirse belge yuzlerce ic XML parcasina ayrilir.
# Bu yuzden ARSIV sayilma kurali uzantiya da bakar.
_ARCHIVE_SUFFIXES = {".zip", ".rar"}
_DOC_SUFFIXES = {".docx", ".xlsx", ".pptx", ".docm", ".xlsm", ".odt", ".ods"}


def is_archive(path) -> bool:
    """Dosya gercekten acilmasi gereken bir arsiv mi?"""
    sfx = path.suffix.lower()
    if sfx in _DOC_SUFFIXES:
        return False
    if sfx in _ARCHIVE_SUFFIXES:
        return True
    if sfx == "":                       # uzantisiz (GUID) dosya -> icerige bak
        return detect_extension(path) in _ARCHIVE_SUFFIXES
    return False


def extract_archive(path, dest, depth=0):
    """Arsivi dest icine acar; ic ice arsivleri de (en fazla 3 seviye) acar."""
    if depth > 3:
        return []
    produced = []
    ext = detect_extension(path, path.suffix.lower())
    if ext == ".zip" and path.suffix.lower() in _DOC_SUFFIXES:
        return []                       # Office belgesi, arsiv degil

    if ext == ".zip":
        try:
            with zipfile.ZipFile(path) as zf:
                for info in zf.infolist():
                    if info.is_dir():
                        continue
                    ad = re.sub(r'[\\/:*?"<>|]', "_", Path(info.filename).name).strip(". ")
                    if not ad:
                        continue
                    hedef = dest / ad[:120]
                    n = 1
                    while hedef.exists():
                        hedef = dest / f"{Path(ad[:110]).stem}_{n}{Path(ad).suffix}"
                        n += 1
                    with zf.open(info) as src, open(hedef, "wb") as out:
                        shutil.copyfileobj(src, out)
                    produced.append(hedef)
        except Exception as e:
            print(f"[ARSIV] ZIP acilamadi ({path.name}): {e}")
            return produced

    elif ext == ".rar":
        exe = find_unrar()
        if not exe:
            print("[ARSIV] RAR icin WinRAR/UnRAR bulunamadi; dosya oldugu gibi birakildi")
            return produced
        onceki = {f for f in dest.rglob("*") if f.is_file()}
        try:
            if "7z" in Path(exe).name.lower():
                args = [exe, "x", "-y", f"-o{dest}", str(path)]
            else:
                args = [exe, "x", "-y", str(path), str(dest) + "\\"]
            subprocess.run(args, capture_output=True, timeout=300,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except Exception as e:
            print(f"[ARSIV] RAR acilamadi: {e}")
            return produced
        produced = [f for f in dest.rglob("*") if f.is_file() and f not in onceki]
    else:
        return produced

    for f in list(produced):
        if is_archive(f):
            produced += extract_archive(f, dest, depth + 1)
    return produced


def html_to_text(raw: bytes) -> str:
    """HTML/Word-HTML baytlarindan duz metin cikarir."""
    enc = "utf-8"
    mm = re.search(rb'charset=["\']?([\w-]+)', raw[:4000], re.I)
    if mm:
        enc = mm.group(1).decode("ascii", "ignore")
    try:
        txt = raw.decode(enc, "ignore")
    except Exception:
        txt = raw.decode("utf-8", "ignore")
    txt = re.sub(r"(?is)<(script|style).*?</\1>", " ", txt)
    txt = re.sub(r"(?s)<[^>]+>", " ", txt)
    txt = txt.replace("&nbsp;", " ").replace("&amp;", "&")
    txt = txt.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"')
    return re.sub(r"[ \t]+", " ", txt)


def docx_to_text(path) -> str:
    """.docx metnini ek bagimlilik olmadan cikarir (docx = zip + xml)."""
    try:
        with zipfile.ZipFile(path) as z:
            xml = z.read("word/document.xml").decode("utf-8", "ignore")
    except Exception:
        return ""
    xml = re.sub(r"</w:p>", "\n", xml)
    xml = re.sub(r"<[^>]+>", "", xml)
    return xml.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")


def belge_metni(path):
    """Desteklenen belge turlerinden metin cikarir. (metin, tur) doner."""
    ext = detect_extension(path, path.suffix.lower())
    sfx = path.suffix.lower()
    try:
        if ext == ".html" or sfx in (".html", ".htm", ".doc"):
            # EKAP'in .doc dosyalari aslinda Word-HTML'dir
            return html_to_text(path.read_bytes()), "html"
        if sfx == ".docx":
            return docx_to_text(path), "docx"
        if sfx in (".txt", ".csv"):
            return path.read_text("utf-8", errors="ignore"), "metin"
    except Exception as e:
        print(f"[BELGE] {path.name} okunamadi: {e}")
    return "", ""


# ── Arka plan tarayici penceresini gorev cubugundan gizleme ───────────────────
# Pencere ekran disinda ama Windows yine de gorev cubugunda bir simge
# gosteriyor ve tiklaninca hicbir sey acilmiyor (pencere gercekten ekran
# disinda). Cozum: WS_EX_TOOLWINDOW. Pencereyi ShowWindow(SW_HIDE) ile
# tamamen gizlemiyoruz — Chromium gizli pencerede cizimi durdurabilir ve
# EKAP'in ihtiyac duydugu tam da o cizim.
_GWL_EXSTYLE      = -20
_WS_EX_TOOLWINDOW = 0x00000080
_OFFSCREEN_LIMIT  = -30000


def snapshot_window_handles() -> set:
    """Mevcut ust duzey pencerelerin listesi (launch oncesi fotograf)."""
    if sys.platform != "win32":
        return set()
    try:
        import ctypes
        from ctypes import wintypes
        handles = set()

        @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        def _cb(hwnd, _lparam):
            handles.add(int(hwnd))
            return True

        ctypes.windll.user32.EnumWindows(_cb, 0)
        return handles
    except Exception:
        return set()


def hide_new_windows_from_taskbar(before: set) -> int:
    """Launch sonrasi ACILAN ve ekran disinda olan pencereleri gizler.

    Yalnizca 'before' fotografinda olmayan pencerelere dokunur; kullanicinin
    kendi tarayici/uygulama pencereleri asla etkilenmez.
    """
    if sys.platform != "win32":
        return 0
    try:
        import ctypes
        from ctypes import wintypes
        u32 = ctypes.windll.user32
        touched = 0

        @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        def _cb(hwnd, _lparam):
            nonlocal touched
            h = int(hwnd)
            if h in before:
                return True
            rect = wintypes.RECT()
            if not u32.GetWindowRect(hwnd, ctypes.byref(rect)):
                return True
            if rect.left > _OFFSCREEN_LIMIT:      # ekran disinda degil, dokunma
                return True
            ex = u32.GetWindowLongW(hwnd, _GWL_EXSTYLE)
            u32.SetWindowLongW(hwnd, _GWL_EXSTYLE, ex | _WS_EX_TOOLWINDOW)
            touched += 1
            return True

        u32.EnumWindows(_cb, 0)
        return touched
    except Exception:
        return 0


def tr_fold_pos(value) -> str:
    """tr_fold'un konum koruyan hali: cikan metin girisle AYNI UZUNLUKTA.

    Baglam cikarirken bulunan konumu orijinal metne geri uygulayacagimiz
    icin uzunlugun degismemesi sart (tr_fold birlesen noktayi siliyor).
    """
    if not value:
        return ""
    s = str(value).translate(_TR_FOLD_MAP)
    return "".join(c.lower() if len(c.lower()) == 1 else c for c in s)


def baglam_listesi(metin: str, kelime: str, once: int = 60, sonra: int = 160,
                   en_fazla: int = 15) -> list:
    """Kelimenin gectigi yerleri ETRAFINDAKI metinle birlikte dondurur.

    Eskiden eslesen satirin ilk 200 karakteri gosteriliyordu; satir uzun
    oldugunda aranan kelime hic gorunmuyordu. Simdi kesit kelimenin
    etrafindan aliniyor.
    """
    if not metin or not kelime:
        return []
    hedef = tr_fold_pos(metin)
    aranan = tr_fold_pos(kelime)
    if not aranan:
        return []

    sonuc, i = [], 0
    while len(sonuc) < en_fazla:
        k = hedef.find(aranan, i)
        if k < 0:
            break
        bas = max(0, k - once)
        bit = min(len(metin), k + len(aranan) + sonra)
        parca = " ".join(metin[bas:bit].split())
        if bas > 0:
            parca = "... " + parca
        if bit < len(metin):
            parca = parca + " ..."
        sonuc.append(parca)
        i = k + len(aranan)
    return sonuc


def tr_lower_char(ch: str) -> str:
    """Tek harf icin DOGRU Turkce kucultme: İ->i, I->ı, digerleri normal.

    Burada tr_fold kullanilamaz: o 'ş'yi 's'ye cevirdigi icin CAPTCHA
    cevabini bozar. Python'un duz .lower() metodu ise 'İ' harfini
    'i + birlesen nokta' yapip iki karakterlik hatali cevap uretir.
    """
    if ch == "İ":
        return "i"
    if ch == "I":
        return "ı"
    return ch.lower()


def tr_fold(value) -> str:
    """Arama/karsilastirma anahtari: buyuk-kucuk ve Turkce aksan farkini siler."""
    if not value:
        return ""
    s = str(value).translate(_TR_FOLD_MAP).lower()
    # Onceki adimlardan artakalan birlesen noktalari (U+0307) temizle.
    if "̇" in s:
        s = unicodedata.normalize("NFKD", s).replace("̇", "")
    return s


# ══════════════════════════════════════════════════════════════════════════════
class StateManager:
    """Durum dosyasi okuma/yazma — bilinen IKN'ler ve bildirim gecmisi."""

    def __init__(self, mode: str = MODE_IHALE):
        # Durum hem izleme thread'i hem de arayuz tarafindan degistiriliyor.
        self._lock = threading.RLock()
        self.mode = mode if mode in MODE_STATE_FILES else MODE_IHALE
        self.state_file = MODE_STATE_FILES[self.mode]
        self.log_file = MODE_LOG_FILES[self.mode]
        self._d = self._load()

    def _load(self) -> dict:
        if not self.state_file.exists():
            return {"ikns": [], "notifications": [], "last_check": None}
        try:
            with open(self.state_file, encoding="utf-8") as f:
                d = json.load(f)
            d.setdefault("notifications", [])
            d.setdefault("ikns", [])
            d.setdefault("last_check", None)
            if not d.get("last_check") and d.get("last_update"):
                d["last_check"] = d.get("last_update")
            self._migrate_legacy_notifications(d)
            return d
        except Exception:
            return {"ikns": [], "notifications": [], "last_check": None}

    def _migrate_legacy_notifications(self, d: dict):
        """Populate notifications for older state files that only stored IKN list."""
        if d.get("notifications"):
            return

        notifications = self._notifications_from_log()

        # Fallback: if log is missing or incomplete, create minimal rows from known IKNs.
        if not notifications:
            now_iso = datetime.now().isoformat()
            for ikn in d.get("ikns", []):
                notifications.append({
                    "ikn": ikn,
                    "ihaleAdi": "(gecmis kayit)",
                    "idareAdi": "",
                    "ihaleTarihSaat": "",
                    "url": f"{EKAP_URL}/{str(ikn).replace('/', '_')}",
                    "found_at": now_iso,
                })

        # Keep only known IKN rows and cap history size.
        known = set(d.get("ikns", []))
        d["notifications"] = [
            n for n in notifications
            if str(n.get("ikn", "")).strip() in known
        ][:MAX_HISTORY]

    def _notifications_from_log(self) -> list:
        rows = []
        if not self.log_file.exists():
            return rows

        try:
            with open(self.log_file, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    parts = [p.strip() for p in line.split("|", 2)]
                    if len(parts) < 3:
                        continue
                    ts, ikn, name = parts
                    rows.append({
                        "ikn": ikn,
                        "ihaleAdi": name,
                        "idareAdi": "",
                        "ihaleTarihSaat": "",
                        "url": f"{EKAP_URL}/{str(ikn).replace('/', '_')}",
                        "found_at": ts,
                    })
        except Exception:
            return []

        # Newest first for table insertion logic.
        rows.reverse()
        return rows

    def save(self):
        # Once gecici dosyaya yaz, sonra yerine tasi: yazma sirasinda program
        # kapanirsa ekap_state.json yarim/bozuk kalmaz.
        with self._lock:
            try:
                tmp = self.state_file.with_name(self.state_file.name + ".tmp")
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(self._d, f, ensure_ascii=False, indent=2)
                tmp.replace(self.state_file)
            except Exception as e:
                print(f"[STATE] Kayit hatasi: {e}")

    def clear_notifications(self):
        with self._lock:
            self._d["notifications"] = []

    @property
    def known_ikns(self) -> set:
        with self._lock:
            return set(self._d["ikns"])

    def add_ikn(self, ikn: str):
        with self._lock:
            if ikn not in self._d["ikns"]:
                self._d["ikns"].append(ikn)

    def add_notification(self, n: dict):
        with self._lock:
            self._d["notifications"].insert(0, n)
            self._d["notifications"] = self._d["notifications"][:MAX_HISTORY]

    def replace_notifications(self, rows: list):
        with self._lock:
            self._d["notifications"] = list(rows)[:MAX_HISTORY]

    def update_notification_fields(self, ikn: str, fields: dict) -> bool:
        """Fill missing notification fields for an existing IKN.

        Only writes when current value is empty/placeholder and new value is meaningful.
        """
        if not ikn:
            return False

        for n in self._d.get("notifications", []):
            if str(n.get("ikn", "")).strip() != str(ikn).strip():
                continue

            changed = False
            for key, raw_val in fields.items():
                cur = str(n.get(key, "") or "").strip()
                new = str(raw_val or "").strip()
                if not new or new == "—":
                    continue
                if cur in {"", "—", "(gecmis kayit)"}:
                    n[key] = new
                    changed = True
            return changed

        return False

    def mark_checked(self):
        self._d["last_check"] = datetime.now().isoformat()

    @property
    def last_check(self):
        return self._d.get("last_check")

    @property
    def notifications(self) -> list:
        # Kopya dondur: izleme thread'i listeyi gezerken arayuz onu
        # temizlerse "list changed size during iteration" olusmasin.
        with self._lock:
            return list(self._d.get("notifications", []))


# ══════════════════════════════════════════════════════════════════════════════
class MonitorThread(threading.Thread):
    """Arka planda Playwright ile EKAP'i duzenli olarak kontrol eder."""

    def __init__(self, state: StateManager, q: queue.Queue, interval: int,
                 mode: str = MODE_IHALE):
        super().__init__(daemon=True, name="EKAPMonitor")
        self.store         = state
        self.q             = q
        self.interval      = interval
        self.mode          = mode
        self._stop         = threading.Event()
        self._manual_check = threading.Event()

    def stop(self):
        self._stop.set()
        self._manual_check.set()  # wake up sleep loop

    def trigger_check(self):
        """Interrupt the wait period and run a check immediately."""
        self._manual_check.set()

    def run(self):
        asyncio.run(self._loop())

    @staticmethod
    def _pick(item: dict, *keys, default=""):
        for k in keys:
            v = item.get(k)
            if v is None:
                continue
            s = str(v).strip()
            if s:
                return s
        return default

    @staticmethod
    async def _solve_captcha_async(page) -> None:
        """Auto-solve any EKAP captcha (text or numeric) in async context."""
        try:
            txt = await page.locator("body").inner_text(timeout=2500)
        except Exception:
            return
        txt_lower = txt.lower()

        has_captcha = any(s in txt_lower for s in [
            "kelimesinin", "sorunun cevab", "küçük olan", "kucuk olan",
            "büyük olan", "buyuk olan", "sayıyı yazınız", "sayiyi yaziniz"
        ])
        if not has_captcha:
            return

        answer = None

        # Numeric comparison captcha
        is_smaller = any(s in txt_lower for s in ["küçük olan", "kucuk olan"])
        is_larger  = any(s in txt_lower for s in ["büyük olan", "buyuk olan"])
        if is_smaller or is_larger:
            numbers = []
            for m in re.finditer(r"\b(\d{1,6}(?:[.,]\d{1,4})?)\b", txt):
                try:
                    numbers.append(float(m.group(1).replace(",", ".")))
                except Exception:
                    pass
            numbers = sorted(set(n for n in numbers if 0 < n < 100000))
            if len(numbers) >= 2:
                val = numbers[0] if is_smaller else numbers[-1]
                answer = str(int(val)) if val == int(val) else f"{val:.2f}".rstrip("0").rstrip(".")
        else:
            # Text captcha
            m = re.search(r"(\w+)\s+kelimesinin\s+son\s+harfi", txt, re.IGNORECASE)
            if m:
                answer = tr_lower_char(m.group(1)[-1])
            if not answer:
                m = re.search(r"(\w+)\s+kelimesinin\s+(?:ilk|bir(?:inci)?)\s+harfi", txt, re.IGNORECASE)
                if m:
                    answer = tr_lower_char(m.group(1)[0])
            if not answer:
                m = re.search(r"(\w+)\s+kelimesinin\s+ka[çc]\s+harfi", txt, re.IGNORECASE)
                if m:
                    answer = str(len(m.group(1)))

        if not answer:
            return

        try:
            inp = page.locator("input[type='text'], input:not([type])")
            if await inp.count() > 0:
                await inp.first.fill(answer)
                await asyncio.sleep(0.3)
                for btn_sel in [
                    "button:has-text('Doğrula')",
                    "button:has-text('Dogrula')",
                    "button[type='submit']",
                    "input[type='submit']",
                    "button",
                ]:
                    try:
                        await page.locator(btn_sel).first.click(timeout=3000)
                        break
                    except Exception:
                        continue
                await asyncio.sleep(1.5)
        except Exception:
            pass

    async def _loop(self):
        if not HAS_PLAYWRIGHT:
            self.q.put(("STATUS",
                "Playwright kurulu degil! Calistirin: pip install playwright && "
                "python -m playwright install chromium",
                "error"))
            return

        if self.mode == MODE_DT:
            await self._loop_dt()
            return

        self.q.put(("STATUS", "Tarayici baslatiliyor...", "info"))
        try:
            async with async_playwright() as pw:
                browser = None
                fail_streak = 0

                while not self._stop.is_set():
                    try:
                        if browser is None:
                            # headless=False zorunlu — BG_BROWSER_ARGS'a bak.
                            browser = await pw.chromium.launch(
                                headless=False, args=BG_BROWSER_ARGS)
                            self.q.put(("STATUS", "Izleme aktif", "ok"))

                        # Her kontrol icin TEMIZ bir oturum. Ayni sayfa uzun
                        # sure kullanildiginda EKAP'in Angular uygulamasi bir
                        # sure sonra bootstrap olmayi birakiyor ve sayfa bos
                        # kaliyordu; boylece her tur sifirdan basliyor.
                        # Tarayici penceresi launch'ta degil, ilk sayfa
                        # acilinca olusuyor; bu yuzden fotografi tam burada
                        # cekip sayfa acildiktan hemen sonra gizliyoruz.
                        # Dar zaman araligi + "sadece ekran disindakiler"
                        # kurali, kullanicinin kendi pencerelerine
                        # dokunulmamasini garanti eder.
                        win_before = snapshot_window_handles()
                        ctx = await browser.new_context(
                            viewport={"width": 1600, "height": 1000})
                        try:
                            page = await ctx.new_page()
                            await asyncio.sleep(0.5)
                            hide_new_windows_from_taskbar(win_before)
                            ok = await self._check(page)
                        finally:
                            try:
                                await ctx.close()
                            except Exception:
                                pass

                        fail_streak = 0 if ok else fail_streak + 1

                    except Exception as e:
                        fail_streak += 1
                        self.q.put(("STATUS", f"Kontrol hatasi: {e}", "warn"))

                    # Ust uste basarisizlikta tarayiciyi komple yenile (kendini
                    # onarma): takilan bir tarayici izlemeyi sessizce oldurmesin.
                    if fail_streak >= 3 and browser is not None:
                        self.q.put(("STATUS",
                            "Ust uste basarisiz kontrol — tarayici yenileniyor...",
                            "warn"))
                        try:
                            await browser.close()
                        except Exception:
                            pass
                        browser = None
                        fail_streak = 0

                    self._manual_check.clear()
                    for _ in range(self.interval * 10):
                        if self._stop.is_set() or self._manual_check.is_set():
                            break
                        await asyncio.sleep(0.1)

                if browser is not None:
                    await browser.close()

        except Exception as e:
            self.q.put(("STATUS", f"Tarayici hatasi: {e}", "error"))

        self.q.put(("STATUS", "Izleme durduruldu", "stopped"))

    async def _loop_dt(self):
        """Dogrudan Temin dongusu.

        Eski EKAP'in .ashx ucu duz GET + JSON dondurdugu icin sayfayi render
        etmeye gerek yok: bu mod HEADLESS, pencere acmadan calisir. (Ihale
        modu, Angular uygulamasi headless'ta bootstrap olmadigi icin gorunur
        pencere kullanmak zorunda.)
        """
        self.q.put(("STATUS", "Dogrudan Temin izleme baslatiliyor...", "info"))
        try:
            async with async_playwright() as pw:
                browser = await pw.chromium.launch(headless=True)
                ctx = await browser.new_context()
                self.q.put(("STATUS", "Izleme aktif (Dogrudan Temin)", "ok"))

                while not self._stop.is_set():
                    try:
                        await self._check_dt(ctx)
                    except Exception as e:
                        self.q.put(("STATUS", f"Kontrol hatasi: {e}", "warn"))

                    self._manual_check.clear()
                    for _ in range(self.interval * 10):
                        if self._stop.is_set() or self._manual_check.is_set():
                            break
                        await asyncio.sleep(0.1)

                await browser.close()
        except Exception as e:
            self.q.put(("STATUS", f"Tarayici hatasi: {e}", "error"))
        self.q.put(("STATUS", "Izleme durduruldu", "stopped"))

    @staticmethod
    def _dt_url(page_index: int, order_by: int = 10) -> str:
        """orderBy: 10 = DTN azalan (en yeni), 4 = son teklif tarihine gore."""
        return (f"{DT_DATA_URL}?ES=&ihaleidListesi=&dtBilgiSecim=1&metot=dtAra"
                f"&orderBy={order_by}&pageIndex={page_index}"
                f"&dtDurum={DT_STATUS_OPEN}")

    @staticmethod
    def _dt_to_record(it: dict, now) -> dict:
        return dt_to_record(it, now)

    async def _dt_sayfalari(self, ctx, sayfa_sayisi: int, order_by: int,
                           bilgi: str = "") -> list:
        """Belirtilen sayida sayfayi ceker; yeni kayit gelmeyince erken biter."""
        items, gorulen = [], set()
        for i in range(1, sayfa_sayisi + 1):
            try:
                resp = await ctx.request.get(self._dt_url(i, order_by),
                                             timeout=60_000)
                if resp.status != 200:
                    break
                data = await resp.json()
            except Exception:
                break
            arr = data.get("yeniDogrudanTeminAramaResultList") or []
            if not isinstance(arr, list) or not arr:
                break
            yeni = [a for a in arr
                    if str(a.get("E1", "")).strip() not in gorulen]
            gorulen.update(str(a.get("E1", "")).strip() for a in arr)
            items.extend(arr)
            if not yeni:                      # ayni kayitlar dondu -> son
                break
            if bilgi and i % 5 == 0:
                self.q.put(("STATUS",
                    f"{bilgi} — {len(gorulen)} duyuru, sayfa {i}", "info"))
        return items

    async def _check_dt(self, ctx) -> bool:
        # Her taramada en yeni duyurular; belirli araliklarla da teklif
        # tarihi gecmemis TUM duyurular taranir.
        simdi = datetime.now()
        son_tam = getattr(self, "_son_tam_tarama", None)
        tam_zamani = (son_tam is None or
                      (simdi - son_tam).total_seconds() >= DT_TAM_ARALIK_DK * 60)

        if tam_zamani:
            self.q.put(("STATUS",
                "Tüm açık duyurular taranıyor (teklif tarihi geçmemiş)...",
                "info"))
            items = await self._dt_sayfalari(ctx, DT_TAM_SAYFA, 4,
                                             "Tüm duyurular taranıyor")
            if items:
                self._son_tam_tarama = simdi
        else:
            self.q.put(("STATUS", "Yeni duyurular kontrol ediliyor...", "info"))
            items = await self._dt_sayfalari(ctx, DT_HIZLI_SAYFA, 10)

        if not items:
            ts = datetime.now().strftime("%H:%M:%S")
            self.q.put(("STATUS",
                f"Son kontrol: {ts}  |  DT verisi alinamadi, mevcut liste korunuyor",
                "warn"))
            return False

        now = datetime.now()
        known = self.store.known_ikns
        previous = {
            str(n.get("ikn", "")).strip(): n
            for n in self.store.notifications
            if str(n.get("ikn", "")).strip()
        }

        latest, new_items, new_count, seen = [], [], 0, set()
        for it in items:
            dtn = str(it.get("E1") or "").strip()
            if not dtn or dtn in seen:
                continue
            seen.add(dtn)
            if str(it.get("E9") or "") != DT_STATUS_OPEN:
                continue

            rec = self._dt_to_record(it, now)
            is_new = dtn not in known
            if is_new:
                known.add(dtn)
                self.store.add_ikn(dtn)
                new_count += 1
            rec["found_at"] = previous.get(dtn, {}).get("found_at") or now.isoformat()
            latest.append(rec)
            if is_new:
                new_items.append(rec)

        # Onceki turlardan tasinan kayitlardan teklif suresi gecenleri at:
        # kullanici yalnizca teklif verilebilir duyurulari gormek istiyor.
        carried = [n for n in self.store.notifications
                   if str(n.get("ikn", "")).strip() not in seen
                   and not teklif_suresi_gecti(n)]
        self.store.replace_notifications(latest + carried)
        self.store.mark_checked()
        self.store.save()

        self._record_new_items(new_items)
        self.q.put(("NOTIFICATION_REFRESH", list(self.store.notifications)))
        self.q.put(("STATUS",
            f"Son kontrol: {now.strftime('%H:%M:%S')}  |  Acik duyuru: {len(latest)}"
            f"  |  Yeni: {new_count}  |  Listede: {len(self.store.notifications)}"
            f"  |  Toplam takip: {len(self.store.known_ikns)}", "ok"))
        return True

    async def _check(self, page) -> bool:
        """Bir kontrol turu calistirir. Veri alinabildiyse True doner."""
        self.q.put(("STATUS", "EKAP sayfasi yukleniyor...", "info"))

        # Tam tarama zamani mi? (ihale tarihi gecmemis TUM ihaleler)
        simdi = datetime.now()
        son_tam = getattr(self, "_son_tam_tarama_ihale", None)
        tam_zamani = (son_tam is None or
                      (simdi - son_tam).total_seconds() >= IHALE_TAM_ARALIK_DK * 60)

        async def _fetch_items_once(tam: bool) -> list:
            sayfa_verisi = {"son": None}
            durum = {"skip": 0}

            async def on_response(resp):
                if "GetListByParameters" in resp.url and resp.status == 200:
                    try:
                        data = await resp.json()
                        arr = (data.get("list") or data.get("result")
                               or data.get("data") or [])
                        if isinstance(arr, list):
                            sayfa_verisi["son"] = arr
                    except Exception:
                        pass

            async def sayfa_ayarla(route, request):
                try:
                    body = json.loads(request.post_data or "{}")
                    body["paginationSkip"] = durum["skip"]
                    body["paginationTake"] = 100
                    # Sadece "Teklif Vermeye Açık" ihaleler gelsin.
                    body["ihaleDurumIdList"] = list(IHALE_DURUM_FILTRESI)
                    headers = dict(request.headers)
                    headers["content-type"] = "application/json"
                    await route.continue_(post_data=json.dumps(body), headers=headers)
                except Exception:
                    await route.continue_()

            pattern = "**/GetListByParameters"
            toplam, gorulen = [], set()
            await page.route(pattern, sayfa_ayarla)
            page.on("response", on_response)
            try:
                try:
                    await page.goto(EKAP_URL, wait_until="networkidle", timeout=90_000)
                except Exception:
                    pass
                await MonitorThread._solve_captcha_async(page)
                # Sabit bekleme yetmiyordu: networkidle bazen erken donuyor ve
                # liste istegi henuz gitmemis oluyordu ("veri bos geldi").
                # Listenin gercekten dolmasini bekle.
                try:
                    await page.wait_for_selector("span.ikn", timeout=60_000)
                except Exception:
                    pass
                for _ in range(40):
                    if sayfa_verisi["son"] is not None:
                        break
                    await asyncio.sleep(0.25)

                ilk = sayfa_verisi["son"] or []
                toplam.extend(ilk)
                gorulen.update(str(a.get("ikn", "")).strip() for a in ilk)

                if tam and ilk:
                    try:
                        await page.evaluate(
                            "() => document.querySelectorAll('ekap-tutorial')"
                            ".forEach(e => e.remove())")
                    except Exception:
                        pass
                    # Sayfalama sitenin kendi "Filtrele" dugmesini tetikleyerek
                    # yapiliyor; dugme hazir olmadan tiklanirsa dongu sessizce
                    # ilk sayfada kaliyordu.
                    try:
                        await page.wait_for_selector("span.ikn", timeout=45_000)
                        await page.wait_for_selector(
                            "button:has-text('Filtrele')", timeout=30_000)
                    except Exception:
                        self.q.put(("STATUS",
                            "Sayfalama baslatilamadi (Filtrele dugmesi yok) — "
                            "yalnizca ilk sayfa alindi", "warn"))
                        return toplam
                    adim = len(ilk)
                    bitis = time.monotonic() + IHALE_TAM_SURE_SN
                    for i in range(1, IHALE_TAM_SAYFA):
                        if time.monotonic() > bitis:
                            self.q.put(("STATUS",
                                f"Sayfalama sure sinirina ulasti "
                                f"({len(gorulen)} ihale alindi)", "warn"))
                            break
                        durum["skip"] = i * adim
                        sayfa_verisi["son"] = None
                        try:
                            await page.locator(
                                "button:has-text('Filtrele')").first.click(timeout=8_000)
                        except Exception:
                            self.q.put(("STATUS",
                                f"Sayfalama durdu ({len(gorulen)} ihale alindi)",
                                "warn"))
                            break
                        for _ in range(40):
                            await asyncio.sleep(0.25)
                            if sayfa_verisi["son"] is not None:
                                break
                        arr = sayfa_verisi["son"] or []
                        yeni = [a for a in arr
                                if str(a.get("ikn", "")).strip() not in gorulen]
                        gorulen.update(str(a.get("ikn", "")).strip() for a in arr)
                        toplam.extend(yeni)
                        if not arr or not yeni:
                            break
                        if i % 5 == 0:
                            self.q.put(("STATUS",
                                f"Tüm açık ihaleler taranıyor "
                                f"({len(gorulen)} ihale, sayfa {i})...", "info"))
            finally:
                page.remove_listener("response", on_response)
                await page.unroute(pattern, sayfa_ayarla)
            return toplam

        if tam_zamani:
            self.q.put(("STATUS",
                "Tüm açık ihaleler taranıyor (ihale tarihi geçmemiş)...", "info"))
        items = await _fetch_items_once(tam_zamani)
        if items and tam_zamani:
            self._son_tam_tarama_ihale = simdi
        if not items:
            self.q.put(("STATUS", "EKAP verisi ilk denemede bos geldi, tekrar deneniyor...", "warn"))
            items = await _fetch_items_once(False)

        if not isinstance(items, list) or not items:
            now = datetime.now().strftime("%H:%M:%S")
            self.q.put(("STATUS", f"Son kontrol: {now}  |  EKAP verisi alinamadi, mevcut liste korunuyor", "warn"))
            return False

        now = datetime.now()
        known = self.store.known_ikns
        previous = {
            str(n.get("ikn", "")).strip(): n
            for n in self.store.notifications
            if str(n.get("ikn", "")).strip()
        }

        latest_notifications = []
        new_items = []
        new_count = 0
        seen_batch_ikns = set()
        # Not: burada eskiden [:100] siniri vardi; tam tarama binlerce ihale
        # getirdiginde ilk 100'u disindakiler sessizce dusuyordu.
        for item in items:
            ikn = self._pick(item, "ikn")
            if not ikn:
                continue
            if ikn in seen_batch_ikns:
                continue
            seen_batch_ikns.add(ikn)

            adi = self._pick(item, "ihaleAdi", "ihale_adi", "ad", default="—")
            idare = self._pick(item, "idareAdi", "idare_adi", "idare", "kurumAdi", default="")
            tarih = self._pick(item, "ihaleTarihSaat", "ihaleTarihi", "tarih", default="")
            dok_sayi = int(item.get("dokumanSayisi") or 0)
            dok_btn = bool(item.get("dokumanButonuGosterilsinMi"))
            durum_id   = int(item.get("ihaleDurum") or 0)
            durum_text = self._pick(item, "ihaleDurumAciklama", default="")

            # Sadece "Teklif Vermeye Açık" ihaleler. Sunucu filtresi zaten
            # bunu yapiyor; burasi ikinci guvenlik katmani. Durum KODUNA
            # bakmak metin karsilastirmasindan saglam.
            durum_kodu = str(item.get("ihaleDurum") or "").strip()
            if durum_kodu:
                if durum_kodu != TENDER_STATUS_OPEN:
                    continue
            elif durum_text and "acik" not in tr_fold(durum_text):
                continue

            is_new = ikn not in known
            if is_new:
                known.add(ikn)
                self.store.add_ikn(ikn)
                new_count += 1

            old = previous.get(ikn, {})
            found_at = old.get("found_at") or now.isoformat()
            record = {
                "ikn": ikn,
                "ihaleAdi": adi,
                "idareAdi": idare,
                "ihaleTarihSaat": tarih,
                "ihaleDurum": durum_id,
                "ihaleDurumAciklama": durum_text,
                "dokumanSayisi": dok_sayi,
                "dokumanButonuGosterilsinMi": dok_btn,
                "il": self._pick(item, "ihaleIlAdi", "ilAdi", default=""),
                "tur": self._pick(item, "ihaleTipAciklama", "ihaleTuruAciklama",
                                  default=""),
                "url": f"{EKAP_URL}/{ikn.replace('/', '_')}",
                "found_at": found_at,
            }
            latest_notifications.append(record)
            if is_new:
                new_items.append(record)

        # Gecmisi KORU: API yalnizca son 100 kaydi donduruyor. Duz replace
        # yapilirsa bu pencerenin disina dusen her ihale listeden siliniyordu.
        # Bu partide hic gorulmeyen eski kayitlar altta saklanir; durumu artik
        # "acik" olmadigi icin elenenler ise bilerek dusurulur.
        carried = [
            n for n in self.store.notifications
            if str(n.get("ikn", "")).strip() not in seen_batch_ikns
            and not teklif_suresi_gecti(n)
        ]
        self.store.replace_notifications(latest_notifications + carried)
        self.store.mark_checked()
        self.store.save()

        self._record_new_items(new_items)
        self.q.put(("NOTIFICATION_REFRESH", list(self.store.notifications)))

        ts = now.strftime("%H:%M:%S")
        shown = len(latest_notifications)
        total = len(self.store.known_ikns)
        self.q.put(("STATUS",
            f"Son kontrol: {ts}  |  Acik ihale: {shown}  |  Yeni: {new_count}"
            f"  |  Listede: {len(self.store.notifications)}  |  Toplam takip: {total}",
            "ok"))
        return True

    def _record_new_items(self, new_items: list):
        """Yeni ihaleleri log dosyasina yaz ve masaustu bildirimi tetikle."""
        if not new_items:
            return

        try:
            with open(self.store.log_file, "a", encoding="utf-8") as f:
                for n in new_items:
                    ts = n.get("found_at", datetime.now().isoformat())
                    f.write(f"{ts} | {n.get('ikn','')} | {n.get('ihaleAdi','')}\n")
        except Exception as e:
            print(f"[LOG] Yazilamadi: {e}")

        # Ilk calistirmada 100 kayit birden yeni olabilir; o zaman tek ozet
        # bildirim gonder, kullaniciyi 100 toast ile bogma.
        if len(new_items) <= 5:
            for n in new_items:
                self.q.put(("NEW_ITEM", n))
        else:
            self.q.put(("NEW_ITEM", {
                "ihaleAdi": f"{len(new_items)} yeni ihale bulundu",
                "idareAdi": "Ayrintilar icin uygulamayi acin",
                "url": EKAP_URL,
            }))


# ══════════════════════════════════════════════════════════════════════════════
class EKAPApp(tk.Tk):
    """Ana masaustu penceresi."""

    def __init__(self, mode: str = MODE_IHALE):
        super().__init__()
        self.mode = mode if mode in MODE_LABELS else MODE_IHALE
        self.title(f"EKAP Izleyici — {MODE_LABELS[self.mode]}")
        self.geometry("1100x640")
        self.minsize(750, 460)
        self.configure(bg=C_BG)
        self._urls = {}
        self._filtered_urls = {}
        self._all_notifications = []
        self._downloading = False
        self._last_selected_iid = None

        self.store   = StateManager(self.mode)
        self._q      = queue.Queue()
        self._thread = None
        self._interval = tk.IntVar(value=CHECK_INTERVAL)
        # Varsayilan KAPALI: acikken listede gezinmek bile her satirda gorunur
        # bir tarayici acip indirme akisi baslatiyordu.
        self._auto_download_var = tk.BooleanVar(value=False)
        self._ocr_var = tk.BooleanVar(value=False)
        self._pdf_keywords_var = tk.StringVar()
        self._keywords_var = tk.StringVar()
        self._date_from_var = tk.StringVar()
        self._date_to_var = tk.StringVar()
        self._live_search_var = tk.StringVar()
        self._deep_search_var = tk.BooleanVar(value=False)
        # Tur suzgeci: hicbiri isaretli degilse HEPSI gosterilir.
        self._tur_vars = {ad: tk.BooleanVar(value=False)
                          for ad in ("Mal", "Hizmet", "Yapım", "Danışmanlık")}
        # Ihale modunda "found_at" sutunu bulunmadigi icin varsayilan
        # siralama ihale tarihine gore yapilir.
        self._live_sort_col = ("found_at" if mode == MODE_DT else "ihale_tarihi")
        self._live_sort_asc = False  # newest first by default

        self._build_ui()
        self._load_history()
        self._start_monitor()

        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self._poll()

    # ── Arayuz insasi ─────────────────────────────────────────────────────────
    # ── Kucuk arayuz yardimcilari ─────────────────────────────────────────
    def _btn(self, parent, text, command, kind="ghost", bold=False, pad=12):
        """Tutarli gorunumlu, uzerine gelince renk degistiren buton."""
        renkler = {
            "primary": (C_BRAND, C_BRAND_LT, "#ffffff"),
            "success": (C_GREEN, C_GREEN_LT, "#08240F"),
            "accent":  (C_PURPLE, C_PURPLE_LT, "#ffffff"),
            "ghost":   (C_SURFACE, C_ELEV, C_TEXT_DIM),
            # "quiet": zemine karisan, yalnizca uzerine gelince beliren
            # dugme. Ikincil eylemler icin (yardim, kapat, temizle).
            "quiet":   (C_PANEL, C_SURFACE, C_MUTED),
        }
        bg, hover, fg = renkler.get(kind, renkler["ghost"])
        b = tk.Button(parent, text=text, command=command, bg=bg, fg=fg,
                      relief="flat", bd=0, padx=pad, pady=5, cursor="hand2",
                      activebackground=hover, activeforeground=fg,
                      font=("Segoe UI", 9, "bold" if bold else "normal"))
        b.bind("<Enter>", lambda e, w=b, c=hover: w.config(bg=c))
        b.bind("<Leave>", lambda e, w=b, c=bg: w.config(bg=c))
        return b

    def _stat_card(self, parent, baslik, deger="—", renk=None, cizgi=None):
        """Ust seritteki sayi kartlarindan biri.

        Kartlar ESIT GENISLIKTE. Eskiden genislik metne gore degisiyordu ve
        sayi degistikce kartlar oynuyordu; gozun sabit bir yeri kalmiyordu.
        Sol kenardaki ince renk cizgisi kartlari birbirinden ayirir.
        """
        dis = tk.Frame(parent, bg=C_BORDER, width=170, height=64)
        dis.pack(side="left", padx=(0, 10))
        dis.pack_propagate(False)

        # Sol vurgu cizgisi (2 piksel) + govde
        tk.Frame(dis, bg=cizgi or C_BORDER, width=2).pack(side="left", fill="y")
        kart = tk.Frame(dis, bg=C_PANEL)
        kart.pack(side="left", fill="both", expand=True)

        ic = tk.Frame(kart, bg=C_PANEL)
        ic.pack(fill="both", expand=True, padx=14, pady=10)
        lbl = tk.Label(ic, text=deger, bg=C_PANEL, fg=renk or C_TEXT,
                       font=("Segoe UI", 16, "bold"), anchor="w")
        lbl.pack(anchor="w")
        tk.Label(ic, text=baslik.upper(), bg=C_PANEL, fg=C_MUTED,
                 font=("Segoe UI", 7, "bold"), anchor="w").pack(anchor="w")
        return lbl

    # ── Guncelleme ────────────────────────────────────────────────────────
    def _guncelleme_seridi_kur(self):
        """Yeni surum varsa gosterilecek serit. Bastan gizlidir.

        Kontrol ACILISTA BIR KEZ ve arka planda yapilir. Ag yoksa sessiz
        kalir: her acilista hata penceresi cikmasi kullaniciyi bunaltir.
        """
        self._guncelleme_kap = tk.Frame(self, bg=C_BG, padx=18)
        self._guncelleme_kap.pack(fill="x")
        self._guncelleme_bilgi = None
        if guncelleme is None or duyuru is None:
            return
        adres = duyuru.ayarlari_oku().get("guncelleme_adresi") or ""
        if not adres:
            return

        def bitince(bilgi, hata):
            if bilgi:
                try:
                    self.after(0, lambda: self._guncelleme_goster(bilgi))
                except Exception:
                    pass

        self.after(2500, lambda: guncelleme.arka_planda_kontrol(
            adres, SURUM, bitince))

    def _guncelleme_goster(self, bilgi: dict):
        for w in self._guncelleme_kap.winfo_children():
            w.destroy()
        self._guncelleme_bilgi = bilgi

        dis = tk.Frame(self._guncelleme_kap, bg=C_BORDER)
        dis.pack(fill="x", pady=(12, 0))
        tk.Frame(dis, bg=C_YELLOW, width=3).pack(side="left", fill="y")
        serit = tk.Frame(dis, bg=C_PANEL)
        serit.pack(side="left", fill="both", expand=True)
        ic = tk.Frame(serit, bg=C_PANEL)
        ic.pack(fill="x", padx=16, pady=11)

        kapat = tk.Button(ic, text="✕", command=self._guncelleme_kapat,
                          bg=C_PANEL, fg=C_MUTED, activebackground=C_SURFACE,
                          activeforeground=C_TEXT, relief="flat", bd=0,
                          padx=8, pady=2, cursor="hand2",
                          font=("Segoe UI", 10))
        kapat.pack(side="right", padx=(12, 0))
        self._btn(ic, "⬆  Şimdi Güncelle", self._guncellemeyi_kur,
                  "primary", bold=True).pack(side="right")

        yazi = tk.Frame(ic, bg=C_PANEL)
        yazi.pack(side="left", fill="x", expand=True)
        tk.Label(yazi, text=f"Yeni sürüm hazır: {bilgi['surum']}",
                 bg=C_PANEL, fg=C_TEXT, font=("Segoe UI Semibold", 10),
                 anchor="w").pack(anchor="w")
        notlar = bilgi.get("notlar") or "Sürüm notu belirtilmemiş."
        tk.Label(yazi, text=f"Şu an {SURUM} kullanıyorsunuz.  {notlar}",
                 bg=C_PANEL, fg=C_MUTED, font=("Segoe UI", 9), anchor="w",
                 justify="left", wraplength=900).pack(anchor="w", pady=(2, 0))

    def _guncelleme_kapat(self):
        for w in self._guncelleme_kap.winfo_children():
            w.destroy()
        self._guncelleme_bilgi = None

    def _guncellemeyi_kur(self):
        """Paketi indirir, dogrular, kurar ve uygulamayi yeniden baslatir.

        Her adim kullaniciya bildirilir; hata olursa kurulum yapilmaz ve
        mevcut surum oldugu gibi kalir.
        """
        bilgi = self._guncelleme_bilgi
        if not bilgi or guncelleme is None:
            return
        if not messagebox.askokcancel(
                "Güncelleme",
                f"Sürüm {bilgi['surum']} indirilip kurulacak.\n\n"
                f"Uygulama kapanıp yeniden açılacak. Ayarlarınız, "
                f"kayıtlarınız ve indirdiğiniz belgeler korunur; mevcut "
                f"sürüm 'yedek' klasörüne kopyalanır.\n\nDevam edilsin mi?",
                parent=self):
            return

        def calis():
            gecici = BASE_DIR / "guncelleme_gecici.zip"
            try:
                def ilerle(inen, toplam):
                    if toplam:
                        yuzde = int(inen * 100 / toplam)
                        self.q.put(("STATUS",
                                    f"Güncelleme indiriliyor... %{yuzde}",
                                    "info"))

                self.q.put(("STATUS", "Güncelleme indiriliyor...", "info"))
                guncelleme.paket_indir(bilgi["paket"], gecici, ilerle)
                self.q.put(("STATUS", "Paket doğrulanıyor...", "info"))
                guncelleme.paketi_dogrula(gecici)
                self.q.put(("STATUS", "Kuruluyor...", "info"))
                yedek, adet = guncelleme.kur(gecici, BASE_DIR)
                self.after(0, lambda: self._guncelleme_bitti(
                    bilgi["surum"], adet, yedek))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror(
                    "Güncelleme başarısız",
                    f"{e}\n\nMevcut sürüm değiştirilmedi.", parent=self))
                self.q.put(("STATUS", "Güncelleme başarısız", "err"))
            finally:
                try:
                    gecici.unlink(missing_ok=True)
                except Exception:
                    pass

        threading.Thread(target=calis, daemon=True).start()

    def _guncelleme_bitti(self, yeni_surum: str, adet: int, yedek: Path):
        messagebox.showinfo(
            "Güncelleme tamamlandı",
            f"Sürüm {yeni_surum} kuruldu ({adet} dosya).\n\n"
            f"Önceki sürüm şuraya yedeklendi:\n{yedek}\n\n"
            f"Uygulama şimdi yeniden başlatılacak.", parent=self)
        self._yeniden_baslat()

    def _yeniden_baslat(self):
        """Uygulamayi ayni modda yeniden acar (mod degistirmeyle ayni yol)."""
        try:
            if self._thread and self._thread.is_alive():
                self._thread.stop()
                self._thread.join(timeout=3)
            self.store.save()
        except Exception:
            pass
        _release_single_instance_lock()
        try:
            komut = [sys.executable]
            if not getattr(sys, "frozen", False):
                komut.append(str(Path(__file__).resolve()))
            komut += ["--mod", self.mode, "--gecis"]
            subprocess.Popen(komut, close_fds=True,
                             creationflags=getattr(subprocess,
                                                   "CREATE_NO_WINDOW", 0))
        except Exception:
            pass
        self.destroy()

    # ── Duyuru seridi ─────────────────────────────────────────────────────
    def _duyuru_seridi_kur(self):
        """Kapatilabilir duyuru seridi.

        Icerik uzak bir JSON dosyasindan gelir (bkz. duyuru.py). Serit
        BASLANGICTA GIZLIDIR ve yalnizca gosterilecek duyuru varsa acilir;
        boylece adres tanimli degilken ekranda bos bir kutu durmaz.
        Ag islemi ayri is parcaciginda yapilir, arayuz hic beklemez.
        """
        # Kap BASTAN paketlenir ki sirasi (ust seridin hemen alti) sabit
        # kalsin. Icerik yokken cocugu olmadigi icin yuksekligi sifirdir,
        # yani ekranda hicbir iz birakmaz.
        self._duyuru_kap = tk.Frame(self, bg=C_BG, padx=18)
        self._duyuru_kap.pack(fill="x")
        self._duyuru_aktif = None
        self._duyuru_liste = []
        self._duyuru_sira = 0
        self._duyuru_zaman = None
        self._duyuru_gorsel = None            # PhotoImage referansi tutulmali
        if duyuru is None:
            return
        self.after(1200, self._duyurulari_yenile)

    def _duyurulari_yenile(self):
        """Duyurulari arka planda tazeler ve zamanlayiciyi kurar."""
        if duyuru is None:
            return
        try:
            dakika = int(duyuru.ayarlari_oku().get("reklam_yenileme_dk", 60))
        except Exception:
            dakika = 60
        dakika = max(5, min(dakika, 24 * 60))

        def bitince(kayitlar):
            # Ag is parcacigindan geliyoruz; tkinter'a ancak ana is
            # parcacigindan dokunulabilir.
            try:
                self.after(0, lambda: self._duyuru_goster(kayitlar))
            except Exception:
                pass

        try:
            duyuru.arka_planda_yenile(bitince)
        except Exception:
            pass
        self.after(dakika * 60 * 1000, self._duyurulari_yenile)

    def _duyuru_goster(self, kayitlar):
        """Gecerli duyurulari alir; birden fazlaysa sirayla gosterir."""
        self._duyuru_liste = list(kayitlar or [])
        self._duyuru_sira = 0
        self._duyuru_ciz()

    def _duyuru_ciz(self):
        """Siradaki duyuruyu cizer ve gecis zamanlayicisini kurar."""
        # Onceki zamanlayici iptal edilmezse her cizimde bir tane daha
        # birikir ve serit giderek hizlanir.
        if getattr(self, "_duyuru_zaman", None):
            try:
                self.after_cancel(self._duyuru_zaman)
            except Exception:
                pass
            self._duyuru_zaman = None

        for w in self._duyuru_kap.winfo_children():
            w.destroy()
        if not self._duyuru_liste:
            self._duyuru_aktif = None
            return

        self._duyuru_sira %= len(self._duyuru_liste)
        kayit = self._duyuru_liste[self._duyuru_sira]
        self._duyuru_aktif = kayit
        if len(self._duyuru_liste) > 1:
            self._duyuru_zaman = self.after(
                DUYURU_DONGU_SN * 1000, self._duyuru_sonraki)
        vurgu = kayit.get("renk") or C_BRAND_LT
        if not (isinstance(vurgu, str) and vurgu.startswith("#")
                and len(vurgu) in (4, 7)):
            vurgu = C_BRAND_LT

        dis = tk.Frame(self._duyuru_kap, bg=C_BORDER)
        dis.pack(fill="x", pady=(12, 0))
        tk.Frame(dis, bg=vurgu, width=3).pack(side="left", fill="y")
        serit = tk.Frame(dis, bg=C_PANEL)
        serit.pack(side="left", fill="both", expand=True)

        # Yalnizca gorsel varsa BANNER modu: afis tek basina ve buyuk.
        banner = bool(kayit.get("gorsel")) and not (kayit.get("baslik")
                                                   or kayit.get("metin"))

        ic = tk.Frame(serit, bg=C_PANEL)
        ic.pack(fill="x", padx=(16 if not banner else 10), pady=11)

        # Kapatma dugmesi en sagda; kullanici istedigi an kaldirabilir.
        kapat = tk.Button(
            ic, text="✕", command=self._duyuru_kapat,
            bg=C_PANEL, fg=C_MUTED, activebackground=C_SURFACE,
            activeforeground=C_TEXT, relief="flat", bd=0, padx=8, pady=2,
            cursor="hand2", font=("Segoe UI", 10))
        kapat.pack(side="right", padx=(12, 0))
        kapat.bind("<Enter>", lambda e: kapat.config(bg=C_SURFACE,
                                                     fg=C_TEXT))
        kapat.bind("<Leave>", lambda e: kapat.config(bg=C_PANEL,
                                                     fg=C_MUTED))

        # Birden fazla duyuru varsa kacinci oldugu gosterilir.
        if len(self._duyuru_liste) > 1:
            tk.Label(ic, text=f"{self._duyuru_sira + 1}/"
                             f"{len(self._duyuru_liste)}",
                     bg=C_PANEL, fg=C_MUTED,
                     font=("Segoe UI", 8)).pack(side="right", padx=(10, 2))

        if kayit.get("link") and not banner:
            self._btn(ic, "Detay  →",
                      lambda: self._duyuru_ac(kayit["link"]),
                      "ghost").pack(side="right")

        # Gorsel varsa onbellekten yuklenir; indirilemezse metin tek basina
        # gosterilir, serit yine calisir.
        yol = None
        if kayit.get("gorsel"):
            try:
                yol = duyuru.gorsel_indir(kayit["gorsel"])
            except Exception:
                yol = None
        if yol:
            self._duyuru_gorsel = self._duyuru_gorseli_yukle(
                yol, DUYURU_BANNER_EN if banner else DUYURU_GORSEL_EN,
                DUYURU_BANNER_BOY if banner else DUYURU_GORSEL_BOY)
            if self._duyuru_gorsel is not None:
                etiket = tk.Label(ic, image=self._duyuru_gorsel, bg=C_PANEL,
                                  cursor="hand2" if kayit.get("link") else "")
                # Banner modunda afis kalan alanin ORTASINA yerlesir; sola
                # yaslandiginda sagda genis bir bosluk kaliyor ve serit
                # yarim kalmis gorunuyordu. Metinli duyuruda ise gorsel
                # metnin solunda durmali.
                if banner:
                    etiket.pack(side="left", expand=True)
                else:
                    etiket.pack(side="left", padx=(0, 16))
                # Banner modunda afisin kendisi tiklanabilir; ayri "Detay"
                # dugmesi afisin yaninda gereksiz duruyor.
                if kayit.get("link"):
                    etiket.bind("<Button-1>",
                                lambda e, l=kayit["link"]: self._duyuru_ac(l))

        if not banner:
            yazi = tk.Frame(ic, bg=C_PANEL)
            yazi.pack(side="left", fill="x", expand=True)
            if kayit.get("baslik"):
                tk.Label(yazi, text=kayit["baslik"], bg=C_PANEL, fg=C_TEXT,
                         font=("Segoe UI Semibold", 10),
                         anchor="w").pack(anchor="w")
            if kayit.get("metin"):
                tk.Label(yazi, text=kayit["metin"], bg=C_PANEL, fg=C_MUTED,
                         font=("Segoe UI", 9), anchor="w", justify="left",
                         wraplength=900).pack(anchor="w", pady=(2, 0))

    def _duyuru_gorseli_yukle(self, yol: Path, en: int = DUYURU_GORSEL_EN,
                              boy: int = DUYURU_GORSEL_BOY):
        """Duyuru gorselini acar ve verilen olcuye sigdirir.

        Pillow ile acilir; boylece JPEG, WEBP, BMP gibi tkinter'in tek
        basina acamadigi bicimler de calisir. Goruntu oranini KORUYARAK
        kucultulur, buyutulmez: kucuk gorsel bulaniklastirilmaz.
        """
        try:
            if HAS_OCR:                       # Pillow kurulu
                im = Image.open(yol)
                if im.mode not in ("RGB", "RGBA"):
                    im = im.convert("RGBA")
                oran = min(en / im.width, boy / im.height, 1.0)
                if oran < 1.0:
                    im = im.resize((max(1, int(im.width * oran)),
                                    max(1, int(im.height * oran))),
                                   Image.LANCZOS)
                # Saydam gorseller serit zeminiyle harmanlanir; aksi halde
                # alfa kanali siyah bir kutuya donusuyor.
                if im.mode == "RGBA":
                    zemin = Image.new("RGB", im.size, _renk_rgb(C_PANEL))
                    zemin.paste(im, mask=im.split()[3])
                    im = zemin
                return ImageTk.PhotoImage(im)
            return tk.PhotoImage(file=str(yol))     # Pillow yoksa PNG/GIF
        except Exception:
            return None

    # ── Arka plan filigrani ───────────────────────────────────────────────
    def _filigran(self, parent, yukseklik: int, opaklik: float = 0.10,
                  zemin: str = C_BG):
        """Logoyu zemine karistirilmis, cok soluk bir goruntu olarak uretir.

        tkinter'da widget'lar gercekten saydam olamaz; bir widget'in
        arkasindaki sey gorunmez. Bu yuzden filigran, logo ile zemin rengi
        ONCEDEN HARMANLANARAK tek bir opak goruntuye cevrilir. Sonuc gozle
        saydam gorunur ama teknik olarak duz bir resimdir.
        """
        if not HAS_OCR:
            return None
        # Yuksek cozunurluklu logo varsa oncelikli: filigran buyutuldugu
        # icin 85x46'lik kucuk logo bulaniklasiyordu.
        for ad in ("logo_filigran.png", "logo_light.png",
                   "logo_original.png", "logo_mark.png"):
            yol = ASSET_DIR / ad
            if not yol.exists():
                continue
            try:
                im = Image.open(yol).convert("RGBA")
                oran = yukseklik / im.height
                im = im.resize((max(1, int(im.width * oran)), yukseklik),
                               Image.LANCZOS)
                # Logonun KENDI RENGI kullanilmaz; yalnizca alfa kanali
                # maske olarak alinip acik bir tonla boyanir.
                #
                # Sebep olculdu: marka logosu siyah cizgi isi. Kendi
                # renkleriyle koyu zemine %13 opaklikta karistirilinca
                # tamamen gorunmez oldu. Maske yontemi, logo dosyasi hangi
                # renkte olursa olsun filigranin gorunmesini garantiler.
                alfa = im.split()[3].point(
                    lambda d: int(d * max(0.0, min(opaklik, 1.0))))
                kart = Image.new("RGB", im.size, _renk_rgb(zemin))
                boya = Image.new("RGB", im.size, _renk_rgb(FILIGRAN_RENGI))
                kart.paste(boya, mask=alfa)
                foto = ImageTk.PhotoImage(kart)
                etiket = tk.Label(parent, image=foto, bg=zemin, bd=0)
                etiket.image = foto          # referans tutulmali, yoksa silinir
                return etiket
            except Exception:
                continue
        return None

    def _duyuru_sonraki(self):
        self._duyuru_sira += 1
        self._duyuru_ciz()

    def _duyuru_kapat(self):
        """Gosterilen duyuruyu kalici olarak kaldirir, sonrakine gecer.

        Kullanici tek bir reklamdan rahatsizsa hepsini kapatmak zorunda
        kalmasin; ama listedeki her duyuruyu tek tek kapatabilir.
        """
        aktif = self._duyuru_aktif
        if duyuru and aktif:
            try:
                duyuru.kapat(aktif.get("id"))
            except Exception:
                pass
        self._duyuru_liste = [k for k in getattr(self, "_duyuru_liste", [])
                              if k is not aktif]
        self._duyuru_ciz()

    def _duyuru_ac(self, link: str):
        """Duyuru linkini tarayicida acar (yalnizca http/https)."""
        guvenli = duyuru.guvenli_link(link) if duyuru else None
        if guvenli:
            try:
                webbrowser.open(guvenli)
            except Exception:
                pass

    # ── Mod degistirici ───────────────────────────────────────────────────
    def _mod_segmenti(self, parent):
        """Ihale <-> Dogrudan Temin gecisi icin bolmeli dugme.

        Iki kaynak ayri durum dosyalari ve ayri EKAP servisleri kullaniyor;
        tek surecte ikisini birden tutmak kayitlari karistirir. Bu yuzden
        gecis, uygulamayi hedef modda yeniden baslatarak yapilir.
        """
        kutu = tk.Frame(parent, bg=C_SURFACE, highlightthickness=1,
                        highlightbackground=C_BORDER)
        self._mod_dugmeleri = {}
        for mod in (MODE_IHALE, MODE_DT):
            aktif = (mod == self.mode)
            b = tk.Button(
                kutu, text=f"  {MODE_LABELS[mod]}  ",
                command=(lambda m=mod: self._mod_degistir(m)),
                bg=C_BRAND if aktif else C_SURFACE,
                fg="#ffffff" if aktif else C_MUTED,
                activebackground=C_BRAND_LT if aktif else C_ELEV,
                activeforeground="#ffffff",
                relief="flat", bd=0, padx=14, pady=7,
                cursor="arrow" if aktif else "hand2",
                font=("Segoe UI", 9, "bold" if aktif else "normal"))
            b.pack(side="left", padx=2, pady=2)
            if not aktif:
                b.bind("<Enter>", lambda e, w=b: w.config(bg=C_ELEV,
                                                          fg=C_TEXT))
                b.bind("<Leave>", lambda e, w=b: w.config(bg=C_SURFACE,
                                                          fg=C_MUTED))
            self._mod_dugmeleri[mod] = b
        return kutu

    def _mod_degistir(self, hedef: str):
        """Uygulamayi diger modda yeniden baslatir."""
        if hedef == self.mode:
            return
        if not messagebox.askokcancel(
                "Mod değiştir",
                f"{MODE_LABELS[hedef]} moduna geçilecek.\n\n"
                f"Uygulama kapanıp yeniden açılacak; devam eden tarama "
                f"durdurulacak. Kayıtlarınız korunur.",
                parent=self):
            return
        try:
            self._set_status(f"{MODE_LABELS[hedef]} moduna geçiliyor...",
                             "info")
            self.update_idletasks()
            if self._thread and self._thread.is_alive():
                self._thread.stop()
                self._thread.join(timeout=3)
            self.store.save()
        except Exception:
            pass
        # Tek kopya kilidi birakilmali, yoksa yeni surec acilamaz.
        _release_single_instance_lock()
        try:
            komut = [sys.executable]
            if not getattr(sys, "frozen", False):
                komut.append(str(Path(__file__).resolve()))
            komut += ["--mod", hedef, "--gecis"]
            subprocess.Popen(komut, close_fds=True,
                             creationflags=getattr(subprocess,
                                                   "CREATE_NO_WINDOW", 0))
        except Exception as e:
            messagebox.showerror("Mod değiştirilemedi", str(e), parent=self)
            return
        self.destroy()

    # ── Yardim ────────────────────────────────────────────────────────────
    def _yardim_ac(self):
        """Yardim penceresi: kisa ipuclari + destek e-postasi."""
        pen = tk.Toplevel(self)
        pen.title("Yardım")
        pen.configure(bg=C_BG)
        pen.resizable(False, False)
        pen.transient(self)

        ust = tk.Frame(pen, bg=C_PANEL, padx=24, pady=18)
        ust.pack(fill="x")
        tk.Label(ust, text="Yardım ve Destek", bg=C_PANEL, fg=C_TEXT,
                 font=("Segoe UI Semibold", 14)).pack(anchor="w")
        tk.Label(ust, text=f"Sürüm {SURUM} — takıldığınız yeri yazın, "
                            f"dönüş yapalım.",
                 bg=C_PANEL, fg=C_MUTED,
                 font=("Segoe UI", 9)).pack(anchor="w", pady=(3, 0))
        tk.Frame(pen, bg=C_BORDER, height=1).pack(fill="x")

        govde = tk.Frame(pen, bg=C_BG, padx=24, pady=18)
        govde.pack(fill="both", expand=True)

        ipuclari = [
            ("Çift tıklama", "Seçili ilanın dokümanını indirir."),
            ("Sağ tıklama", "İlanı tarayıcıda açar."),
            ("Mod değiştirme", "Başlıktaki düğmelerle İhaleler ve "
                               "Doğrudan Temin arasında geçiş yapın."),
            ("Şartname Okuma", "Teknik şartname PDF'ini okur, "
                               "tutarsızlıkları işaretler."),
            ("Güvenlik sorusu", "İhale dokümanı indirirken EKAP görsel "
                                "soru sorar; açılan pencereye cevabı yazın."),
        ]
        for baslik, aciklama in ipuclari:
            satir = tk.Frame(govde, bg=C_BG)
            satir.pack(fill="x", pady=(0, 9))
            tk.Label(satir, text=baslik, bg=C_BG, fg=C_TEXT_DIM, width=17,
                     anchor="w", font=("Segoe UI", 9, "bold")).pack(side="left")
            tk.Label(satir, text=aciklama, bg=C_BG, fg=C_MUTED,
                     wraplength=380, justify="left", anchor="w",
                     font=("Segoe UI", 9)).pack(side="left", fill="x",
                                                expand=True)

        tk.Frame(govde, bg=C_BORDER, height=1).pack(fill="x", pady=(6, 14))

        adres = duyuru.destek_eposta() if duyuru else ""
        kutu = tk.Frame(govde, bg=C_SURFACE, padx=16, pady=14,
                        highlightthickness=1, highlightbackground=C_BORDER)
        kutu.pack(fill="x")
        tk.Label(kutu, text="DESTEK E-POSTASI", bg=C_SURFACE, fg=C_MUTED,
                 font=("Segoe UI", 7, "bold")).pack(anchor="w")
        tk.Label(kutu, text=(adres or "— henüz tanımlanmadı —"),
                 bg=C_SURFACE, fg=(C_TEXT if adres else C_YELLOW),
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(3, 10))

        if adres:
            tk.Label(kutu, text="Düğmeye basınca varsayılan e-posta "
                               "programınız açılır.",
                     bg=C_SURFACE, fg=C_MUTED,
                     font=("Segoe UI", 8)).pack(anchor="w", pady=(0, 10))
            self._btn(kutu, "✉  E-posta Gönder",
                      lambda: self._destek_yaz(adres), "primary",
                      bold=True).pack(anchor="w")
        else:
            tk.Label(kutu,
                     text="Adresi eklemek için uygulama klasöründeki\n"
                          "ayarlar.json dosyasında \"destek_eposta\" "
                          "alanını doldurun.",
                     bg=C_SURFACE, fg=C_MUTED, justify="left",
                     font=("Segoe UI", 8)).pack(anchor="w")

        alt = tk.Frame(pen, bg=C_BG, padx=24, pady=(0, 18))
        alt.pack(fill="x")
        self._btn(alt, "Kapat", pen.destroy, "ghost",
                  pad=18).pack(side="right")
        self._btn(alt, "Güncelleme Denetle",
                  lambda: self._guncelleme_denetle(pen), "quiet",
                  pad=14).pack(side="left")

        pen.bind("<Escape>", lambda e: pen.destroy())
        pen.update_idletasks()
        x = self.winfo_rootx() + (self.winfo_width() - pen.winfo_width()) // 2
        y = self.winfo_rooty() + 90
        pen.geometry(f"+{max(0, x)}+{max(0, y)}")
        pen.grab_set()

    def _guncelleme_denetle(self, ust_pencere=None):
        """Yardim penceresindeki "Güncelleme Denetle" dugmesi.

        Otomatik kontrolun aksine burada SONUC HER ZAMAN bildirilir;
        kullanici bilerek sordugu icin "guncel" cevabi da bilgidir.
        """
        if guncelleme is None or duyuru is None:
            messagebox.showinfo("Güncelleme",
                                "Güncelleme modülü yüklü değil.",
                                parent=ust_pencere or self)
            return
        adres = duyuru.ayarlari_oku().get("guncelleme_adresi") or ""
        if not adres:
            messagebox.showinfo(
                "Güncelleme",
                "Güncelleme adresi tanımlı değil.\n\n"
                "ayarlar.json dosyasındaki \"guncelleme_adresi\" alanına "
                "deponuzdaki surum.json adresini yazın.",
                parent=ust_pencere or self)
            return

        def bitince(bilgi, hata):
            def goster():
                if hata:
                    messagebox.showwarning(
                        "Güncelleme denetlenemedi",
                        f"{hata}\n\nİnternet bağlantınızı ve adresi "
                        f"kontrol edin.", parent=ust_pencere or self)
                elif bilgi:
                    if ust_pencere:
                        ust_pencere.destroy()
                    self._guncelleme_goster(bilgi)
                else:
                    messagebox.showinfo(
                        "Güncelleme",
                        f"En güncel sürümü kullanıyorsunuz ({SURUM}).",
                        parent=ust_pencere or self)
            try:
                self.after(0, goster)
            except Exception:
                pass

        guncelleme.arka_planda_kontrol(adres, SURUM, bitince)

    def _destek_yaz(self, adres: str):
        """Varsayilan e-posta programini konu ve sistem bilgisiyle acar."""
        from urllib.parse import quote
        ayar = duyuru.ayarlari_oku() if duyuru else {}
        konu = ayar.get("destek_konu") or "EKAP İzleyici — Destek Talebi"
        govde = (
            "Sorununuzu buraya yazın:\n\n\n"
            "-------------------------------------------\n"
            f"Mod        : {MODE_LABELS[self.mode]}\n"
            f"Takip      : {len(self.store.known_ikns)}\n"
            f"Python     : {sys.version.split()[0]}\n"
            f"Tarih      : {datetime.now():%d.%m.%Y %H:%M}\n")
        try:
            webbrowser.open(f"mailto:{adres}?subject={quote(konu)}"
                            f"&body={quote(govde)}")
        except Exception as e:
            messagebox.showerror("E-posta açılamadı", str(e), parent=self)

    def _load_logo(self):
        """assets/logo_light.png dosyasini yukler (yoksa None doner)."""
        for ad in ("logo_light.png", "logo_original.png"):
            yol = ASSET_DIR / ad
            if yol.exists():
                try:
                    return tk.PhotoImage(file=str(yol))
                except Exception:
                    continue
        return None

    # ── Arayuz insasi ─────────────────────────────────────────────────────
    def _build_ui(self):
        self._style_ttk()

        # ══ UST SERIT: logo + mod degistirici + durum + yardim ══
        hdr = tk.Frame(self, bg=C_PANEL, height=76)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        tk.Frame(self, bg=C_BORDER, height=1).pack(fill="x")

        sol = tk.Frame(hdr, bg=C_PANEL)
        sol.pack(side="left", padx=20, pady=12)

        self._logo_img = self._load_logo()
        if self._logo_img is not None:
            tk.Label(sol, image=self._logo_img,
                     bg=C_PANEL).pack(side="left", padx=(0, 16))

        yazi = tk.Frame(sol, bg=C_PANEL)
        yazi.pack(side="left")
        tk.Label(yazi, text="EKAP İzleyici", bg=C_PANEL, fg=C_TEXT,
                 font=("Segoe UI Semibold", 15)).pack(anchor="w")
        tk.Label(yazi, text="UNIARCH Klinik Mühendislik", bg=C_PANEL,
                 fg=C_MUTED, font=("Segoe UI", 8)).pack(anchor="w", pady=(1, 0))

        # Mod degistirici: iki kaynak arasinda uygulamayi kapatmadan gecis.
        self._mod_segmenti(hdr).pack(side="left", padx=(34, 0), pady=12)

        # Sag: yardim + durum gostergesi
        sag = tk.Frame(hdr, bg=C_PANEL)
        sag.pack(side="right", padx=20)
        self._btn(sag, "?  Yardım", self._yardim_ac, "quiet",
                  pad=12).pack(side="right", padx=(12, 0))

        durum_kutu = tk.Frame(sag, bg=C_SURFACE, padx=12, pady=7,
                              highlightthickness=1,
                              highlightbackground=C_BORDER)
        durum_kutu.pack(side="right")
        self._dot = tk.Label(durum_kutu, text="●", bg=C_SURFACE, fg=C_MUTED,
                             font=("Segoe UI", 10))
        self._dot.pack(side="left", padx=(0, 8))
        self._status_lbl = tk.Label(durum_kutu, text="Başlatılıyor...",
                                    bg=C_SURFACE, fg=C_TEXT_DIM,
                                    font=("Segoe UI", 9), anchor="w",
                                    justify="left")
        self._status_lbl.pack(side="left")

        # ══ GUNCELLEME SERIDI (duyurunun USTUNDE; reklam bunu ortemez) ══
        self._guncelleme_seridi_kur()

        # ══ DUYURU SERIDI (kapatilabilir, isi engellemez) ══
        self._duyuru_seridi_kur()

        # ══ ISTATISTIK KARTLARI ══
        stat = tk.Frame(self, bg=C_BG, padx=18, pady=14)
        stat.pack(fill="x")
        kartlar = tk.Frame(stat, bg=C_BG)
        kartlar.pack(side="left")
        birim = "duyuru" if self.mode == MODE_DT else "ihale"
        self._stat_takip = self._stat_card(
            kartlar, f"Takip edilen {birim}", "0", cizgi=C_BRAND_LT)
        self._stat_liste = self._stat_card(
            kartlar, "Listede", "0", cizgi=C_BRAND_LT)
        self._stat_yeni = self._stat_card(
            kartlar, "Yeni", "0", C_GREEN, cizgi=C_GREEN)
        self._stat_kontrol = self._stat_card(
            kartlar, "Son kontrol", "—", C_TEXT_DIM, cizgi=C_BORDER)
        self._info_lbl = self._stat_takip          # eski isim uyumu

        # Marka filigrani. Kartlarin sagindaki bant her zaman bos kaliyor;
        # logo oraya zemine karistirilmis olarak konur. Isi engellemez,
        # tiklanmaz, yeniden boyutlandirmada kartlarla cakismaz.
        fil = self._filigran(stat, 74, 0.13, C_BG)
        if fil is not None:
            fil.pack(side="right", padx=(20, 4))

        # ══ ARAC CUBUGU ══
        # Eskiden tum kontroller tek sirada, ayrimsiz duruyordu; hangi
        # dugmenin neyle ilgili oldugu okunmuyordu. Artik uc gruba ayrildi
        # ve her grubun ustunde kucuk bir baslik var.
        tb = tk.Frame(self, bg=C_BG, padx=18)
        tb.pack(fill="x", pady=(0, 12))
        bar = tk.Frame(tb, bg=C_PANEL, padx=16, pady=12,
                       highlightthickness=1, highlightbackground=C_BORDER)
        bar.pack(fill="x")

        def grup(baslik, sag=False):
            """Baslikli kontrol grubu doner; icine kontroller paketlenir."""
            dis = tk.Frame(bar, bg=C_PANEL)
            dis.pack(side="right" if sag else "left")
            tk.Label(dis, text=baslik, bg=C_PANEL, fg=C_MUTED,
                     font=("Segoe UI", 7, "bold")).pack(anchor="w",
                                                        pady=(0, 6))
            ic = tk.Frame(dis, bg=C_PANEL)
            ic.pack(anchor="w")
            return ic

        def ayirac():
            tk.Frame(bar, bg=C_BORDER, width=1,
                     height=42).pack(side="left", padx=18)

        def kutucuk(parent, metin, degisken):
            return tk.Checkbutton(
                parent, text=metin, variable=degisken,
                bg=C_PANEL, fg=C_TEXT_DIM, selectcolor=C_SURFACE,
                activebackground=C_PANEL, activeforeground=C_TEXT,
                font=("Segoe UI", 9), bd=0, highlightthickness=0,
                cursor="hand2")

        def giris(parent, degisken, genislik, dogrulama=None):
            e = tk.Entry(parent, textvariable=degisken, width=genislik,
                         bg=C_SURFACE, fg=C_TEXT, insertbackground=C_TEXT,
                         relief="flat", font=("Segoe UI", 9),
                         highlightthickness=1, highlightbackground=C_BORDER,
                         highlightcolor=C_BRAND_LT)
            if dogrulama:
                e.config(validate="key", validatecommand=dogrulama,
                         justify="center")
            return e

        # -- TARAMA
        g = grup("TARAMA")
        vcmd = (self.register(lambda v: v.isdigit() or v == ""), "%P")
        self._interval_entry = giris(g, self._interval, 5, vcmd)
        self._interval_entry.pack(side="left", ipady=5, padx=(0, 4))
        tk.Label(g, text="sn", bg=C_PANEL, fg=C_MUTED,
                 font=("Segoe UI", 8)).pack(side="left", padx=(0, 8))
        self._btn(g, "Uygula", self._restart_monitor,
                  "ghost").pack(side="left")
        self._btn(g, "↻  Şimdi Tara", self._manual_scan, "success",
                  bold=True).pack(side="left", padx=8)

        ayirac()

        # -- DOKUMAN
        g = grup("DOKÜMAN")
        self._btn(g, "⬇  Seçileni İndir", self._download_selected_item,
                  "primary", bold=True).pack(side="left")
        self._btn(g, "📂  İndirilenler", self._open_download_dir,
                  "accent").pack(side="left", padx=8)
        kutucuk(g, "Seçince otomatik indir",
                self._auto_download_var).pack(side="left", padx=(4, 0))

        ayirac()

        # -- BELGE ICINDE ARAMA
        g = grup("BELGE İÇİNDE ARA")
        self._pdf_keywords_entry = giris(g, self._pdf_keywords_var, 22)
        self._pdf_keywords_entry.pack(side="left", ipady=5)
        kutucuk(g, "OCR", self._ocr_var).pack(side="left", padx=8)

        # -- Sagda: yikici eylem, digerlerinden uzakta
        g = grup("KAYITLAR", sag=True)
        self._btn(g, "Geçmişi Temizle", self._clear_history,
                  "quiet").pack(side="left")

        # ══ SEKMELER ══
        tabs_wrap = tk.Frame(self, bg=C_BG, padx=14)
        tabs_wrap.pack(fill="both", expand=True)
        self._tabs = ttk.Notebook(tabs_wrap)
        self._tabs.pack(fill="both", expand=True)

        self._tab_live = tk.Frame(self._tabs, bg=C_BG)
        self._tab_filter = tk.Frame(self._tabs, bg=C_BG)
        self._tab_pdf = tk.Frame(self._tabs, bg=C_BG)
        self._tabs.add(self._tab_live, text="  Canlı İzleme  ")
        self._tabs.add(self._tab_filter, text="  Filtreleme  ")
        self._tabs.add(self._tab_pdf, text="  Belge Analizi  ")

        # Sartname Okuma sekmesi. Ayri bir pakette (sartname/) durur ve
        # ana uygulamayi hic tanimaz; renk paleti ile buton fabrikasi
        # disaridan verilir. Paket yuklenemezse uygulama calismaya devam
        # eder, yalnizca bu sekme acilmaz.
        self._tab_sartname = self._sartname_sekmesi_kur()
        if self._tab_sartname is not None:
            self._tabs.add(self._tab_sartname, text="  Şartname Okuma  ")

        # -- Arama serdi
        ara_kutu = tk.Frame(self._tab_live, bg=C_PANEL, padx=10, pady=8,
                            highlightthickness=1, highlightbackground=C_BORDER)
        ara_kutu.pack(fill="x", pady=(8, 6))

        # 1. satir: arama kutusu
        ust = tk.Frame(ara_kutu, bg=C_PANEL)
        ust.pack(fill="x")
        tk.Label(ust, text="🔍", bg=C_PANEL, fg=C_MUTED,
                 font=("Segoe UI", 11)).pack(side="left", padx=(2, 8))
        live_search_entry = tk.Entry(
            ust, textvariable=self._live_search_var,
            bg=C_SURFACE, fg=C_TEXT, insertbackground=C_TEXT,
            relief="flat", font=("Segoe UI", 10))
        live_search_entry.pack(side="left", fill="x", expand=True, ipady=5)
        self._live_count_lbl = tk.Label(ust, text="", bg=C_PANEL,
                                        fg=C_MUTED, font=("Segoe UI", 9, "bold"))
        self._live_count_lbl.pack(side="right", padx=(10, 4))
        self._btn(ust, "×  Temizle", self._clear_live_filters, "ghost",
                  pad=10).pack(side="right", padx=8)

        # 2. satir: tur rozetleri (dar pencerede tasmasin diye ayri satir)
        alt = tk.Frame(ara_kutu, bg=C_PANEL)
        alt.pack(fill="x", pady=(8, 0))
        tk.Label(alt, text="TÜR", bg=C_PANEL, fg=C_MUTED,
                 font=("Segoe UI", 8, "bold")).pack(side="left", padx=(2, 10))
        self._tur_rozetleri(alt, self._apply_live_filter).pack(side="left")
        tk.Label(alt, text="seçim yoksa tümü listelenir", bg=C_PANEL,
                 fg=C_MUTED, font=("Segoe UI", 8)).pack(side="left", padx=(10, 0))
        self._live_search_var.trace_add("write", lambda *_: self._apply_live_filter())

        # -- Tablo
        tree_wrap = tk.Frame(self._tab_live, bg=C_BG)
        tree_wrap.pack(fill="both", expand=True, pady=(0, 8))

        cols, heads = self._sutun_tanimi(filtre=False)
        self._tree = ttk.Treeview(tree_wrap, columns=cols, show="headings",
                                  style="EKAP.Treeview", selectmode="browse")
        self._live_head_labels = {col: head for col, head, *_ in heads}
        for col, head, width, anch in heads:
            self._tree.heading(col, text=head, anchor="w" if anch == "w" else "center",
                               command=lambda c=col: self._tree_heading_click(c))
            self._tree.column(col, width=width, anchor=anch, minwidth=70,
                              stretch=(col in ("ihale_adi", "idare_adi")))

        vsb = ttk.Scrollbar(tree_wrap, orient="vertical", command=self._tree.yview)
        hsb = ttk.Scrollbar(tree_wrap, orient="horizontal", command=self._tree.xview)
        self._tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self._tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        tree_wrap.rowconfigure(0, weight=1)
        tree_wrap.columnconfigure(0, weight=1)

        self._tree.bind("<Double-Button-1>", self._download_selected_item)
        self._tree.bind("<Return>",          self._download_selected_item)
        self._tree.bind("<Button-3>",        self._open_url)
        self._tree.bind("<<TreeviewSelect>>", self._on_row_selected)

        self._build_filter_tab()
        self._build_pdf_tab()

        # ══ ALT CUBUK ══
        footer = tk.Frame(self, bg=C_PANEL, pady=6,
                          highlightthickness=1, highlightbackground=C_BORDER)
        footer.pack(fill="x", side="bottom")
        lc = self._fmt_dt(self.store.last_check) if self.store.last_check else "henüz yok"
        self._footer_lbl = tk.Label(
            footer,
            text=(f"   Çift tık: belgeyi indir      Sağ tık: tarayıcıda aç      "
                  f"İndirilenler: {DOWNLOAD_DIR}"),
            bg=C_PANEL, fg=C_MUTED, font=("Segoe UI", 8))
        self._footer_lbl.pack(side="left")
        tk.Label(footer, text="UNIARCH Klinik Mühendislik   ", bg=C_PANEL,
                 fg=C_BRAND_LT, font=("Segoe UI", 8, "bold")).pack(side="right")

    def _style_ttk(self):
        s = ttk.Style(self)
        s.theme_use("clam")

        # clam temasinin varsayilan 3B kenarliklari ACIK RENKTIR (beyaza
        # yakin). Koyu zeminde bunlar sekme alaninin ve tablonun cevresinde
        # beyaz cerceve olarak goruluyordu. Tum ttk widget'lari icin taban
        # ayari burada bir kez yapilir; tek tek widget'ta ezmek gerekmez.
        s.configure(".",
                    background=C_BG, foreground=C_TEXT,
                    bordercolor=C_BORDER, lightcolor=C_PANEL,
                    darkcolor=C_PANEL, troughcolor=C_SURFACE,
                    focuscolor=C_BRAND_LT, borderwidth=0, relief="flat")

        # Sekmeler: secili olan markanin soluk tonuyla doldurulur ve ustunde
        # ince bir vurgu cizgisi tasir. Tam doygun lacivert dolgu, sekmeyi
        # butona benzetip hiyerarsiyi bozuyordu.
        s.configure("TNotebook", background=C_BG, borderwidth=0,
                    bordercolor=C_BG, lightcolor=C_BG, darkcolor=C_BG,
                    tabmargins=(0, 8, 0, 0))
        s.configure("TNotebook.Tab", background=C_PANEL, foreground=C_MUTED,
                    padding=(20, 11), font=("Segoe UI", 9), borderwidth=0)
        s.map("TNotebook.Tab",
              background=[("selected", C_SURFACE), ("active", C_ELEV)],
              foreground=[("selected", C_TEXT), ("active", C_TEXT_DIM)],
              font=[("selected", ("Segoe UI", 9, "bold"))],
              expand=[("selected", (0, 0, 0, 0))])

        # Tablo: satir yuksekligi artirildi (nefes alani), baslik satiri
        # zeminle ayni tonda ama ustte ince ayirac var.
        s.configure("EKAP.Treeview",
                    background=C_ROWBASE, foreground=C_TEXT,
                    fieldbackground=C_ROWBASE, rowheight=36,
                    font=("Segoe UI", 9), borderwidth=0,
                    bordercolor=C_ROWBASE, lightcolor=C_ROWBASE,
                    darkcolor=C_ROWBASE, relief="flat")
        s.configure("EKAP.Treeview.Heading",
                    background=C_PANEL, foreground=C_MUTED,
                    font=("Segoe UI", 8, "bold"), relief="flat",
                    padding=(10, 10), borderwidth=0)
        s.map("EKAP.Treeview.Heading",
              background=[("active", C_SURFACE)],
              foreground=[("active", C_TEXT_DIM)])
        s.map("EKAP.Treeview",
              background=[("selected", C_BRAND_SOFT)],
              foreground=[("selected", C_TEXT)])

        # Kaydirma cubuklari: ok dugmeleri kaldirildi, ince ve sessiz.
        for yon in ("Vertical", "Horizontal"):
            s.configure(f"{yon}.TScrollbar", background=C_BORDER,
                        troughcolor=C_BG, bordercolor=C_BG,
                        arrowcolor=C_BG, borderwidth=0, width=11,
                        arrowsize=0)
            s.map(f"{yon}.TScrollbar", background=[("active", C_ELEV)])

        s.configure("EKAP.TProgressbar", background=C_BRAND_LT,
                    troughcolor=C_SURFACE, borderwidth=0, thickness=6)

    def _info_text(self) -> str:
        rows = len(self._tree.get_children()) if hasattr(self, "_tree") else 0
        return (f"Takip: {len(self.store.known_ikns)}  |  Listede: {rows}")

    @staticmethod
    def _fmt_dt(iso) -> str:
        if not iso:
            return "—"
        try:
            return datetime.fromisoformat(iso).strftime("%d.%m.%Y %H:%M:%S")
        except Exception:
            return str(iso)[:19]

    @staticmethod
    def _sort_datetime(raw) -> datetime:
        """EKAP'in karisik tarih formatlarini siralanabilir datetime'a cevirir."""
        raw = str(raw or "").strip().replace("Z", "")
        if not raw:
            return datetime.min
        try:
            return datetime.fromisoformat(raw)
        except ValueError:
            pass
        for fmt in ("%d.%m.%Y %H:%M", "%d.%m.%Y", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
            try:
                return datetime.strptime(raw, fmt)
            except ValueError:
                continue
        return datetime.min

    # ── Gecmisi yukle ─────────────────────────────────────────────────────────
    def _load_history(self):
        self._all_notifications = list(self.store.notifications)
        self._reload_notification_views()

    def _reload_notification_views(self):
        self._apply_live_filter()
        self._refresh_idare_choices()
        self._apply_filters()
        self._refresh_info()

    def _clear_live_filters(self):
        """Canli sekmedeki arama metnini ve tur rozetlerini sifirlar."""
        for v in self._tur_vars.values():
            v.set(False)
        self._live_search_var.set("")
        self._rozetleri_boya()
        self._apply_live_filter()

    def _sutun_tanimi(self, filtre: bool = False):
        """Moda gore sutun listesi. (kolonlar, basliklar) doner.

        Ihale modunda ILK SUTUN YOK: ekapv2 liste servisi ilan tarihini
        dondurmuyor ve gun bazli suzgecle turetmek guvenilir sonuc vermedi
        (art arda gunlerde kayitlar orusuyor). Yaniltici bir tarih
        gostermektense sutunu hic koymuyoruz. Dogrudan Temin'de ise gercek
        ilan tarihi geldigi icin sutun duruyor.
        """
        dt = (self.mode == MODE_DT)
        heads = []
        if dt:
            heads.append(("found_at", "İlan Tarihi", 120, "center"))
        heads += [
            ("ikn",       "DTN" if dt else "İKN",            125, "center"),
            ("ihale_adi", "İş Adı" if dt else "İhale Adı",
             330 if filtre else 420, "w"),
            ("idare_adi", "İdare", 240 if filtre else 320, "w"),
        ]
        if filtre:
            heads.append(("il", "İl", 110, "center"))
        heads += [
            ("ihale_tarihi", "Son Teklif" if dt else "İhale Tarihi", 130, "center"),
            # DT'de durum her satirda ayni ("Duyurusu Yayimlanmis"); yerine
            # gercekten ayirt edici olan TUR gosterilir.
            ("ihale_durumu", "Tür" if dt else "Durum",
             90 if dt else (190 if filtre else 210), "center" if dt else "w"),
        ]
        return tuple(h[0] for h in heads), heads

    def _satir_degerleri(self, n: dict, filtre: bool = False) -> tuple:
        """Bir kaydin tablo satirini sutun tanimiyla ayni sirada uretir."""
        tarih_raw = n.get("ihaleTarihSaat") or ""
        try:
            tarih_str = datetime.fromisoformat(str(tarih_raw)).strftime("%d.%m.%Y %H:%M")
        except Exception:
            tarih_str = str(tarih_raw)[:16]
        if self.mode == MODE_DT:
            durum = n.get("dt_turu") or n.get("ihaleDurumAciklama", "")
        else:
            durum = n.get("ihaleDurumAciklama", "")

        deger = []
        if self.mode == MODE_DT:
            deger.append(self._ilk_sutun(n))
        deger += [n.get("ikn", ""), n.get("ihaleAdi", "—"), n.get("idareAdi", "—")]
        if filtre:
            deger.append(n.get("il", "—"))
        deger += [tarih_str, durum]
        return tuple(deger)

    def _ilk_sutun(self, n: dict) -> str:
        """Tablonun ilk sutunu: DT'de ilan (duyuru) tarihi, ihalede bulunma.

        ekapv2 ihale listesi ilan tarihini DONDURMUYOR (yanitta yalnizca
        ihaleTarihSaat var); o yuzden ihale modunda kaydin ilk goruldugu
        zaman gosterilmeye devam ediyor.
        """
        if self.mode == MODE_DT:
            t = str(n.get("ilanTarihi") or n.get("dt_duyuru_tarihi") or "").strip()
            if t:
                return t
        return self._fmt_dt(n.get("found_at"))[:16]

    def _tree_heading_click(self, col: str):
        """Sort live tree by column; toggle asc/desc on repeated click."""
        if self._live_sort_col == col:
            self._live_sort_asc = not self._live_sort_asc
        else:
            self._live_sort_col = col
            self._live_sort_asc = True
        self._apply_live_filter()

    def _apply_live_filter(self):
        """Rebuild the live tree with current search text and sort order."""
        if not hasattr(self, "_tree"):
            return

        query = tr_fold(self._live_search_var.get().strip())
        secili_tur = self._secili_turler()

        # Filter
        if query:
            tokens = [t for t in re.split(r"[\s,;]+", query) if t]
            rows = []
            for n in self._all_notifications:
                text = tr_fold(" ".join([
                    str(n.get("ikn", "")),
                    str(n.get("ihaleAdi", "")),
                    str(n.get("idareAdi", "")),
                    str(n.get("il", "")),
                ]))
                if all(tok in text for tok in tokens):
                    rows.append(n)
        else:
            rows = list(self._all_notifications)

        if secili_tur:
            rows = [n for n in rows if self._tur_uygun_mu(n, secili_tur)]

        # Sort
        col = self._live_sort_col
        asc = self._live_sort_asc

        def sort_key(n):
            if col == "found_at":
                if self.mode == MODE_DT:
                    return self._sort_datetime(n.get("ilanTarihi"))
                return str(n.get("found_at", ""))
            if col == "ikn":
                return str(n.get("ikn", ""))
            if col == "ihale_adi":
                return tr_fold(n.get("ihaleAdi", ""))
            if col == "idare_adi":
                return tr_fold(n.get("idareAdi", ""))
            if col == "ihale_tarihi":
                # "11.12.2026 11:00" metnini duz siralamak gun bazli yanlis
                # sonuc veriyordu; gercek tarihe cevirip sirala.
                return self._sort_datetime(n.get("ihaleTarihSaat"))
            if col == "ihale_durumu":
                return tr_fold(n.get("ihaleDurumAciklama", ""))
            return ""

        rows.sort(key=sort_key, reverse=not asc)

        # Rebuild tree
        for iid in self._tree.get_children():
            self._tree.delete(iid)
        self._urls.clear()

        for n in rows:
            ikn = n.get("ikn", "")
            if not ikn:
                continue
            try:
                self._tree.insert("", "end", iid=ikn,
                                  values=self._satir_degerleri(n),
                                  tags=("tek" if len(self._urls) % 2 else "cift",))
            except tk.TclError:
                pass
            self._urls[ikn] = n.get("url", EKAP_URL)

        self._tree.tag_configure("cift", background=C_ROWBASE)
        self._tree.tag_configure("tek", background=C_ROWALT)

        # Update column heading arrows
        if hasattr(self, "_live_head_labels"):
            for c, label in self._live_head_labels.items():
                arrow = (" ▲" if asc else " ▼") if c == col else ""
                self._tree.heading(c, text=label + arrow)

        # Update count label
        total = len(self._all_notifications)
        shown = len(rows)
        if hasattr(self, "_live_count_lbl"):
            suzgecli = bool(query or secili_tur)
            birim = "duyuru" if self.mode == MODE_DT else "ihale"
            self._live_count_lbl.config(
                text=f"{shown} / {total} {birim}" if suzgecli else f"{total} {birim}")


    def _insert_row(self, n: dict, highlight: bool = True):
        ikn = n.get("ikn", "")
        if not ikn:
            return
        found_str = self._fmt_dt(n.get("found_at"))[:16]
        tarih_raw = n.get("ihaleTarihSaat") or ""
        try:
            tarih_str = datetime.fromisoformat(tarih_raw).strftime("%d.%m.%Y %H:%M")
        except Exception:
            tarih_str = str(tarih_raw)[:16]

        tag = "new" if highlight else ""
        durum_str = n.get("ihaleDurumAciklama", "")
        try:
            self._tree.insert("", 0, iid=ikn,
                               values=(found_str, ikn,
                                       n.get("ihaleAdi", "—"),
                                       n.get("idareAdi", "—"),
                                       tarih_str,
                                       durum_str),
                               tags=(tag,))
        except tk.TclError:
            pass  # Ayni IKN zaten listede

        self._tree.tag_configure("new", background=C_ROWHI)
        self._urls[ikn] = n.get("url", EKAP_URL)

        if highlight:
            self.after(NEW_ROW_TIMEOUT,
                       lambda i=ikn: self._clear_highlight(i))

    def _clear_highlight(self, ikn: str):
        try:
            self._tree.item(ikn, tags=())
        except tk.TclError:
            pass

    def _refresh_info(self, yeni: int = None):
        """Ust seritteki sayi kartlarini tazeler."""
        try:
            self._stat_takip.config(text=str(len(self.store.known_ikns)))
            self._stat_liste.config(text=str(len(self._all_notifications)))
            if yeni is not None:
                self._stat_yeni.config(text=str(yeni))
            lc = self.store.last_check
            self._stat_kontrol.config(
                text=self._fmt_dt(lc)[11:19] if lc else "—")
        except Exception:
            pass

    # ── Izleme ────────────────────────────────────────────────────────────────
    def _read_interval(self) -> int:
        """Aralik kutusu bos/gecersizse varsayilana don — asla istisna atma.

        Aksi halde kutu bosken 'Uygula' basildiginda TclError olusuyor ve
        eski thread durdurulmus oldugu icin izleme tamamen duruyordu.
        """
        try:
            value = int(self._interval.get())
        except Exception:
            value = CHECK_INTERVAL
        if value < 30:
            value = 30
        try:
            self._interval.set(value)
        except Exception:
            pass
        return value

    def _start_monitor(self):
        interval = self._read_interval()
        self._thread = MonitorThread(self.store, self._q, interval, self.mode)
        self._thread.start()

    def _restart_monitor(self):
        interval = self._read_interval()
        if self._thread and self._thread.is_alive():
            self._thread.stop()
            self._thread.join(timeout=3)
        self._start_monitor()
        self._set_status(f"İzleme yeniden başlatıldı ({interval} sn aralıklarla)", "ok")

    def _manual_scan(self):
        """Trigger an immediate scan without restarting the thread."""
        if self._thread and self._thread.is_alive():
            self._thread.trigger_check()
            self._set_status("Manuel tarama başlatıldı...", "info")
        else:
            self._restart_monitor()

    # ── Kuyruk yoklamasi ──────────────────────────────────────────────────────
    def _poll(self):
        try:
            while True:
                kind, *rest = self._q.get_nowait()
                if kind == "STATUS":
                    msg   = rest[0]
                    level = rest[1] if len(rest) > 1 else "info"
                    self._set_status(msg, level)
                elif kind == "NEW_ITEM":
                    # Liste zaten hemen ardindan gelen NOTIFICATION_REFRESH ile
                    # tazeleniyor; burada sadece masaustu bildirimi gosterilir.
                    self._win_notify(rest[0])
                elif kind == "NOTIFICATION_REFRESH":
                    self._all_notifications = list(rest[0]) if rest else []
                    self._reload_notification_views()
                elif kind == "DOWNLOAD_DONE":
                    file_path = rest[0]
                    self._downloading = False
                    self._set_status(f"Dokuman indirildi: {file_path}", "ok")
                    self._refresh_pdf_file_list()
                    # Dosya nereye indi gorunsun diye PDF Analiz sekmesine gec
                    try:
                        self._tabs.select(self._tab_pdf)
                    except Exception:
                        pass
                    # Yeni dosyayı listede otomatik seç
                    try:
                        target = Path(file_path)
                        for i, p in enumerate(self._pdf_file_paths):
                            if p == target:
                                self._pdf_listbox.selection_clear(0, "end")
                                self._pdf_listbox.selection_set(i)
                                self._pdf_listbox.see(i)
                                break
                    except Exception:
                        pass
                elif kind == "DOWNLOAD_FAIL":
                    msg = rest[0]
                    self._downloading = False
                    self._set_status(f"Indirme basarisiz: {msg}", "error")
                elif kind == "DEEP_RESULT":
                    ifade = rest[0]
                    kayitlar = rest[1]
                    if kayitlar is None:
                        self._set_status(
                            f"İlan içi arama başarısız: {rest[2] if len(rest) > 2 else ''}",
                            "error")
                    else:
                        self._render_filter_rows(
                            kayitlar, self._split_keywords(),
                            f"EKAP'ta '{ifade}' araması")
                        if kayitlar:
                            self._set_status(
                                f"İlan içeriğinde arama tamamlandı: '{ifade}' → "
                                f"{len(kayitlar)} sonuç", "ok")
                        else:
                            # EKAP Turkce karakterlere birebir duyarli; ASCII
                            # yazilmissa kullaniciya bunu hatirlat.
                            ipucu = ""
                            if ifade == tr_fold(ifade):
                                ipucu = ("  —  EKAP Türkçe karaktere duyarlıdır; "
                                         "'ü, ı, ş, ğ, ö, ç' harflerini kullanarak "
                                         "yazmayı deneyin")
                            self._set_status(
                                f"İlan içeriğinde arama: '{ifade}' → sonuç yok{ipucu}",
                                "warn")
                        self._tabs.select(self._tab_filter)
                elif kind == "PDF_SCAN_RESULT":
                    msg = rest[0]
                    self._set_status(msg, "ok")
                elif kind == "PDF_SCAN_DETAIL":
                    rows = rest[1]
                    summary = rest[0] if rest else ""
                    self._render_pdf_analysis(rows, summary)
                    self._tabs.select(self._tab_pdf)
                elif kind == "PDF_SCAN_MULTI":
                    summary = rest[0] if rest else ""
                    rows = rest[1] if len(rest) > 1 else []
                    self._render_pdf_analysis(rows, summary)
                    self._tabs.select(self._tab_pdf)
        except queue.Empty:
            pass
        except Exception as e:
            # Tek bir bozuk mesaj yuzunden UI guncellemesinin kalici olarak
            # durmamasi icin: hatayi yut, dongu her halukarda devam etsin.
            print(f"[UI] Kuyruk mesaji islenemedi: {e}")
        # Pencere kapandiysa yeni tur planlama (aksi halde kapanista
        # "invalid command name ..._poll" uyarisi olusuyor).
        try:
            self._poll_id = self.after(250, self._poll)
        except tk.TclError:
            pass

    def _set_status(self, msg: str, level: str = "info"):
        colors = {"ok": C_GREEN, "error": C_RED,
                  "warn": C_YELLOW, "stopped": C_MUTED}
        self._dot.config(fg=colors.get(level, C_ACCENT))
        # Uzun mesajlar seridi tasirmasin
        kisa = msg if len(msg) <= 78 else msg[:75] + "..."
        self._status_lbl.config(text=kisa,
                                fg=C_RED if level == "error" else C_TEXT)
        # Tam metni ipucu olarak sakla
        self._status_lbl._tam_mesaj = msg
        now_str = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
        self._footer_lbl.config(
            text=(f"  Son kontrol: {now_str}"
                  "   |   Cift tik: dokumani indir  |  Sag tik: ihaleyi tarayicida ac"))

    # ── Acilan URL ────────────────────────────────────────────────────────────
    def _open_url(self, event=None):
        sel = self._tree.selection()
        if not sel:
            return
        url = self._urls.get(sel[0], EKAP_URL)
        webbrowser.open(url)

    # ── Temizle ───────────────────────────────────────────────────────────────
    def _open_download_dir(self, path=None):
        """Indirilen dokumanlar klasorunu Dosya Gezgini'nde acar."""
        hedef = Path(path) if path else DOWNLOAD_DIR
        try:
            DOWNLOAD_DIR.mkdir(exist_ok=True)
            if hedef.is_file():
                # Dosyayi Gezgin'de secili halde goster
                subprocess.Popen(["explorer", "/select,", str(hedef)])
            else:
                os.startfile(str(hedef))
            self._set_status(f"Klasor acildi: {hedef}", "ok")
        except Exception as e:
            self._set_status(f"Klasor acilamadi: {e}", "error")

    def _clear_history(self):
        if not messagebox.askyesno(
                "Gecmisi Temizle",
                "Listelenen tum bildirimler silinecek.\n"
                "Takip edilen IKN kayitlari tutulacak.\nDevam edilsin mi?"):
            return
        for iid in self._tree.get_children():
            self._tree.delete(iid)
        for iid in self._filter_tree.get_children():
            self._filter_tree.delete(iid)
        self._urls.clear()
        self._filtered_urls.clear()
        self._all_notifications = []
        self._group_text.configure(state="normal")
        self._group_text.delete("1.0", "end")
        self._group_text.configure(state="disabled")
        for iid in self._pdf_tree.get_children():
            self._pdf_tree.delete(iid)
        self._pdf_summary.configure(state="normal")
        self._pdf_summary.delete("1.0", "end")
        self._pdf_summary.configure(state="disabled")
        self.store.clear_notifications()
        self.store.save()
        self._refresh_idare_choices()
        self._refresh_info()

    def _build_filter_tab(self):
        kok = tk.Frame(self._tab_filter, bg=C_BG)
        kok.pack(fill="both", expand=True, pady=(8, 0))

        # ══ ARAMA KARTI ══
        kart = tk.Frame(kok, bg=C_PANEL, padx=12, pady=10,
                        highlightthickness=1, highlightbackground=C_BORDER)
        kart.pack(fill="x")

        st1 = tk.Frame(kart, bg=C_PANEL)
        st1.pack(fill="x")
        tk.Label(st1, text="Aranacak kelimeler", bg=C_PANEL, fg=C_MUTED,
                 font=("Segoe UI", 9)).pack(side="left", padx=(0, 8))
        self._keywords_entry = tk.Entry(
            st1, textvariable=self._keywords_var, bg=C_SURFACE, fg=C_TEXT,
            insertbackground=C_TEXT, relief="flat", font=("Segoe UI", 10))
        self._keywords_entry.pack(side="left", fill="x", expand=True, ipady=5)
        self._keywords_entry.bind("<Return>", lambda e: self._apply_filters())

        self._btn(st1, "Filtrele", self._apply_filters, "primary",
                  bold=True).pack(side="right", padx=(8, 0))
        self._btn(st1, "Sıfırla", self._reset_filters,
                  "ghost").pack(side="right", padx=(8, 0))

        st2 = tk.Frame(kart, bg=C_PANEL)
        st2.pack(fill="x", pady=(9, 0))
        derin = tk.Checkbutton(
            st2, text="İlan içeriğinde de ara  (EKAP'a sorar — başlıkta geçmeyen"
                      " ilanları da bulur)",
            variable=self._deep_search_var, bg=C_PANEL, fg=C_TEXT,
            selectcolor=C_SURFACE, activebackground=C_PANEL,
            activeforeground=C_TEXT, font=("Segoe UI", 9), bd=0,
            highlightthickness=0)
        derin.pack(side="left")

        tk.Label(st2, text="Bitiş", bg=C_PANEL, fg=C_MUTED,
                 font=("Segoe UI", 9)).pack(side="right", padx=(8, 6))
        self._date_to_entry = tk.Entry(
            st2, textvariable=self._date_to_var, width=12, bg=C_SURFACE,
            fg=C_TEXT, insertbackground=C_TEXT, relief="flat",
            justify="center", font=("Segoe UI", 9))
        self._date_to_entry.pack(side="right", ipady=4)
        tk.Label(st2, text="Başlangıç", bg=C_PANEL, fg=C_MUTED,
                 font=("Segoe UI", 9)).pack(side="right", padx=(14, 6))
        self._date_from_entry = tk.Entry(
            st2, textvariable=self._date_from_var, width=12, bg=C_SURFACE,
            fg=C_TEXT, insertbackground=C_TEXT, relief="flat",
            justify="center", font=("Segoe UI", 9))
        self._date_from_entry.pack(side="right", ipady=4)
        tk.Label(st2, text="Tarih (gg.aa.yyyy)", bg=C_PANEL, fg=C_MUTED,
                 font=("Segoe UI", 8)).pack(side="right", padx=(0, 6))

        st3 = tk.Frame(kart, bg=C_PANEL)
        st3.pack(fill="x", pady=(9, 0))
        tk.Label(st3, text="Tür", bg=C_PANEL, fg=C_MUTED,
                 font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 8))
        self._tur_rozetleri(st3, lambda: None).pack(side="left")
        tk.Label(st3, text="(seçim yoksa tümü)", bg=C_PANEL, fg=C_MUTED,
                 font=("Segoe UI", 8)).pack(side="left", padx=(8, 0))

        self._filter_hint = tk.Label(
            kart,
            text="Birden fazla kelimeyi boşlukla ayırın. Normal aramada her kelime "
                 "ayrı aranır; ilan içeriği aramasında hepsi birlikte aranır.  "
                 "İlan içeriği aramasında Türkçe karakterleri tam yazın (kanül, bakım).",
            bg=C_PANEL, fg=C_MUTED, font=("Segoe UI", 8), anchor="w")
        self._filter_hint.pack(fill="x", pady=(8, 0))

        # ══ ICERIK: sol il paneli + sag sonuclar ══
        content = tk.Frame(kok, bg=C_BG)
        content.pack(fill="both", expand=True, pady=(10, 8))

        sol = tk.Frame(content, bg=C_PANEL, padx=10, pady=10, width=250,
                       highlightthickness=1, highlightbackground=C_BORDER)
        sol.pack(side="left", fill="y", padx=(0, 10))
        sol.pack_propagate(False)

        tk.Label(sol, text="BÖLGE / İL", bg=C_PANEL, fg=C_MUTED,
                 font=("Segoe UI", 8, "bold")).pack(anchor="w")
        self._il_arama_var = tk.StringVar()
        il_ara = tk.Entry(sol, textvariable=self._il_arama_var, bg=C_SURFACE,
                          fg=C_TEXT, insertbackground=C_TEXT, relief="flat",
                          font=("Segoe UI", 9))
        il_ara.pack(fill="x", pady=(6, 8), ipady=4)
        self._il_arama_var.trace_add("write", lambda *_: self._refresh_idare_choices())

        # Bolge > il agaci. Bir bolge secilince altindaki tum iller
        # secilmis sayilir; tek tek il secmek de mumkun.
        idare_wrap = tk.Frame(sol, bg=C_PANEL)
        idare_wrap.pack(fill="both", expand=True)
        self._il_tree = ttk.Treeview(
            idare_wrap, show="tree", selectmode="extended",
            style="EKAP.Treeview")
        self._il_tree.column("#0", width=200, stretch=True)
        idare_scroll = ttk.Scrollbar(idare_wrap, orient="vertical",
                                     command=self._il_tree.yview)
        self._il_tree.configure(yscrollcommand=idare_scroll.set)
        self._il_tree.pack(side="left", fill="both", expand=True)
        idare_scroll.pack(side="left", fill="y")
        self._il_tree.tag_configure("bolge", foreground=C_BRAND_LT,
                                    font=("Segoe UI", 9, "bold"))
        self._il_tree.bind("<<TreeviewSelect>>",
                           lambda e: self._il_secim_bilgisi())

        btn_row = tk.Frame(sol, bg=C_PANEL)
        btn_row.pack(fill="x", pady=(8, 0))
        self._btn(btn_row, "Tümü", self._select_all_idare, "ghost",
                  pad=10).pack(side="left")
        self._btn(btn_row, "Temizle", self._clear_idare_selection, "ghost",
                  pad=10).pack(side="left", padx=6)
        self._il_bilgi_lbl = tk.Label(sol, text="", bg=C_PANEL, fg=C_MUTED,
                                      font=("Segoe UI", 8))
        self._il_bilgi_lbl.pack(anchor="w", pady=(6, 0))

        sag = tk.Frame(content, bg=C_BG)
        sag.pack(side="left", fill="both", expand=True)

        table_wrap = tk.Frame(sag, bg=C_BG)
        table_wrap.pack(fill="both", expand=True)
        cols, heads = self._sutun_tanimi(filtre=True)
        self._filter_tree = ttk.Treeview(
            table_wrap, columns=cols, show="headings",
            style="EKAP.Treeview", selectmode="browse")
        for col, head, width, anch in heads:
            self._filter_tree.heading(col, text=head,
                                      anchor="w" if anch == "w" else "center")
            self._filter_tree.column(col, width=width, anchor=anch, minwidth=70,
                                     stretch=(col in ("ihale_adi", "idare_adi")))

        f_vsb = ttk.Scrollbar(table_wrap, orient="vertical", command=self._filter_tree.yview)
        f_hsb = ttk.Scrollbar(table_wrap, orient="horizontal", command=self._filter_tree.xview)
        self._filter_tree.configure(yscrollcommand=f_vsb.set, xscrollcommand=f_hsb.set)
        self._filter_tree.grid(row=0, column=0, sticky="nsew")
        f_vsb.grid(row=0, column=1, sticky="ns")
        f_hsb.grid(row=1, column=0, sticky="ew")
        table_wrap.rowconfigure(0, weight=1)
        table_wrap.columnconfigure(0, weight=1)
        self._filter_tree.bind("<Double-Button-1>", self._download_selected_item)
        self._filter_tree.bind("<Return>", self._download_selected_item)
        self._filter_tree.bind("<Button-3>", self._open_filtered_url)
        self._filter_tree.bind("<<TreeviewSelect>>", self._on_row_selected)

        ozet = tk.Frame(sag, bg=C_BG)
        ozet.pack(fill="x", pady=(8, 0))
        baslik_sat = tk.Frame(ozet, bg=C_BG)
        baslik_sat.pack(fill="x")
        tk.Label(baslik_sat, text="Kelimeye göre dağılım", bg=C_BG, fg=C_TEXT,
                 font=("Segoe UI", 9, "bold")).pack(side="left")
        self._filter_count_lbl = tk.Label(baslik_sat, text="", bg=C_BG,
                                          fg=C_MUTED, font=("Segoe UI", 9, "bold"))
        self._filter_count_lbl.pack(side="right")

        g_wrap = tk.Frame(ozet, bg=C_BG)
        g_wrap.pack(fill="x", pady=(4, 0))
        self._group_text = tk.Text(
            g_wrap, bg=C_PANEL, fg=C_TEXT, relief="flat", height=7,
            font=("Consolas", 9), wrap="word", highlightthickness=1,
            highlightbackground=C_BORDER, padx=8, pady=6)
        g_scroll = ttk.Scrollbar(g_wrap, orient="vertical", command=self._group_text.yview)
        self._group_text.configure(yscrollcommand=g_scroll.set)
        self._group_text.pack(side="left", fill="both", expand=True)
        g_scroll.pack(side="left", fill="y")
        self._group_text.configure(state="disabled")

    def _secili_turler(self):
        """Isaretli turler; hicbiri isaretli degilse bos kume (= hepsi)."""
        return {ad for ad, v in self._tur_vars.items() if v.get()}

    def _tur_uygun_mu(self, kayit, secili=None) -> bool:
        secili = self._secili_turler() if secili is None else secili
        if not secili:
            return True
        tur = str(kayit.get("tur") or kayit.get("dt_turu") or "").strip()
        return tur in secili

    TUR_RENKLERI = {"Mal": "#2F6FB8", "Hizmet": "#8B5CF6",
                    "Yapım": "#F59E0B", "Danışmanlık": "#14B8A6"}

    def _tur_rozetleri(self, parent, komut):
        """Mal / Hizmet / Yapım / Danışmanlık icin acilip kapanan rozetler.

        Ayni degiskenler iki sekmede de kullanildigi icin butun rozetler tek
        listede tutulur ve her tiklamada hepsi birden yeniden boyanir.
        """
        if not hasattr(self, "_rozetler"):
            self._rozetler = []
        kutu = tk.Frame(parent, bg=parent.cget("bg"))
        for ad, v in self._tur_vars.items():
            renk = self.TUR_RENKLERI.get(ad, C_BRAND)
            b = tk.Checkbutton(
                kutu, text=ad, variable=v,
                bg=C_SURFACE, fg=C_MUTED, selectcolor=C_SURFACE,
                font=("Segoe UI", 9), bd=0, highlightthickness=0,
                indicatoron=False, padx=11, pady=5, cursor="hand2",
                relief="flat", offrelief="flat", overrelief="flat")
            b.config(command=lambda k=komut: (self._rozetleri_boya(), k()))
            b.pack(side="left", padx=(0, 5))
            self._rozetler.append((b, v, renk))
        self._rozetleri_boya()
        return kutu

    def _rozetleri_boya(self):
        """Rozetlerin rengini degiskenlerin son haline gore gunceller."""
        for b, v, renk in getattr(self, "_rozetler", []):
            try:
                if v.get():
                    b.config(bg=renk, fg="#ffffff", selectcolor=renk,
                             activebackground=renk, activeforeground="#ffffff")
                else:
                    b.config(bg=C_SURFACE, fg=C_MUTED, selectcolor=C_SURFACE,
                             activebackground=C_SURFACE, activeforeground=C_TEXT)
            except tk.TclError:
                pass

    def _il_secim_bilgisi(self):
        try:
            secili = self._il_tree.selection()
            bolge = sum(1 for i in secili if i.startswith("B::"))
            iller = len(self._selected_idareler())
            if not secili:
                metin = "Tümü (seçim yok)"
            elif bolge:
                metin = f"{bolge} bölge · {iller} il seçili"
            else:
                metin = f"{iller} il seçili"
            self._il_bilgi_lbl.config(text=metin)
        except Exception:
            pass

    # ── EKAP'ta ilan icinde arama ─────────────────────────────────────────
    def _deep_search(self, keywords):
        """Kelimeleri EKAP'in kendi arama servisine sorar.

        Yerel arama yalnizca listedeki basliklarda gezer; EKAP'in arananIfade
        parametresi ilan METNINDE de arar, bu yuzden basligi eslesmese bile
        ilgili duyurulari bulur.
        """
        if self.mode != MODE_DT:
            self._set_status(
                "İlan içeriğinde arama şimdilik yalnızca Doğrudan Temin modunda "
                "çalışıyor (ihale servisi oturum istiyor)", "warn")
            return False
        # DIKKAT: EKAP'in arama servisi Turkce karakterlere BIREBIR duyarli
        # ("kanül" -> 15 sonuc, "kanul" -> 0 sonuc). Yerel aramada kullandigimiz
        # sadelestirilmis (tr_fold) hali gonderilirse hicbir sey bulunamaz;
        # bu yuzden kullanicinin YAZDIGI metin oldugu gibi gonderilir.
        ifade = " ".join(self._keywords_var.get().split()).strip()
        if not ifade:
            ifade = " ".join(keywords).strip()
        if not ifade:
            return False
        iller = self._selected_idareler()
        il_kodu = ""
        if len(iller) == 1:
            ad = next(iter(iller))
            for kod, il_adi in DT_ILLER.items():
                if il_adi == ad:
                    il_kodu = kod
                    break
        tur_kodu = ""
        secili = self._secili_turler()
        if len(secili) == 1:
            ad = next(iter(secili))
            for kod, tur_adi in DT_TURLER.items():
                if tur_adi == ad:
                    tur_kodu = kod
                    break
        # Onceki arama surerken yenisi baslarsa Playwright surucusu cakisip
        # "EPIPE / broken pipe" veriyor; tek seferde tek arama.
        if getattr(self, "_deep_calisiyor", False):
            self._set_status("Önceki ilan içi arama sürüyor, lütfen bekleyin...",
                             "warn")
            return True
        self._deep_calisiyor = True
        self._set_status(f"EKAP'ta ilan içeriğinde aranıyor: {ifade}...", "info")
        threading.Thread(target=self._deep_search_worker,
                         args=(ifade, il_kodu, tur_kodu), daemon=True).start()
        return True

    def _deep_search_worker(self, ifade: str, il_kodu: str, tur_kodu: str = ""):
        from urllib.parse import quote
        try:
            from playwright.sync_api import sync_playwright as _sp
            with _sp() as pw:
                br = pw.chromium.launch(headless=True)
                ctx = br.new_context()
                bulunan = []
                for sayfa in range(1, DT_ARAMA_SAYFA + 1):
                    url = (f"{DT_DATA_URL}?ES=&ihaleidListesi=&dtBilgiSecim=1"
                           f"&metot=dtAra&orderBy=10&pageIndex={sayfa}"
                           f"&dtDurum={DT_STATUS_OPEN}&arananIfade={quote(ifade)}")
                    if il_kodu:
                        url += f"&ilID={il_kodu}"
                    if tur_kodu:
                        url += f"&dtTuru={tur_kodu}"
                    r = ctx.request.get(url, timeout=60_000)
                    if r.status != 200:
                        break
                    arr = r.json().get("yeniDogrudanTeminAramaResultList") or []
                    if not arr:
                        break
                    bulunan.extend(arr)

                # Hic sonuc yoksa: kullanici Turkce karakter kullanmadan
                # yazmis olabilir ("kanul"). Sadelestirilmis halle bir daha
                # dene; EKAP metni ASCII yazilmis kayitlar icin ise yarar.
                yedek = tr_fold(ifade)
                if not bulunan and yedek and yedek != ifade.lower():
                    url = (f"{DT_DATA_URL}?ES=&ihaleidListesi=&dtBilgiSecim=1"
                           f"&metot=dtAra&orderBy=10&pageIndex=1"
                           f"&dtDurum={DT_STATUS_OPEN}&arananIfade={quote(yedek)}")
                    if il_kodu:
                        url += f"&ilID={il_kodu}"
                    if tur_kodu:
                        url += f"&dtTuru={tur_kodu}"
                    try:
                        r = ctx.request.get(url, timeout=60_000)
                        if r.status == 200:
                            bulunan = r.json().get("yeniDogrudanTeminAramaResultList") or []
                    except Exception:
                        pass
                br.close()
            now = datetime.now()
            kayitlar, gorulen = [], set()
            for it in bulunan:
                dtn = str(it.get("E1") or "").strip()
                if not dtn or dtn in gorulen:
                    continue
                gorulen.add(dtn)
                kayitlar.append(dt_to_record(it, now))
            self._q.put(("DEEP_RESULT", ifade, kayitlar))
        except Exception as e:
            self._q.put(("DEEP_RESULT", ifade, None, str(e)))
        finally:
            self._deep_calisiyor = False

    def _render_filter_rows(self, filtered, keywords, kaynak=""):
        """Filtre sonuclarini tabloya basar."""
        self._filtered_urls.clear()
        for iid in self._filter_tree.get_children():
            self._filter_tree.delete(iid)

        for idx, item in enumerate(filtered):
            iid = f"f_{idx}_{item.get('ikn', '')}"
            self._filter_tree.insert(
                "", "end", iid=iid,
                values=self._satir_degerleri(item, filtre=True),
                tags=("tek" if idx % 2 else "cift",))
            self._filtered_urls[iid] = item.get("url", EKAP_URL)

        self._filter_tree.tag_configure("cift", background=C_ROWBASE)
        self._filter_tree.tag_configure("tek", background=C_ROWALT)
        self._filter_count_lbl.config(
            text=f"{len(filtered)} sonuç{('  ·  ' + kaynak) if kaynak else ''}")
        self._render_grouped_keywords(keywords, filtered)

    def _split_keywords(self):
        raw = tr_fold(self._keywords_var.get().strip())
        if not raw:
            return []
        tokens = [t for t in re.split(r"[,;\n\t ]+", raw) if t]
        seen = set()
        ordered = []
        for t in tokens:
            if t not in seen:
                seen.add(t)
                ordered.append(t)
        return ordered

    @staticmethod
    def _parse_date_input(value: str):
        value = (value or "").strip()
        if not value:
            return None
        for fmt in ("%d.%m.%Y", "%Y-%m-%d", "%d/%m/%Y"):
            try:
                return datetime.strptime(value, fmt).date()
            except ValueError:
                continue
        return None

    def _item_date(self, item: dict):
        for key in ("ihaleTarihSaat", "found_at"):
            raw = str(item.get(key) or "").strip()
            if not raw:
                continue
            raw = raw.replace("Z", "")
            try:
                return datetime.fromisoformat(raw).date()
            except ValueError:
                pass
            for fmt in ("%d.%m.%Y %H:%M", "%d.%m.%Y", "%Y-%m-%d %H:%M:%S"):
                try:
                    return datetime.strptime(raw, fmt).date()
                except ValueError:
                    continue
        return None

    def _refresh_idare_choices(self):
        """Sol panelde IL listesini kurar (eskiden idare adlariydi).

        Il, idare adindan cok daha kullanisli: 300+ farkli idare yerine
        en fazla 81 secenek cikiyor ve yaninda kayit sayisi gosteriliyor.
        """
        if not hasattr(self, "_il_tree"):
            return
        secili = set(self._il_tree.selection())
        rows = self._all_notifications or list(self.store.notifications)
        sayac = {}
        for n in rows:
            il = str(n.get("il", "")).strip() or "(Belirtilmemiş)"
            sayac[il] = sayac.get(il, 0) + 1
        # Sol paneldeki kucuk arama kutusu hem bolge hem il adinda arar
        sorgu = tr_fold(getattr(self, "_il_arama_var", None).get()
                        if hasattr(self, "_il_arama_var") else "")

        # Illeri bolgelere dagit
        bolgeler = {}
        for il, adet in sayac.items():
            b = il_bolgesi(il) if il != "(Belirtilmemiş)" else BOLGE_DISI
            bolgeler.setdefault(b, []).append((il, adet))

        for iid in self._il_tree.get_children():
            self._il_tree.delete(iid)
        self._il_bolge_iller = {}

        sirali_bolge = sorted(bolgeler.items(), key=lambda kv: tr_fold(kv[0]))
        for bolge, iller in sirali_bolge:
            iller.sort(key=lambda kv: tr_fold(kv[0]))
            if sorgu and sorgu not in tr_fold(bolge):
                iller = [(i, n) for i, n in iller if sorgu in tr_fold(i)]
                if not iller:
                    continue
            toplam = sum(n for _, n in iller)
            b_iid = f"B::{bolge}"
            self._il_tree.insert("", "end", iid=b_iid,
                                 text=f"{bolge}  ({toplam})",
                                 open=bool(sorgu), tags=("bolge",))
            self._il_bolge_iller[b_iid] = [i for i, _ in iller]
            for il, adet in iller:
                self._il_tree.insert(b_iid, "end", iid=f"I::{il}",
                                     text=f"{il}  ({adet})")

        for iid in secili:
            try:
                self._il_tree.selection_add(iid)
                ust = self._il_tree.parent(iid)
                if ust:
                    self._il_tree.item(ust, open=True)
            except Exception:
                pass
        self._il_secim_bilgisi()

    def _selected_idareler(self):
        """Secili il adlarini dondurur; bolge secildiyse altindaki tum iller."""
        secili = set()
        for iid in self._il_tree.selection():
            if iid.startswith("I::"):
                secili.add(iid[3:])
            elif iid.startswith("B::"):
                secili.update(getattr(self, "_il_bolge_iller", {}).get(iid, []))
        return secili

    def _apply_filters(self):
        if not hasattr(self, "_filter_tree"):
            return

        keywords = self._split_keywords()
        date_from = self._parse_date_input(self._date_from_var.get())
        date_to = self._parse_date_input(self._date_to_var.get())

        if self._date_from_var.get().strip() and date_from is None:
            messagebox.showwarning("Tarih Formati", "Baslangic tarihi gecersiz. Ornek: 13.04.2026")
            return
        if self._date_to_var.get().strip() and date_to is None:
            messagebox.showwarning("Tarih Formati", "Bitis tarihi gecersiz. Ornek: 13.04.2026")
            return
        if date_from and date_to and date_from > date_to:
            messagebox.showwarning("Tarih Formati", "Baslangic tarihi bitis tarihinden buyuk olamaz.")
            return

        selected_idareler = self._selected_idareler()
        secili_tur = self._secili_turler()

        # "İlan içeriğinde de ara" isaretliyse sorguyu EKAP'a gonder.
        if keywords and self._deep_search_var.get():
            if self._deep_search(keywords):
                return

        filtered = []
        for item in self._all_notifications:
            item_date = self._item_date(item)
            if date_from and (item_date is None or item_date < date_from):
                continue
            if date_to and (item_date is None or item_date > date_to):
                continue
            il = str(item.get("il", "")).strip() or "(Belirtilmemiş)"
            if selected_idareler and il not in selected_idareler:
                continue
            if not self._tur_uygun_mu(item, secili_tur):
                continue

            if keywords:
                text = tr_fold(" ".join([
                    str(item.get("ikn", "")),
                    str(item.get("ihaleAdi", "")),
                    str(item.get("idareAdi", "")),
                    str(item.get("il", "")),
                ]))
                if not any(k in text for k in keywords):
                    continue
            filtered.append(item)

        self._render_filter_rows(filtered, keywords, "listeden")

    def _render_grouped_keywords(self, keywords, filtered):
        self._group_text.configure(state="normal")
        self._group_text.delete("1.0", "end")

        if not filtered:
            self._group_text.insert("end", "Filtreye uygun veri bulunamadi.\n")
            self._group_text.configure(state="disabled")
            return

        if not keywords:
            self._group_text.insert(
                "end",
                f"Toplam {len(filtered)} kayit listelendi. Kelime girerseniz her kelime icin ayri gruplama gorunur.\n"
            )
            self._group_text.configure(state="disabled")
            return

        for kw in keywords:
            self._group_text.insert("end", f"\n[{kw}]\n")
            count = 0
            for item in filtered:
                text = tr_fold(" ".join([
                    str(item.get("ikn", "")),
                    str(item.get("ihaleAdi", "")),
                    str(item.get("idareAdi", "")),
                ]))
                if kw in text:
                    count += 1
                    self._group_text.insert(
                        "end",
                        f"- {item.get('ikn', '')} | {item.get('ihaleAdi', '—')} | {item.get('idareAdi', '—')}\n"
                    )
            if count == 0:
                self._group_text.insert("end", "- Eslesen kayit yok\n")

        self._group_text.configure(state="disabled")

    def _reset_filters(self):
        for v in self._tur_vars.values():
            v.set(False)
        self._rozetleri_boya()
        self._keywords_var.set("")
        self._date_from_var.set("")
        self._date_to_var.set("")
        self._clear_idare_selection()
        self._apply_filters()

    def _select_all_idare(self):
        """Tum bolgeleri secer (dolayisiyla tum iller)."""
        self._il_tree.selection_set(self._il_tree.get_children())
        self._il_secim_bilgisi()

    def _clear_idare_selection(self):
        self._il_tree.selection_remove(self._il_tree.selection())
        self._il_secim_bilgisi()

    def _open_filtered_url(self, event=None):
        sel = self._filter_tree.selection()
        if not sel:
            return
        url = self._filtered_urls.get(sel[0], EKAP_URL)
        webbrowser.open(url)

    def _sartname_sekmesi_kur(self):
        """Sartname Okuma sekmesini olusturur; hata halinde None doner."""
        try:
            from sartname.arayuz import SartnameSekmesi
        except Exception as e:                       # paket/bagimlilik eksik
            print(f"[sartname] sekme yuklenemedi: {e}")
            return None
        renkler = {
            "BG": C_BG, "PANEL": C_PANEL, "SURFACE": C_SURFACE,
            "BORDER": C_BORDER, "TEXT": C_TEXT, "MUTED": C_MUTED,
            "ACCENT": C_ACCENT, "GREEN": C_GREEN, "YELLOW": C_YELLOW,
            "RED": C_RED, "ROWALT": C_ROWALT,
        }
        try:
            return SartnameSekmesi(self._tabs, renkler, self._btn,
                                   DOWNLOAD_DIR, SARTNAME_DIR)
        except Exception as e:                       # noqa: BLE001
            print(f"[sartname] sekme olusturulamadi: {e}")
            return None

    def _build_pdf_tab(self):
        # ── Üst araç çubuğu ───────────────────────────────────────────────
        top = tk.Frame(self._tab_pdf, bg=C_BG, pady=6, padx=8)
        top.pack(fill="x")
        tk.Label(top, text="Üstteki \"Belge içinde ara\" kutusundaki kelimeler, indirilen belgelerde aranır  ·  PDF / DOCX / DOC / HTML",
                 bg=C_BG, fg=C_MUTED, font=("Segoe UI", 8)).pack(side="left")
        self._btn(top, "Tümünü Tara", self._scan_all_pdfs,
                  "ghost").pack(side="right", padx=(4, 0))
        self._btn(top, "Seçileni Tara", self._scan_selected_pdfs,
                  "primary", bold=True).pack(side="right", padx=(4, 0))
        self._btn(top, "↻  Yenile", self._refresh_pdf_file_list,
                  "ghost", pad=8).pack(side="right", padx=(4, 0))
        self._btn(top, "📂  Klasörü Aç", self._open_selected_in_explorer,
                  "accent").pack(side="right", padx=(4, 0))

        # ── Yatay bölünmüş alan: sol=dosya listesi, sağ=sonuçlar ─────────
        paned = tk.PanedWindow(self._tab_pdf, bg=C_BG, orient="horizontal",
                               sashwidth=6, sashrelief="flat", bd=0)
        paned.pack(fill="both", expand=True, padx=8, pady=(0, 4))

        # SOL panel – indirilen dosyalar
        left = tk.Frame(paned, bg=C_BG)
        paned.add(left, minsize=160, width=240)
        tk.Label(left, text="İndirilen Belgeler", bg=C_BG, fg=C_TEXT,
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(4, 2))
        lbx_wrap = tk.Frame(left, bg=C_BG)
        lbx_wrap.pack(fill="both", expand=True)
        self._pdf_listbox = tk.Listbox(
            lbx_wrap, bg=C_PANEL, fg=C_TEXT, selectmode="extended",
            relief="flat", activestyle="dotbox", font=("Segoe UI", 9),
            selectbackground=C_ACCENT, selectforeground="#fff", bd=0
        )
        lbx_vsb = ttk.Scrollbar(lbx_wrap, orient="vertical",
                                 command=self._pdf_listbox.yview)
        self._pdf_listbox.configure(yscrollcommand=lbx_vsb.set)
        self._pdf_listbox.pack(side="left", fill="both", expand=True)
        lbx_vsb.pack(side="right", fill="y")
        # Çift tıkla tara
        self._pdf_listbox.bind("<Double-1>", lambda e: self._scan_selected_pdfs())

        # SAĞ panel – arama sonuçları
        right = tk.Frame(paned, bg=C_BG)
        paned.add(right, minsize=300)

        cols = ("pdf", "keyword", "page", "count", "source", "snippet")
        self._pdf_tree = ttk.Treeview(right, columns=cols, show="headings",
                                      style="EKAP.Treeview")
        heads = [
            ("pdf",     "Belge",       240, "w"),
            ("keyword", "Kelime",      120, "center"),
            ("page",    "Sayfa",        60, "center"),
            ("count",   "Adet",         55, "center"),
            ("source",  "Kaynak",       80, "center"),
            ("snippet", "Bulunan yer (tamamı için satırı seçin)", 560, "w"),
        ]
        for col, head, width, anch in heads:
            self._pdf_tree.heading(col, text=head, anchor="center")
            self._pdf_tree.column(col, width=width, anchor=anch,
                                  stretch=(col == "snippet"))

        vsb = ttk.Scrollbar(right, orient="vertical",   command=self._pdf_tree.yview)
        hsb = ttk.Scrollbar(right, orient="horizontal", command=self._pdf_tree.xview)
        self._pdf_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self._pdf_tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        right.rowconfigure(0, weight=1)
        right.columnconfigure(0, weight=1)

        # Alt detay paneli: secili sonucun tam metni
        # side="bottom": tablo alani ne kadar buyurse buyusun detay paneli
        # her zaman altta yerini korur.
        detay = tk.Frame(self._tab_pdf, bg=C_BG, padx=8)
        detay.pack(side="bottom", fill="x", pady=(6, 8))
        tk.Label(detay, text="BULUNAN YERİN TAM METNİ", bg=C_BG, fg=C_MUTED,
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", pady=(0, 4))
        d_wrap = tk.Frame(detay, bg=C_BG)
        d_wrap.pack(fill="x")
        self._pdf_summary = tk.Text(
            d_wrap, bg=C_PANEL, fg=C_TEXT, relief="flat",
            height=9, font=("Segoe UI", 10), wrap="word",
            highlightthickness=1, highlightbackground=C_BORDER,
            padx=10, pady=8, spacing1=2, spacing3=4, cursor="arrow")
        d_scroll = ttk.Scrollbar(d_wrap, orient="vertical",
                                 command=self._pdf_summary.yview)
        self._pdf_summary.configure(yscrollcommand=d_scroll.set)
        self._pdf_summary.pack(side="left", fill="both", expand=True)
        d_scroll.pack(side="left", fill="y")
        self._pdf_summary.tag_configure("baslik", foreground=C_BRAND_LT,
                                        font=("Segoe UI", 10, "bold"))
        self._pdf_summary.tag_configure("vurgu", background="#F59E0B",
                                        foreground="#1a1a1a",
                                        font=("Segoe UI", 10, "bold"))
        self._pdf_summary.tag_configure("sira", foreground=C_MUTED,
                                        font=("Segoe UI", 9))
        self._pdf_summary.configure(state="disabled")

        self._pdf_rows = {}
        self._pdf_ozet_metni = ""
        self._pdf_tree.bind("<<TreeviewSelect>>", self._pdf_detay_goster)
        self._pdf_tree.bind("<Double-Button-1>", self._pdf_dosyayi_ac)

        # Yerlesim sirasi: tk.pack alani cagri sirasina gore dagitir. Tablo
        # alani once paketlendigi icin detay panelini asagi tasiyordu; tabloyu
        # yeniden paketleyerek sirayi cevir (once detay, sonra genisleyen tablo).
        paned.pack_forget()
        paned.pack(fill="both", expand=True, padx=8, pady=(0, 4))

        # İlk yükleme
        self._pdf_file_paths: list[Path] = []
        self._refresh_pdf_file_list()

    def _pdf_dosyayi_ac(self, event=None):
        """Sonuc satirina cift tiklayinca ilgili belgeyi Gezgin'de gosterir."""
        sec = self._pdf_tree.selection()
        satir = self._pdf_rows.get(sec[0]) if sec else None
        if not satir:
            return
        ad = satir.get("pdf", "")
        for yol in self._pdf_file_paths:
            if yol.name == ad:
                self._open_download_dir(yol)
                return
        self._open_download_dir()

    def _open_selected_in_explorer(self):
        """Sol listede secili dosyayi Gezgin'de gosterir; secim yoksa klasoru acar."""
        try:
            idx = list(self._pdf_listbox.curselection())
            if idx and idx[0] < len(self._pdf_file_paths):
                self._open_download_dir(self._pdf_file_paths[idx[0]])
                return
        except Exception:
            pass
        self._open_download_dir()

    def _refresh_pdf_file_list(self):
        """DOWNLOAD_DIR altındaki dosyalari listeler; dosya yoksa klasorleri de gosterir."""
        if not hasattr(self, "_pdf_listbox"):
            return
        self._pdf_file_paths = []
        self._pdf_listbox.delete(0, "end")
        if not DOWNLOAD_DIR.exists():
            return
        files = sorted(
            (f for f in DOWNLOAD_DIR.rglob("*") if f.is_file()),
            key=lambda p: p.stat().st_mtime, reverse=True
        )
        for f in files:
            self._pdf_file_paths.append(f)
            rel = f.relative_to(DOWNLOAD_DIR)
            # "klasor > dosya" seklinde daha okunakli goster
            etiket = f"{rel.parts[0][:22]} › {f.name}" if len(rel.parts) > 1 else f.name
            self._pdf_listbox.insert("end", etiket)

        # Dosya yoksa en azindan klasorleri goster
        if not files:
            folders = sorted((d for d in DOWNLOAD_DIR.iterdir() if d.is_dir()),
                             key=lambda p: p.stat().st_mtime, reverse=True)
            for d in folders:
                self._pdf_file_paths.append(d)
                self._pdf_listbox.insert("end", f"[Klasor] {d.name}")

    def _scan_selected_pdfs(self):
        keywords = self._pdf_keywords_var.get().strip()
        if not keywords:
            self._set_status("PDF Kelime alanina aranacak kelimeleri girin", "warn")
            return
        indices = list(self._pdf_listbox.curselection())
        if not indices:
            self._set_status("Tarancak dosyayi sol listeden secin", "warn")
            return
        raw_paths = [self._pdf_file_paths[i] for i in indices
                     if i < len(self._pdf_file_paths)]
        paths = []
        for p in raw_paths:
            if p.is_dir():
                paths.extend([f for f in p.rglob("*") if f.is_file()])
            else:
                paths.append(p)
        paths = list(dict.fromkeys(paths))
        if not paths:
            self._set_status("Secilen klasorde dosya bulunamadi", "warn")
            return
        use_ocr = bool(self._ocr_var.get())
        self._set_status(f"{len(paths)} dosya taranıyor...", "info")
        threading.Thread(
            target=self._scan_multiple_pdfs_worker,
            args=(paths, keywords, use_ocr), daemon=True
        ).start()

    def _scan_all_pdfs(self):
        keywords = self._pdf_keywords_var.get().strip()
        if not keywords:
            self._set_status("PDF Kelime alanina aranacak kelimeleri girin", "warn")
            return
        if not self._pdf_file_paths:
            self._set_status("Indirilen dosya bulunamadi; once dosya indirin", "warn")
            return
        expanded = []
        for p in self._pdf_file_paths:
            if p.is_dir():
                expanded.extend([f for f in p.rglob("*") if f.is_file()])
            else:
                expanded.append(p)
        expanded = list(dict.fromkeys(expanded))
        if not expanded:
            self._set_status("Klasorlerde dosya bulunamadi", "warn")
            return
        use_ocr = bool(self._ocr_var.get())
        self._set_status(f"{len(expanded)} dosya taranıyor...", "info")
        threading.Thread(
            target=self._scan_multiple_pdfs_worker,
            args=(expanded, keywords, use_ocr), daemon=True
        ).start()

    def _scan_multiple_pdfs_worker(self, paths: list, keywords: str, use_ocr: bool):
        all_rows = []
        summary_lines = []
        TARANABILIR = {".pdf", ".docx", ".doc", ".html", ".htm", ".txt", ".csv"}
        for p in paths:
            if p.suffix.lower() not in TARANABILIR:
                summary_lines.append(f"{p.name}: bicim desteklenmiyor, atlandi")
                continue
            summary, rows = self._scan_pdf_keywords(p, keywords, use_ocr)
            all_rows.extend(rows)
            summary_lines.append(f"{p.name}: {summary}")
        combined = "\n".join(summary_lines)
        self._q.put(("PDF_SCAN_MULTI", combined, all_rows))

    def _render_pdf_analysis(self, rows: list, summary: str = ""):
        for iid in self._pdf_tree.get_children():
            self._pdf_tree.delete(iid)

        self._pdf_rows = {}
        for idx, row in enumerate(rows):
            iid = f"p_{idx}"
            self._pdf_rows[iid] = row
            self._pdf_tree.insert(
                "", "end", iid=iid,
                values=(
                    row.get("pdf", "-"),
                    row.get("keyword", ""),
                    row.get("page", ""),
                    row.get("count", 0),
                    row.get("source", ""),
                    row.get("snippet", ""),
                ),
                tags=("tek" if idx % 2 else "cift",))
        self._pdf_tree.tag_configure("cift", background=C_ROWBASE)
        self._pdf_tree.tag_configure("tek", background=C_ROWALT)

        self._pdf_ozet_metni = summary
        if rows:
            toplam = {}
            for r in rows:
                k = r.get("keyword", "")
                toplam[k] = toplam.get(k, 0) + int(r.get("count", 0))
            self._pdf_ozet_metni = (
                (summary + "\n" if summary else "") +
                f"{len(rows)} eşleşme  ·  " +
                ", ".join(f"{k}: {v}" for k, v in toplam.items()) +
                "\n\nBir satır seçin — bulunan yerin tam metni burada görünür.")
        elif not summary:
            self._pdf_ozet_metni = "Girilen kelimeler bulunamadı."

        self._pdf_detay_goster(None)

        # Ilk satiri otomatik sec ki kullanici hemen metni gorsun
        cocuklar = self._pdf_tree.get_children()
        if cocuklar:
            self._pdf_tree.selection_set(cocuklar[0])
            self._pdf_tree.focus(cocuklar[0])

    def _pdf_detay_goster(self, event=None):
        """Secili sonucun tam metnini alt panelde, kelime vurgulu gosterir."""
        self._pdf_summary.configure(state="normal")
        self._pdf_summary.delete("1.0", "end")

        sec = self._pdf_tree.selection()
        satir = self._pdf_rows.get(sec[0]) if sec else None
        if satir is None:
            self._pdf_summary.insert("end", getattr(self, "_pdf_ozet_metni", ""))
            self._pdf_summary.configure(state="disabled")
            return

        kelime = satir.get("keyword", "")
        baslik = (f"{satir.get('pdf', '')}   ·   \"{kelime}\"   ·   "
                  f"{satir.get('count', 0)} kez")
        if satir.get("page") not in ("", "-", None):
            baslik += f"   ·   sayfa {satir.get('page')}"
        self._pdf_summary.insert("end", baslik + "\n", "baslik")

        baglamlar = satir.get("contexts") or (
            [satir["snippet"]] if satir.get("snippet") else [])
        if not baglamlar:
            self._pdf_summary.insert("end", "\n(Metin kesiti alinamadi)")
        for i, b in enumerate(baglamlar, 1):
            self._pdf_summary.insert("end", f"\n{i}. ", "sira")
            # Kelimeyi vurgulayarak yaz
            hedef = tr_fold_pos(b)
            aranan = tr_fold_pos(kelime)
            konum = 0
            while aranan:
                k = hedef.find(aranan, konum)
                if k < 0:
                    break
                self._pdf_summary.insert("end", b[konum:k])
                self._pdf_summary.insert("end", b[k:k + len(aranan)], "vurgu")
                konum = k + len(aranan)
            self._pdf_summary.insert("end", b[konum:] + "\n")

        if len(baglamlar) < int(satir.get("count", 0) or 0):
            self._pdf_summary.insert(
                "end",
                f"\n(İlk {len(baglamlar)} eşleşme gösteriliyor; "
                f"belgede toplam {satir.get('count')} kez geçiyor.)", "sira")
        self._pdf_summary.configure(state="disabled")

    def _active_selection(self):
        active_tab = self._tabs.index(self._tabs.select()) if hasattr(self, "_tabs") else 0

        # DIKKAT: sutun sirasi moda gore degisiyor (ihale modunda "İlan
        # Tarihi" sutunu yok). Bu yuzden deger SIRASINA gore degil, sutun
        # ADINA gore okunur; yoksa yanlis alan IKN sanilir.
        def _kayit(tree, iid, urls):
            try:
                ikn = str(tree.set(iid, "ikn")).strip()
            except Exception:
                ikn = ""
            kayit = self._find_notification(ikn) or {}
            ad = kayit.get("ihaleAdi")
            if not ad:
                try:
                    ad = str(tree.set(iid, "ihale_adi"))
                except Exception:
                    ad = ikn
            return (iid, {"ikn": ikn, "ihaleAdi": ad, "kayit": kayit},
                    urls.get(iid, EKAP_URL))

        def _from_live():
            sel = self._tree.selection()
            if not sel:
                return None
            return _kayit(self._tree, sel[0], self._urls)

        def _from_filter():
            sel = self._filter_tree.selection()
            if not sel:
                return None
            return _kayit(self._filter_tree, sel[0], self._filtered_urls)

        # Filtreleme sekmesinde onceligi o tablo alir; diger sekmelerde
        # (PDF Analiz dahil) hangisinde secim varsa o kullanilir.
        order = [_from_filter, _from_live] if active_tab == 1 else [_from_live, _from_filter]
        for getter in order:
            found = getter()
            if found:
                return found
        return None, None, None

    def _on_row_selected(self, event=None):
        if not self._auto_download_var.get():
            return
        iid, _, _ = self._active_selection()
        if not iid:
            return
        if iid == self._last_selected_iid:
            return
        self._last_selected_iid = iid
        self.after(120, self._download_selected_item)

    def _find_notification(self, ikn: str):
        for n in self._all_notifications:
            if str(n.get("ikn", "")).strip() == str(ikn).strip():
                return n
        return None

    def _download_selected_item(self, event=None):
        if self._downloading:
            self._set_status("Indirme zaten suruyor, lutfen bekleyin...", "warn")
            return

        iid, values, url = self._active_selection()
        if not iid or not values:
            self._set_status("Indirme icin once bir kayit secin", "warn")
            return

        ikn       = str(values.get("ikn") or "dokuman")
        ihale_adi = str(values.get("ihaleAdi") or ikn)

        # EKAP bu ihale icin dokuman butonu gostermiyorsa tarayici acmadan bitir.
        notif = values.get("kayit") or self._find_notification(ikn)
        if notif is not None and notif.get("dokumanButonuGosterilsinMi") is False:
            self._set_status(
                f"{ikn}: EKAP bu ihale icin dokuman sunmuyor, indirme atlandi", "warn")
            return

        keywords  = self._pdf_keywords_var.get().strip()
        use_ocr   = bool(self._ocr_var.get())
        self._downloading = True
        self._set_status(f"Dokuman indiriliyor: {ikn}", "info")

        dt_id = str((notif or {}).get("dt_id", ""))
        worker = threading.Thread(
            target=self._download_document_worker,
            args=(url, ikn, ihale_adi, keywords, use_ocr, self.mode, dt_id),
            daemon=True,
            name="EKAPDownloader"
        )
        worker.start()

    @staticmethod
    def _safe_filename(name: str, max_len: int = 80) -> str:
        """Windows-safe filesystem name: strip forbidden chars, trim length."""
        safe = re.sub(r'[\\/:*?"<>|]', '_', name).strip('. ')
        return safe[:max_len] if safe else "dokuman"

    @staticmethod
    def _parse_captcha_answer(body_text: str):
        """Parse EKAP challenge question and return the expected answer string."""
        # Pattern: "SÖZCÜK kelimesinin son harfi nedir?"
        m = re.search(r"(\w+)\s+kelimesinin\s+son\s+harfi", body_text, re.IGNORECASE)
        if m:
            return tr_lower_char(m.group(1)[-1])
        # Pattern: "SÖZCÜK kelimesinin ilk harfi nedir?"
        m = re.search(r"(\w+)\s+kelimesinin\s+(?:ilk|bir(?:inci)?)\s+harfi", body_text, re.IGNORECASE)
        if m:
            return tr_lower_char(m.group(1)[0])
        # Pattern: "SÖZCÜK kelimesinin kaç harfi vardır?"
        m = re.search(r"(\w+)\s+kelimesinin\s+ka[çc]\s+harfi", body_text, re.IGNORECASE)
        if m:
            return str(len(m.group(1)))
        return None

    @staticmethod
    def _dismiss_tutorial_sync(page) -> bool:
        """EKAP'in <ekap-tutorial> tanitim katmanini kapatir.

        Bu katman ("1 / 10 — Arama Filtreleri ... Ileri") sayfanin uzerine
        seffaf bir overlay koyuyor ve dokuman butonuna yapilan tiklamalar
        ona gidiyor. Her indirme temiz profille acildigi icin katman HER
        SEFERINDE cikiyor; kapatilmazsa indirme hicbir zaman baslamiyor.
        """
        try:
            if page.locator("ekap-tutorial").count() == 0:
                return False
            # 1) Kendi kapatma dugmesi
            try:
                page.locator("ekap-tutorial .close-btn").first.click(timeout=2000)
                page.wait_for_timeout(400)
            except Exception:
                pass
            # 2) Escape (testte tek basina da yeterli oluyor)
            if page.locator("ekap-tutorial .overlay").count() > 0:
                try:
                    page.keyboard.press("Escape")
                    page.wait_for_timeout(400)
                except Exception:
                    pass
            # 3) Son care: katmani DOM'dan kaldir
            if page.locator("ekap-tutorial").count() > 0:
                page.evaluate(
                    "() => document.querySelectorAll('ekap-tutorial')"
                    ".forEach(e => e.remove())")
            return True
        except Exception:
            return False

    @staticmethod
    def _is_captcha_page_sync(page) -> bool:
        """Detect EKAP validation page that asks manual challenge response."""
        # EKAP'in dokuman indirme sayfasindaki (IlanDokumanDownload.aspx)
        # dogrulama, soruyu METIN olarak degil GORSEL olarak veriyor; sayfa
        # metni yalnizca "Dogrula" oldugu icin asagidaki kelime sayimi
        # cogu zaman esigi tutturamiyor ve CAPTCHA "cozuldu" saniliyordu.
        # Kesin isaret: dogrulama kutusunun/gorselinin sayfada olmasi.
        try:
            for sel in ("#ctl00_capEkapMaster_txtCaptcha",
                        "#ctl00_capEkapMaster_capImg",
                        "input[name*='txtCaptcha']"):
                if page.locator(sel).count() > 0:
                    return True
        except Exception:
            pass

        try:
            txt = page.locator("body").inner_text(timeout=2500).lower()
        except Exception:
            return False
        signals = [
            "kelimesinin son harfi nedir",
            "sorunun cevabini",
            "sorunun cevabını",
            "sayiyı yaziniz",
            "sayıyı yazınız",
            "küçük olan",
            "kucuk olan",
            "büyük olan",
            "buyuk olan",
            "dogrula",
            "doğrula",
        ]
        hit = sum(1 for s in signals if s in txt)
        return hit >= 2

    @staticmethod
    def _ocr_captcha_numbers(img):
        """CAPTCHA gorselinden sayilari okur. (sayilar, ondalikli_mi) doner.

        Tesseract yan yana duran iki sayiyi tek kelime gibi okuyabiliyor
        ("37,98" + "12,45" -> "37,9812,45"). Iki asamali cozum:
          1) Tum gorseli oku, ondalikli kalibi ayikla.
          2) Yetmezse gorseli bos sutunlardan parcalara ayirip her parcayi
             ayri ayri oku (tamsayi CAPTCHA'lari icin sart).
        """
        def _parse(text):
            dec = re.findall(r"\d{1,6}[.,]\d{1,2}", text)
            if dec:
                return [float(x.replace(",", ".")) for x in dec], True
            ints = re.findall(r"\d{1,6}", text)
            return [float(x) for x in ints], False

        cfg_all = "--psm 6 -c tessedit_char_whitelist=0123456789.,- "
        try:
            raw_all = pytesseract.image_to_string(img, config=cfg_all)
        except Exception:
            raw_all = ""
        nums, dec = _parse(raw_all)

        # Bitisik okundugunda ("4821735") tamsayi ayirma yanlis sayilar
        # uretir ama yine de ">=2 sayi" gibi gorunur. Bu yuzden sayilar
        # arasinda gercek bir bosluk yoksa parcalamaya GUVEN.
        # Ondalikli kalip da bitisik metni yanlis bolebiliyor
        # ("56,7"+"56,9" -> "56,756,9" -> 56,75 + 6,9). Bu yuzden tum
        # gorsel okumasina SADECE gercek bir bosluk varsa guven.
        gap_var = any(c.isspace() for c in raw_all.strip())
        if len(nums) >= 2 and gap_var:
            return nums, dec

        # --- Sutun izdusumu ile parcalama ---
        try:
            g = img.convert("L")
            w, h = g.size
            px = g.load()
            min_gap = max(6, h // 4)
            cols = [any(px[x, y] < 128 for y in range(h)) for x in range(w)]
            segs, start, gap = [], None, 0
            for x in range(w):
                if cols[x]:
                    if start is None:
                        start = x
                    gap = 0
                elif start is not None:
                    gap += 1
                    if gap >= min_gap:
                        segs.append((max(0, start - 3), x - gap + 4))
                        start, gap = None, 0
            if start is not None:
                segs.append((max(0, start - 3), w))

            cfg_one = "--psm 7 -c tessedit_char_whitelist=0123456789.,"
            out, any_dec = [], False
            for a, b in segs:
                if b - a < 8:
                    continue
                part = pytesseract.image_to_string(g.crop((a, 0, b, h)), config=cfg_one)
                pn, pd = _parse(part)
                out += pn
                any_dec = any_dec or pd
            if len(out) >= 2:
                return out, any_dec
        except Exception:
            pass
        return nums, dec


    def _solve_numeric_captcha_sync(self, page) -> bool:
        """Solve image-based numeric CAPTCHA: küçük/büyük olan sayıyı yaz."""
        try:
            txt = page.locator("body").inner_text(timeout=3000)
            txt_lower = txt.lower()

            is_smaller = any(s in txt_lower for s in ["küçük olan", "kucuk olan"])
            is_larger  = any(s in txt_lower for s in ["büyük olan", "buyuk olan"])
            if not (is_smaller or is_larger):
                return False

            self._q.put(("STATUS", "Sayisal CAPTCHA algilandi, cozum deneniyor...", "info"))

            # --- Strategy 1: OCR the captcha image element ---
            ocr_numbers = []
            if HAS_OCR:
                captcha_selectors = [
                    "img[src*='aptcha']",
                    "img[src*='Aptcha']",
                    "canvas",
                    ".captchaImg",
                    ".captcha img",
                    "[id*='aptcha'] img",
                    "[class*='aptcha'] img",
                ]
                for sel in captcha_selectors:
                    try:
                        elem = page.locator(sel)
                        if elem.count() > 0:
                            img_bytes = elem.first.screenshot()
                            img = Image.open(io.BytesIO(img_bytes)).convert("L")
                            ocr_numbers, had_decimal = self._ocr_captcha_numbers(img)
                            self._captcha_decimal = had_decimal
                            if len(ocr_numbers) >= 2:
                                break
                    except Exception:
                        continue

            # --- Strategy 2: scrape numbers from visible page text ---
            page_numbers = []
            for m in re.finditer(r"\b(\d{1,6}(?:[.,]\d{1,4})?)\b", txt):
                try:
                    page_numbers.append(float(m.group(1).replace(",", ".")))
                except Exception:
                    pass

            # --- Strategy 3: scrape numbers from HTML source (data attrs / scripts) ---
            html_numbers = []
            try:
                html = page.content()
                for m in re.finditer(r"data-[\w-]+=['\"]([\d.]+)['\"]", html):
                    try:
                        html_numbers.append(float(m.group(1)))
                    except Exception:
                        pass
                # Also find JS variable assignments like var x = 37.98
                for m in re.finditer(r"=\s*([\d]+(?:\.[\d]+)?)", html):
                    try:
                        html_numbers.append(float(m.group(1)))
                    except Exception:
                        pass
            except Exception:
                pass

            # Combine candidates - prefer OCR numbers, then brief page numbers
            candidates = ocr_numbers if len(ocr_numbers) >= 2 else (
                page_numbers if len(page_numbers) >= 2 else html_numbers
            )
            # Filter to plausible captcha range
            candidates = [n for n in candidates if 0 < n < 100000]
            candidates = list(dict.fromkeys(candidates))  # deduplicate

            if len(candidates) < 2:
                return False

            # Pick answer: smallest or largest
            candidate_set = sorted(set(candidates))
            answer_val = candidate_set[0] if is_smaller else candidate_set[-1]

            # Format: drop .0 for integers
            if answer_val == int(answer_val):
                answer_str = str(int(answer_val))
            else:
                answer_str = f"{answer_val:.2f}".rstrip("0").rstrip(".")
                # EKAP Turkce ondalik ayraci (virgul) bekliyor.
                if getattr(self, "_captcha_decimal", False):
                    answer_str = answer_str.replace(".", ",")

            inp = page.locator(
                "input[type='text'], input:not([type='hidden']):not([type='submit'])"
                ":not([type='button']):not([type='checkbox'])"
            )
            if inp.count() == 0:
                return False

            inp.first.fill(answer_str)
            page.wait_for_timeout(400)

            for btn_sel in [
                "button:has-text('Doğrula')",
                "button:has-text('Dogrula')",
                "button[type='submit']",
                "input[type='submit']",
                "button",
            ]:
                try:
                    page.locator(btn_sel).first.click(timeout=3000)
                    break
                except Exception:
                    continue

            page.wait_for_timeout(1800)
            if self._is_captcha_page_sync(page):
                return False
            # Soru sayfasi kalkmis olabilir ama cevap YANLIS kabul edilmis
            # olabilir; bunu basari saymayalim.
            try:
                after = tr_fold(page.locator("body").inner_text(timeout=2000))
                if any(w in after for w in ("yanlis", "hatali", "gecersiz",
                                            "tekrar deneyin")):
                    return False
            except Exception:
                pass
            return True
        except Exception:
            return False

    def _solve_captcha_sync(self, page, manual_timeout_sec: int = 60) -> bool:
        """Auto-solve any EKAP captcha (text or numeric). Falls back to manual."""
        if not self._is_captcha_page_sync(page):
            return True

        # EKAP dokuman indirme dogrulamasi: soru sayfa metninde degil
        # GORSELDE ve bilgi sorusu tipinde ("Hangisi Turkiye'nin bir
        # sehridir? ..." + saginda bozulmus bir sayi). Bunu otomatik
        # cozmeye calismak anlamsiz; dogrudan kullaniciya birak.
        try:
            if page.locator("#ctl00_capEkapMaster_txtCaptcha").count() > 0:
                try:
                    page.bring_to_front()
                except Exception:
                    pass
                self._q.put(("STATUS",
                    "EKAP guvenlik sorusu (gorsel) — acilan pencerede cevabi ve "
                    "sagdaki sayiyi yazip Dogrula'ya basin...", "warn"))
                return self._wait_manual_captcha(page, max(manual_timeout_sec, 180))
        except Exception:
            pass

        self._q.put(("STATUS", "Dogrulama sayfasi algilandi, otomatik cozum deneniyor...", "info"))

        # Try text-based captcha (kelimesinin son/ilk harfi) up to 3 times
        for _attempt in range(3):
            try:
                txt = page.locator("body").inner_text(timeout=3000)

                # Numeric captcha (küçük/büyük olan sayı)
                txt_lower = txt.lower()
                if any(s in txt_lower for s in ["küçük olan", "kucuk olan", "büyük olan", "buyuk olan"]):
                    if self._solve_numeric_captcha_sync(page):
                        self._q.put(("STATUS", "Sayisal dogrulama otomatik tamamlandi...", "info"))
                        return True
                    # Numeric solve failed - skip text attempt
                    break

                # Text captcha
                answer = self._parse_captcha_answer(txt)
                if answer:
                    inp = page.locator(
                        "input[type='text'], "
                        "input:not([type]), "
                        "input:not([type='hidden']):not([type='submit']):not([type='button'])"
                    )
                    if inp.count() > 0:
                        inp.first.fill(answer)
                        page.wait_for_timeout(300)
                        for btn_sel in [
                            "button:has-text('Doğrula')",
                            "button:has-text('Dogrula')",
                            "button:has-text('doğrula')",
                            "button[type='submit']",
                            "input[type='submit']",
                            "button",
                        ]:
                            try:
                                page.locator(btn_sel).first.click(timeout=3000)
                                break
                            except Exception:
                                continue
                        page.wait_for_timeout(1500)
                        if not self._is_captcha_page_sync(page):
                            self._q.put(("STATUS", "Dogrulama otomatik tamamlandi, devam ediliyor...", "info"))
                            return True
            except Exception:
                pass
            page.wait_for_timeout(600)

        # Fallback: manual wait (browser is headless=False so user can see it)
        try:
            page.bring_to_front()
        except Exception:
            pass
        self._q.put(("STATUS",
            f"Otomatik dogrulama basarisiz — acilan tarayicida kendiniz tamamlayin "
            f"({manual_timeout_sec} sn)...", "warn"))
        return self._wait_manual_captcha(page, manual_timeout_sec)

    def _wait_manual_captcha(self, page, timeout_sec: int) -> bool:
        """Kullanici dogrulamayi tamamlayana kadar bekler."""
        end_ts = time.time() + timeout_sec
        last_note = 0
        while time.time() < end_ts:
            if page.is_closed():
                # Sekme kapandi: dogrulama sonrasi yonlendirme olabilir de,
                # sayfanin kendini kapatmasi da. Karar veremeyiz; disaridaki
                # dongu indirmenin gelip gelmedigine bakarak karar versin.
                return True
            try:
                page.wait_for_timeout(1000)
            except Exception:
                return True
            if not self._is_captcha_page_sync(page):
                self._q.put(("STATUS", "Dogrulama tamamlandi, indirme suruyor...", "info"))
                return True
            kalan = int(end_ts - time.time())
            if kalan // 30 != last_note:
                last_note = kalan // 30
                self._q.put(("STATUS",
                    f"Guvenlik sorusu bekleniyor... ({kalan} sn kaldi)", "warn"))
        self._q.put(("STATUS", "Guvenlik sorusu zamaninda cevaplanmadi", "error"))
        return False

    def _download_document_worker(self, url: str, ikn: str, ihale_adi: str,
                                  keywords: str, use_ocr: bool,
                                  mode: str = MODE_IHALE, dt_id: str = ""):
        if not HAS_PLAYWRIGHT_SYNC:
            self._q.put(("DOWNLOAD_FAIL", "Playwright sync API kurulu degil"))
            return

        DOWNLOAD_DIR.mkdir(exist_ok=True)

        # Her ihale icin kendi isimli alt klasor. Klasor, dosya GERCEKTEN
        # inince olusturulur; aksi halde basarisiz her deneme geride bos
        # klasor birakiyordu.
        safe_name = self._safe_filename(ihale_adi)
        ihale_dir = DOWNLOAD_DIR / safe_name

        try:
            with sync_playwright() as pw:
                # Bu pencere KULLANICIYA GORUNMELI: EKAP indirme sayfasinda
                # gorsel guvenlik sorusunu insanin cevaplamasi gerekiyor.
                # Sabit konum, pencerenin ekran disinda/arkada kalmamasi icin.
                browser = pw.chromium.launch(
                    headless=False,
                    args=["--window-position=80,60", "--window-size=1400,900"])
                context = browser.new_context(
                    accept_downloads=True,
                    viewport={"width": 1600, "height": 1000}
                )
                page = context.new_page()

                # DIKKAT: Playwright'ta "download" olayi BrowserContext'te
                # DEGIL, Page'de yayilir. context.on("download", ...) hata
                # vermeden kabul ediliyor ama hicbir zaman tetiklenmiyor;
                # bu yuzden inen dosya goruluyordu ama uygulama "dosya
                # gelmedi" diyordu. Dinleyici her sayfaya tek tek baglanir.
                downloads_received = []
                new_pages = []

                def _indirmeyi_dinle(sayfa):
                    try:
                        sayfa.on("download", lambda d: downloads_received.append(d))
                    except Exception:
                        pass

                _indirmeyi_dinle(page)
                context.on("page", lambda p: (new_pages.append(p),
                                              _indirmeyi_dinle(p)))

                # ── Dogrudan Temin dali ──────────────────────────────────
                # DT dokumani eski EKAP'te tek bir adresle iniyor; ihale
                # tarafindaki gibi liste/dropdown gezmeye gerek yok.
                if mode == MODE_DT:
                    if not dt_id:
                        raise RuntimeError("Bu duyuru icin dokuman kimligi yok")
                    hedef = DT_DOC_URL.format(dt_id=dt_id)
                    self._q.put(("STATUS", f"Dogrudan temin dokumani aciliyor: {ikn}", "info"))
                    try:
                        page.goto(hedef, wait_until="domcontentloaded", timeout=120000)
                    except Exception as e:
                        # DT adresi dogrudan dosya dondurdugu icin Playwright
                        # "Download is starting" diye navigasyonu iptal eder;
                        # bu beklenen durum, hata degil.
                        if "download" not in str(e).lower() and \
                           not isinstance(e, PlaywrightTimeoutError):
                            raise
                    page.wait_for_timeout(1500)
                    self._dismiss_tutorial_sync(page)

                    # DT adresinde genelde guvenlik sorusu CIKMIYOR; ciksa da
                    # _solve_captcha_sync zaten kullaniciya birakir.
                    if not downloads_received and not self._solve_captcha_sync(page):
                        raise RuntimeError("Dogrulama tamamlanmadi")

                    bitis = time.time() + 60
                    while time.time() < bitis and not downloads_received:
                        page.wait_for_timeout(500)

                    if not downloads_received:
                        raise RuntimeError(
                            "Dosya gelmedi. Genellikle sebep: acilan pencerede "
                            "guvenlik sorusu (soru + sagdaki sayi) zamaninda "
                            "cevaplanmadi. Bu duyuruda dosya olmama ihtimali de var."
                        )
                    download = downloads_received[0]
                    suggested = download.suggested_filename or "dokuman"
                    ext = Path(suggested).suffix
                    ihale_dir.mkdir(parents=True, exist_ok=True)
                    out_path = ihale_dir / f"{safe_name}{ext}"
                    if out_path.exists():
                        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                        out_path = ihale_dir / f"{safe_name}_{stamp}{ext}"
                    download.save_as(str(out_path))
                    context.close()
                    browser.close()
                    out_path = self._finalize_download(out_path, ihale_dir)
                    self._q.put(("DOWNLOAD_DONE", str(out_path)))
                    if keywords:
                        try:
                            msg, rows = self._scan_pdf_keywords(out_path, keywords, use_ocr)
                            self._q.put(("PDF_SCAN_RESULT", msg))
                            self._q.put(("PDF_SCAN_DETAIL", f"{out_path.name} -> {msg}", rows))
                        except Exception as e:
                            self._q.put(("PDF_SCAN_RESULT", f"PDF tarama hatasi: {e}"))
                    return

                # paginationTake=100 intercept — same as monitoring thread
                def _force_take_100(route, request):
                    try:
                        body = json.loads(request.post_data or "{}")
                        body["paginationSkip"] = 0
                        body["paginationTake"] = 100
                        body["ihaleDurumIdList"] = list(IHALE_DURUM_FILTRESI)
                        headers = dict(request.headers)
                        headers["content-type"] = "application/json"
                        route.continue_(post_data=json.dumps(body), headers=headers)
                    except Exception:
                        route.continue_()

                page.route("**/GetListByParameters", _force_take_100)

                # ONCE ihalenin KENDI detay sayfasini ac. Orada tek bir ihale
                # ve tek bir dokuman butonu bulunur; 100 satir icinde arayip
                # yanlis satira denk gelme riski ortadan kalkar. Ayrica ilk
                # 100 sonucun disinda kalan eski ihaleler de indirilebilir.
                detail_url = url or f"{EKAP_URL}/{ikn.replace('/', '_')}"
                self._q.put(("STATUS", f"Ilan detayi aciliyor: {ikn}", "info"))

                def _open(target):
                    try:
                        page.goto(target, wait_until="domcontentloaded", timeout=120000)
                    except PlaywrightTimeoutError:
                        pass
                    try:
                        page.wait_for_selector("span.ikn", timeout=60000)
                    except Exception:
                        return False
                    page.wait_for_timeout(1200)
                    return True

                on_detail = _open(detail_url)
                if not on_detail:
                    # Detay acilmadiysa eski yonteme (arama listesi) don.
                    self._q.put(("STATUS", "Detay acilmadi, arama listesine bakiliyor...", "warn"))
                    if not _open(EKAP_URL):
                        raise RuntimeError("EKAP listesi yuklenemedi")
                page.unroute("**/GetListByParameters", _force_take_100)

                if not self._solve_captcha_sync(page):
                    raise RuntimeError("Dogrulama tamamlanmadi")

                # EKAP'in tanitim balonu (ekap-tutorial) sayfanin uzerine
                # gorunmez bir katman seriyor ve TUM tiklamalari yutuyor.
                self._dismiss_tutorial_sync(page)

                ikn_cells = page.locator("span.ikn")
                row_count = ikn_cells.count()
                target_idx = -1
                for i in range(row_count):
                    try:
                        if ikn_cells.nth(i).inner_text().strip() == ikn:
                            target_idx = i
                            break
                    except Exception:
                        continue
                if target_idx < 0:
                    raise RuntimeError(f"IKN satiri bulunamadi: {ikn}")

                doc_sel = "[title='Dokümanı Gör'], [title='Dokumani Gor'], [title='Doküman Gör']"

                # Once butonu IKN'nin KENDI satirindan sec. Index eslestirmesi
                # ("n. IKN -> n. buton") satirlardan birinde buton yoksa kayar
                # ve sessizce baska bir ihalenin dokumanini indirir.
                doc_btn = None
                try:
                    row = ikn_cells.nth(target_idx).locator(
                        'xpath=ancestor::*[self::ihale-liste-item'
                        ' or contains(@class,"pc-card")'
                        ' or contains(@class,"dx-row") or self::tr][1]')
                    in_row = row.locator(doc_sel)
                    if in_row.count() > 0:
                        doc_btn = in_row.first
                except Exception:
                    doc_btn = None

                if doc_btn is None:
                    doc_buttons = page.locator(doc_sel)
                    # Yalnizca buton sayisi satir sayisiyla birebir esitse
                    # index yontemine guvenilebilir.
                    if doc_buttons.count() != row_count:
                        raise RuntimeError(
                            "Dokuman butonlari satirlarla eslesmiyor "
                            f"({doc_buttons.count()} buton / {row_count} satir); "
                            "yanlis dokuman inmesin diye islem durduruldu")
                    doc_btn = doc_buttons.nth(target_idx)

                self._q.put(("STATUS", "Dokuman yukluyor, dropdown bekleniyor...", "info"))

                # Indirme dinleyicisi yukarida (her iki mod icin) kuruldu.

                # Yeni sekmeler yukarida dinleniyor (indirme + CAPTCHA icin).

                dropdown_item_selectors = [
                    ".dx-menu-item:has-text('İhale Dokümanı')",
                    ".dx-item:has-text('İhale Dokümanı')",
                    "li:has-text('İhale Dokümanı')",
                    "a:has-text('İhale Dokümanı')",
                    "text='İhale Dokümanı'",
                    "text=/İhale Doküman/i",
                    "text=/Ihale Dokuman/i",
                ]

                download = None
                for _menu_attempt in range(3):
                    if download:
                        break
                    # Katman yeniden dogmus olabilir; her denemede temizle.
                    self._dismiss_tutorial_sync(page)
                    # Click the ↓ download icon ONCE to open dropdown
                    doc_btn.click(timeout=8000)
                    page.wait_for_timeout(900)

                    # Solve CAPTCHA on main page if it appeared
                    if not self._solve_captcha_sync(page):
                        raise RuntimeError("Dogrulama zamani asimi (60 sn)")

                    # Try each selector on the already-open dropdown (no re-click)
                    clicked = False
                    for selector in dropdown_item_selectors:
                        try:
                            if page.locator(selector).count() == 0:
                                continue
                            page.locator(selector).first.click(timeout=6000)
                            clicked = True
                            break
                        except Exception:
                            continue

                    if clicked:
                        # Indirmeyi bekle; acilan sekmede guvenlik sorusu
                        # cikarsa kullanicinin cevaplamasi icin sure tanin.
                        end_wait = time.time() + 45
                        handled = set()
                        while time.time() < end_wait:
                            for np in list(new_pages):
                                if np in handled:
                                    continue
                                try:
                                    np.wait_for_load_state("domcontentloaded", timeout=3000)
                                    if self._is_captcha_page_sync(np):
                                        handled.add(np)
                                        self._q.put(("STATUS",
                                            "Indirme sekmesinde guvenlik sorusu var...", "warn"))
                                        self._solve_captcha_sync(np)
                                        # Cevaplandiktan sonra dosyanin
                                        # gelmesi icin ek sure ver.
                                        end_wait = time.time() + 60
                                except Exception:
                                    pass
                            if downloads_received:
                                download = downloads_received[0]
                                break
                            page.wait_for_timeout(500)
                        break  # stop menu attempts

                    # Menu didn't appear — press Escape and retry
                    try:
                        page.keyboard.press("Escape")
                        page.wait_for_timeout(600)
                    except Exception:
                        pass

                if not download:
                    raise RuntimeError(
                        "Dosya gelmedi. Genellikle sebep: acilan pencerede EKAP "
                        "guvenlik sorusu (soru + sagdaki sayi) zamaninda "
                        "cevaplanmadi. Tekrar deneyip pencere acilinca cevabi "
                        "yazin. Bu ihalede dokuman olmama ihtimali de var."
                    )

                suggested = download.suggested_filename or "dokuman.pdf"
                ext = Path(suggested).suffix or ".pdf"
                ihale_dir.mkdir(parents=True, exist_ok=True)
                out_path = ihale_dir / f"{safe_name}{ext}"
                # Ayni isimde dosya varsa numara ekle
                if out_path.exists():
                    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    out_path = ihale_dir / f"{safe_name}_{stamp}{ext}"
                download.save_as(str(out_path))

                context.close()
                browser.close()
                out_path = self._finalize_download(out_path, ihale_dir)

            self._q.put(("DOWNLOAD_DONE", str(out_path)))

        except Exception as e:
            self._q.put(("DOWNLOAD_FAIL", str(e)))
            return

        # Indirme bitti; buradan sonraki hata "indirme basarisiz" degildir.
        if keywords:
            try:
                msg, detail_rows = self._scan_pdf_keywords(out_path, keywords, use_ocr)
                self._q.put(("PDF_SCAN_RESULT", msg))
                self._q.put(("PDF_SCAN_DETAIL", f"{out_path.name} -> {msg}", detail_rows))
            except Exception as e:
                self._q.put(("PDF_SCAN_RESULT", f"PDF tarama hatasi: {e}"))

    def _finalize_download(self, out_path: Path, hedef_dir: Path) -> Path:
        """Inen dosyanin turunu duzeltir ve arsivse icerigini acar.

        EKAP dokumani ZIP olarak gelir (icinde .docx/.doc teknik sartnameler,
        ic ice zip ve .rar ekler). Uzantisiz GUID adiyla da gelebildigi icin
        tur ICERIKTEN belirlenir.
        """
        try:
            gercek = detect_extension(out_path, out_path.suffix.lower())
            if gercek and gercek != out_path.suffix.lower():
                yeni = out_path.with_suffix(gercek)
                if yeni.exists():
                    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    yeni = out_path.with_name(f"{out_path.stem}_{stamp}{gercek}")
                out_path = out_path.replace(yeni)
                self._q.put(("STATUS", f"Dosya turu duzeltildi: {out_path.name}", "info"))

            if is_archive(out_path):
                self._q.put(("STATUS", "Arsiv aciliyor...", "info"))
                cikanlar = extract_archive(out_path, hedef_dir)
                if cikanlar:
                    self._q.put(("STATUS",
                        f"Arsivden {len(cikanlar)} belge cikarildi: {hedef_dir.name}",
                        "ok"))
        except Exception as e:
            self._q.put(("STATUS", f"Arsiv islenemedi: {e}", "warn"))
        return out_path

    def _resolve_tesseract_path(self):
        if shutil.which("tesseract"):
            return "tesseract"
        candidates = [
            Path("C:/Program Files/Tesseract-OCR/tesseract.exe"),
            Path("C:/Program Files (x86)/Tesseract-OCR/tesseract.exe"),
            Path.home() / "AppData/Local/Programs/Tesseract-OCR/tesseract.exe",
        ]
        for p in candidates:
            if p.exists():
                return str(p)
        return None

    def _scan_pdf_keywords(self, pdf_path: Path, raw_keywords: str, use_ocr: bool):
        # Eslestirme sadelestirilmis (tr_fold) metinle yapilir; ekranda ise
        # kullanicinin YAZDIGI hali gorunmeli ("parça" -> tabloda "parca"
        # yazmasin diye).
        ham_kelimeler = [k for k in re.split(r"[,;\n\t ]+", raw_keywords) if k.strip()]
        gosterim, keywords = {}, []
        for hk in ham_kelimeler:
            fk = tr_fold(hk)
            if fk and fk not in gosterim:
                gosterim[fk] = hk
                keywords.append(fk)
        if not keywords:
            return "PDF tarama atlandi (kelime girilmedi).", []
        # PDF disi belgeler (docx / doc=Word-HTML / html / txt) burada islenir.
        if not str(pdf_path).lower().endswith(".pdf"):
            metin, tur = belge_metni(Path(pdf_path))
            if not metin.strip():
                return (f"'{Path(pdf_path).name}' okunamadi "
                        f"(desteklenmeyen bicim ya da bos).", [])
            folded = tr_fold(metin)
            satirlar = [ln.strip() for ln in metin.splitlines() if ln.strip()]
            sayim, satir_listesi = {}, []
            for kw in keywords:
                c = folded.count(kw)
                sayim[kw] = c
                if c:
                    baglamlar = baglam_listesi(metin, kw)
                    satir_listesi.append({
                        "pdf": Path(pdf_path).name,
                        "keyword": gosterim.get(kw, kw), "page": "-",
                        "count": c, "source": tur,
                        "snippet": baglamlar[0] if baglamlar else "",
                        "contexts": baglamlar,
                    })
            ozet = ", ".join(f"{gosterim.get(k, k)}: {v}" for k, v in sayim.items())
            return f"Kelime sonucu ({tur}) -> {ozet}", satir_listesi

        if not HAS_PDF_TEXT:
            return "PDF taramasi icin pymupdf kurun: pip install pymupdf", []

        counts = {k: 0 for k in keywords}
        detail_rows = []

        tess_cmd = None
        if use_ocr:
            if not HAS_OCR:
                return "OCR secili ama eksik paket var: pip install pytesseract pillow", []
            tess_cmd = self._resolve_tesseract_path()
            if not tess_cmd:
                return ("OCR secili ama tesseract bulunamadi. Kurulum: "
                        "winget install UB-Mannheim.TesseractOCR"), []
            pytesseract.pytesseract.tesseract_cmd = tess_cmd
            if ocr_dili() != "tur":
                self._q.put(("STATUS",
                    "UYARI: Tesseract Türkçe dil paketi yok — OCR sonuçları "
                    "bozuk çıkacak. kurulum.bat çalıştırın.", "warn"))

        text_chars = 0
        try:
            doc = fitz.open(str(pdf_path))
            for page_idx, page in enumerate(doc, start=1):
                raw_text = page.get_text("text") or ""
                text_chars += len(raw_text.strip())
                text = tr_fold(raw_text)
                lines = [ln.strip() for ln in raw_text.splitlines() if ln.strip()]
                for kw in keywords:
                    c = text.count(kw)
                    counts[kw] += c
                    if c:
                        baglamlar = baglam_listesi(raw_text, kw)
                        detail_rows.append({
                            "pdf": pdf_path.name,
                            "keyword": gosterim.get(kw, kw),
                            "page": page_idx,
                            "count": c,
                            "source": "metin",
                            "snippet": baglamlar[0] if baglamlar else "",
                            "contexts": baglamlar,
                        })

                # OCR fallback (image-based PDF) only when enabled.
                if use_ocr and (not text.strip()):
                    # Gri tonlamayi dogrudan PyMuPDF uretir: hem daha net
                    # sonuc verir hem RGB->gri cevriminden hizli.
                    pix = page.get_pixmap(matrix=fitz.Matrix(OCR_ZOOM, OCR_ZOOM),
                                          colorspace=fitz.csGRAY, alpha=False)
                    img = Image.frombytes("L", [pix.width, pix.height], pix.samples)
                    raw_ocr = pytesseract.image_to_string(img, lang=ocr_dili()) or ""
                    ocr_text = tr_fold(raw_ocr)
                    ocr_lines = [ln.strip() for ln in raw_ocr.splitlines() if ln.strip()]
                    for kw in keywords:
                        c = ocr_text.count(kw)
                        counts[kw] += c
                        if c:
                            baglamlar = baglam_listesi(raw_ocr, kw)
                            detail_rows.append({
                                "pdf": pdf_path.name,
                                "keyword": gosterim.get(kw, kw),
                                "page": page_idx,
                                "count": c,
                                "source": "ocr",
                                "snippet": baglamlar[0] if baglamlar else "",
                                "contexts": baglamlar,
                            })
            doc.close()
        except Exception as e:
            return f"PDF tarama hatasi: {e}", []

        # Taranmis (goruntu) PDF'lerde metin katmani yoktur; OCR kapaliyken
        # arama sessizce "0" doner ve kullanici kelimenin gercekten olmadigini
        # sanir. EKAP teknik sartnameleri cogunlukla bu turdendir.
        if text_chars == 0 and not use_ocr:
            return (f"UYARI: '{pdf_path.name}' taranmis (goruntu) PDF — metin "
                    f"katmani yok, arama yapilamadi. OCR kutusunu isaretleyip "
                    f"tekrar deneyin.", [])

        method = "metin"
        if use_ocr:
            dil = ocr_dili()
            method = f"metin+ocr[{dil}]"
            if dil != "tur":
                method += " — TURKCE PAKET YOK, sonuclar bozuk olabilir"
        return (f"Kelime sonucu ({method}) -> " +
                ", ".join(f"{gosterim.get(k, k)}: {v}" for k, v in counts.items())), detail_rows

    # ── Windows toast bildirimi ───────────────────────────────────────────────
    def _win_notify(self, n: dict):
        if not HAS_WINOTIFY:
            return
        try:
            toast = WinNotify(
                app_id="EKAP Ihale Izleyici",
                title="Yeni Ihale Bulundu!",
                msg=f"{n.get('ihaleAdi', '')[:90]}\n{n.get('idareAdi', '')}",
                duration="long",
                launch=n.get("url", EKAP_URL),
            )
            toast.show()
        except Exception:
            pass

    # ── Pencere kapatma ───────────────────────────────────────────────────────
    def _on_close(self):
        try:
            if getattr(self, "_poll_id", None):
                self.after_cancel(self._poll_id)
        except Exception:
            pass
        if self._thread and self._thread.is_alive():
            self._set_status("Durduruluyor...", "warn")
            self._thread.stop()
        self.store.save()
        self.destroy()


# ══════════════════════════════════════════════════════════════════════════════
_INSTANCE_LOCK = None


def _release_single_instance_lock():
    """Kilidi birakir. Mod degisiminde YENI surec acilabilsin diye gerekli.

    Kilit birakilmazsa yeni surec "Uygulama zaten calisiyor" diyip kapanir
    ve kullanici hicbir pencere olmadan kalir.
    """
    global _INSTANCE_LOCK
    if _INSTANCE_LOCK and sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.kernel32.ReleaseMutex(_INSTANCE_LOCK)
            ctypes.windll.kernel32.CloseHandle(_INSTANCE_LOCK)
        except Exception:
            pass
    _INSTANCE_LOCK = None


def acquire_single_instance_lock():
    """Uygulamanin ayni anda ikinci kez acilmasini engeller.

    Adlandirilmis Windows mutex'i kullanilir; surec ismine bakmak yanlis
    sonuc verirdi cunku uygulama kendi alt sureclerini (tarayici, surucu)
    zaten aciyor. Mutex handle'i dondurulur: program kapanana kadar canli
    kalmali, aksi halde kilit dusner.
    """
    if sys.platform != "win32":
        return True
    try:
        import ctypes
        ERROR_ALREADY_EXISTS = 183
        handle = ctypes.windll.kernel32.CreateMutexW(
            None, False, "Global\\EKAP_Ihale_Izleyici_SingleInstance")
        if ctypes.windll.kernel32.GetLastError() == ERROR_ALREADY_EXISTS:
            # CreateMutexW, mutex ZATEN VARSA da gecerli bir handle doner.
            # Kapatilmazsa handle sizar ve mutex nesnesi hayatta kalir.
            # Mod degisiminde bu olumcul: kilit birkac kez denenirken her
            # denemede bir handle sizar, eski surec kapansa bile mutex
            # bizim sizan handle'larimiz yuzunden serbest kalmaz ve yeni
            # pencere HIC acilmaz. Olculdu: birak-yeniden al dongusu
            # bu yuzden basarisizdi.
            if handle:
                ctypes.windll.kernel32.CloseHandle(handle)
            return False
        return handle
    except Exception:
        return True     # kilit kurulamadiysa uygulamayi engelleme


def ask_mode(default: str = MODE_IHALE):
    """Acilista calisma modunu sorar. Iptal edilirse None doner."""
    win = tk.Tk()
    win.title("EKAP Izleyici")
    win.configure(bg=C_BG)
    win.resizable(False, False)
    secim = {"mod": None}

    tk.Label(win, text="Ne izlensin?", bg=C_BG, fg=C_TEXT,
             font=("Segoe UI", 14, "bold")).pack(padx=30, pady=(24, 4))
    tk.Label(win, text="Iki kaynak ayri ayri takip edilir; kayitlari karismaz.",
             bg=C_BG, fg=C_MUTED, font=("Segoe UI", 9)).pack(padx=30, pady=(0, 18))

    def sec(mod):
        secim["mod"] = mod
        win.destroy()

    kutu = tk.Frame(win, bg=C_BG)
    kutu.pack(padx=30, pady=(0, 24))

    for mod, baslik, aciklama, renk in (
        (MODE_IHALE, "İhaleler", "EKAP ihale ilanlari\n(Teklif Vermeye Acik)", C_ACCENT),
        (MODE_DT, "Doğrudan Temin", "Dogrudan temin duyurulari\n(Duyurusu Yayimlanmis)", "#2ecc71"),
    ):
        cerceve = tk.Frame(kutu, bg=C_PANEL, padx=14, pady=12)
        cerceve.pack(side="left", padx=8)
        tk.Button(cerceve, text=baslik, bg=renk, fg="#fff", relief="flat",
                  width=18, cursor="hand2", font=("Segoe UI", 11, "bold"),
                  command=lambda m=mod: sec(m)).pack()
        tk.Label(cerceve, text=aciklama, bg=C_PANEL, fg=C_MUTED,
                 font=("Segoe UI", 8), justify="center").pack(pady=(8, 0))

    win.bind("<Return>", lambda e: sec(default))
    win.bind("<Escape>", lambda e: win.destroy())
    win.update_idletasks()
    x = (win.winfo_screenwidth() - win.winfo_width()) // 2
    y = (win.winfo_screenheight() - win.winfo_height()) // 3
    win.geometry(f"+{x}+{y}")
    win.mainloop()
    return secim["mod"]


def _komut_satiri():
    """--mod ihale|dt ve --gecis bayraklarini okur."""
    argv = sys.argv[1:]
    mod = None
    if "--mod" in argv:
        i = argv.index("--mod")
        if i + 1 < len(argv) and argv[i + 1] in (MODE_IHALE, MODE_DT):
            mod = argv[i + 1]
    return mod, ("--gecis" in argv)


if __name__ == "__main__":
    _mod_arg, _gecis = _komut_satiri()

    # Mod degisiminde eski surec kapanirken yeni surec aciliyor; kilit
    # birakilana kadar kisa bir yaris var. Bu yuzden gecis basladiginda
    # kilit birkaç saniye boyunca tekrar denenir.
    _instance_lock = acquire_single_instance_lock()
    if _instance_lock is False and _gecis:
        for _ in range(20):                     # 20 x 0.25 sn = 5 sn
            time.sleep(0.25)
            _instance_lock = acquire_single_instance_lock()
            if _instance_lock is not False:
                break

    _INSTANCE_LOCK = _instance_lock if _instance_lock is not True else None
    if _instance_lock is False:
        root = tk.Tk()
        root.withdraw()
        messagebox.showwarning(
            "EKAP Ihale Izleyici",
            "Uygulama zaten calisiyor.\n\n"
            "Gorev cubugunda acik olan pencereyi kullanin. Ayni anda birden "
            "fazla kopya calistirmak durum dosyasinin bozulmasina yol acar."
        )
        sys.exit(0)

    if not HAS_PLAYWRIGHT:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(
            "Eksik Bagimlilik",
            "Playwright kurulu degil.\n\n"
            "Lutfen komut satirinda sunu calistirin:\n\n"
            "  pip install playwright winotify\n"
            "  python -m playwright install chromium"
        )
        sys.exit(1)

    # Mod komut satirindan geldiyse secim penceresi gosterilmez; mod
    # degistirme dugmesi uygulamayi boyle yeniden baslatir.
    _mode = _mod_arg or ask_mode()
    if not _mode:
        sys.exit(0)

    app = EKAPApp(_mode)
    app.mainloop()
