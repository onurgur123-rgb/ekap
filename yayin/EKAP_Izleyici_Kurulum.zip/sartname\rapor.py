# -*- coding: utf-8 -*-
"""Excel raporu (Spesifikasyon E2) ve JSON/ham metin ciktisi.

Kurallar:
  - Her satirda MADDE ATFI sutunu zorunlu; kaynagi gosterilemeyen bulgu
    rapora girmez.
  - Sartnamede olmayan bilgi hucresi BOS BIRAKILMAZ, "ŞARTNAMEDE YOK" yazilir
    ve kirmiziya boyanir. ("bilgi yok" ile "bakilmadi" ayirt edilebilsin.)
  - Toplamlar FORMULLE hesaplanir (COUNTA/COUNTIF); sabit sayi yazilmaz.
  - Her sayfada lejant bulunur.
"""
from __future__ import annotations

import json
from pathlib import Path

from . import karsilastir
from .model import KIRMIZI, Sartname, YOK

# ── Renk paleti (E2) ───────────────────────────────────────────────────────
YESIL   = "FFC6EFCE"      # Yuklenici sorumlulugunda
SARI    = "FFFFEB9C"      # Idare sorumlulugunda
KIRMIZI_R = "FFFFC7CE"    # tanimsiz / riskli
TURUNCU = "FFFFD5A6"      # celiskili
MAVI_YAZI = "FF1F4E79"    # firma dolduracak (sari zemin + mavi yazi)
BASLIK  = "FF203864"
BASLIK_YAZI = "FFFFFFFF"
GRI     = "FFF2F2F2"

LEJANT = [
    ("Yüklenici sorumluluğunda", YESIL),
    ("İdare sorumluluğunda", SARI),
    ("Tanımsız / riskli", KIRMIZI_R),
    ("Çelişkili", TURUNCU),
    ("Firma dolduracak", MAVI_YAZI),
]


def _stil():
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    return Alignment, Border, Font, PatternFill, Side


def _dolgu(renk: str):
    from openpyxl.styles import PatternFill
    return PatternFill("solid", fgColor=renk)


def _baslik_yaz(ws, basliklar: list[str], satir: int = 1) -> int:
    from openpyxl.styles import Alignment, Font
    for i, ad in enumerate(basliklar, start=1):
        h = ws.cell(row=satir, column=i, value=ad)
        h.fill = _dolgu(BASLIK)
        h.font = Font(bold=True, color=BASLIK_YAZI, size=10)
        h.alignment = Alignment(horizontal="center", vertical="center",
                                wrap_text=True)
    ws.freeze_panes = ws.cell(row=satir + 1, column=1)
    return satir + 1


def _lejant_yaz(ws, satir: int) -> int:
    from openpyxl.styles import Font
    ws.cell(row=satir, column=1, value="LEJANT").font = Font(bold=True, size=9)
    for i, (metin, renk) in enumerate(LEJANT):
        h = ws.cell(row=satir, column=2 + i, value=metin)
        h.font = Font(size=9, bold=(renk == MAVI_YAZI),
                      color=(MAVI_YAZI if renk == MAVI_YAZI else "FF000000"))
        h.fill = _dolgu(SARI if renk == MAVI_YAZI else renk)
    return satir + 2


def _yok_ise_boya(hucre, deger) -> None:
    """Bos birakma: ŞARTNAMEDE YOK yaz ve kirmiziya boya."""
    from openpyxl.styles import Font
    if deger in (None, "", YOK):
        hucre.value = YOK
        hucre.fill = _dolgu(KIRMIZI_R)
        hucre.font = Font(size=10, italic=True)


def _genislik(ws, genislikler: dict[str, int]) -> None:
    for sutun, en in genislikler.items():
        ws.column_dimensions[sutun].width = en


# ══════════════════════════════════════════════════════════════════════════
def _sayfa_ozet(wb, sartnameler: list[Sartname]) -> None:
    from openpyxl.styles import Alignment, Font
    ws = wb.active
    ws.title = "Özet"
    satir = _lejant_yaz(ws, 1)

    basliklar = ["Dosya", "Kurum", "Sayfa (PDF)", "Gövde", "Ek",
                 "Metin katmanı", "OCR güveni", "Madde", "Cihaz/Künye",
                 "Ek kalem", "Kapsam", "Kapsam maddesi", "Kırmızı uyarı",
                 "Toplam uyarı", "Süre (sn)"]
    satir = _baslik_yaz(ws, basliklar, satir)
    ilk_veri = satir

    for sn in sartnameler:
        degerler = [
            sn.dosya_adi, sn.kurum, sn.sayfa_sayisi_pdf,
            sn.sayfa_sayisi_govde, sn.ek_sayfa_sayisi,
            "VAR" if sn.metin_katmani else "YOK (OCR)",
            sn.ocr_guven or "—",
            len(sn.maddeler), len([c for c in sn.cihazlar if c.kunye]),
            len(sn.ek_kalemler),
            (sn.kapsam.dahil_haric or YOK).upper(),
            sn.kapsam.madde, sn.kirmizi_sayisi, len(sn.uyarilar), sn.sure_sn,
        ]
        for i, deger in enumerate(degerler, start=1):
            h = ws.cell(row=satir, column=i, value=deger)
            if i in (11, 12):
                _yok_ise_boya(h, deger)
            if i == 13 and isinstance(deger, int) and deger:
                h.fill = _dolgu(KIRMIZI_R)
                h.font = Font(bold=True)
        satir += 1

    # Toplamlar FORMULLE
    son = satir - 1
    ws.cell(row=satir + 1, column=1, value="TOPLAM").font = Font(bold=True)
    for sutun in ("H", "I", "J", "M", "N"):
        ws.cell(row=satir + 1, column=ws[f"{sutun}1"].column,
                value=f"=SUM({sutun}{ilk_veri}:{sutun}{son})").font = Font(bold=True)
    ws.cell(row=satir + 3, column=1,
            value="Not: Bu modül yorum yapmaz; veri çıkarır ve tutarsızlık "
                  "işaretler. Hukuki sonuç çıkarma kullanıcıya aittir.").font = \
        Font(italic=True, size=9)
    _genislik(ws, {"A": 34, "B": 26, "K": 12, "L": 14})
    ws.cell(row=ilk_veri - 1, column=1).alignment = Alignment(wrap_text=True)


def _sayfa_cihaz(wb, sartnameler: list[Sartname]) -> None:
    from openpyxl.styles import Font
    ws = wb.create_sheet("Cihaz Listesi")
    satir = _lejant_yaz(ws, 1)
    satir = _baslik_yaz(ws, ["Dosya", "Künye", "Marka / Model", "Tip",
                             "Sayfa", "Eksik alan"], satir)
    ilk = satir
    for sn in sartnameler:
        for c in sn.cihazlar:
            ws.cell(row=satir, column=1, value=sn.dosya_adi)
            ws.cell(row=satir, column=2, value=c.kunye)
            h = ws.cell(row=satir, column=3, value=c.marka)
            _yok_ise_boya(h, c.marka)
            ws.cell(row=satir, column=4, value=c.tip or "—")
            ws.cell(row=satir, column=5, value=c.sayfa)
            e = ws.cell(row=satir, column=6,
                        value=", ".join(c.eksik_alanlar) or "—")
            if c.eksik_alanlar:
                e.fill = _dolgu(KIRMIZI_R)
            satir += 1
    ws.cell(row=satir + 1, column=1, value="TOPLAM CİHAZ").font = Font(bold=True)
    ws.cell(row=satir + 1, column=2,
            value=f"=COUNTA(B{ilk}:B{satir - 1})").font = Font(bold=True)
    ws.cell(row=satir + 2, column=1, value="MARKA/MODEL EKSİK").font = Font(bold=True)
    ws.cell(row=satir + 2, column=2,
            value=f'=COUNTIF(F{ilk}:F{satir - 1},"<>—")').font = Font(bold=True)
    _genislik(ws, {"A": 30, "B": 14, "C": 30, "D": 20, "F": 18})


def _sayfa_standart(wb, sartnameler: list[Sartname]) -> None:
    from openpyxl.styles import Font
    ws = wb.create_sheet("TS ve Belge Matrisi")
    satir = _lejant_yaz(ws, 1)

    # Sabit sorgu listesi: bulunamayan da raporlanir ("YOK" bilgisi degerlidir)
    basliklar = ["Standart / Belge"] + [sn.dosya_adi for sn in sartnameler] + \
                ["Madde", "Marka bazlı?", "Bağlam"]
    satir = _baslik_yaz(ws, basliklar, satir)

    tum_adlar = []
    for sn in sartnameler:
        for ad in sn.standartlar:
            if ad not in tum_adlar:
                tum_adlar.append(ad)
    for ad in sorted(tum_adlar):
        ws.cell(row=satir, column=1, value=ad).font = Font(bold=True)
        madde, marka, baglam = "", "", ""
        for i, sn in enumerate(sartnameler, start=2):
            isabetler = sn.standartlar.get(ad, [])
            h = ws.cell(row=satir, column=i, value="VAR" if isabetler else "YOK")
            h.fill = _dolgu(YESIL if isabetler else KIRMIZI_R)
            if isabetler and not madde:
                madde = isabetler[0].madde or ""
                marka = ("EVET" if "[MARKA BAZLI BELGE ŞARTI]"
                         in isabetler[0].baglam else "hayır")
                baglam = isabetler[0].baglam[:300]
        s = len(sartnameler)
        h = ws.cell(row=satir, column=s + 2, value=madde)
        _yok_ise_boya(h, madde)
        m = ws.cell(row=satir, column=s + 3, value=marka or "—")
        if marka == "EVET":
            m.fill = _dolgu(TURUNCU)
            m.font = Font(bold=True)
        ws.cell(row=satir, column=s + 4, value=baglam or "—")
        satir += 1
    _genislik(ws, {"A": 20, "B": 12, "C": 12,
                   chr(65 + len(sartnameler) + 3): 90})


def _sayfa_sorumluluk(wb, sartnameler: list[Sartname]) -> None:
    from openpyxl.styles import Font
    ws = wb.create_sheet("Sorumluluk Matrisi")
    satir = _lejant_yaz(ws, 1)
    satir = _baslik_yaz(ws, ["Dosya", "Konu", "Taraf", "Madde", "Sayfa",
                             "Bağlam"], satir)
    ilk = satir

    # Taraf tahmini SADECE metinden; belirlenemiyorsa "TANIMSIZ" (kirmizi).
    for sn in sartnameler:
        for konu in ("yedek_parca", "sarf", "aksesuar", "filtre", "bakim_kiti"):
            isabetler = sn.sorumluluk.get(konu, [])
            if not isabetler:
                ws.cell(row=satir, column=1, value=sn.dosya_adi)
                ws.cell(row=satir, column=2, value=konu)
                h = ws.cell(row=satir, column=3, value=YOK)
                h.fill = _dolgu(KIRMIZI_R)
                ws.cell(row=satir, column=4, value=YOK).fill = _dolgu(KIRMIZI_R)
                satir += 1
                continue
            for isabet in isabetler[:8]:
                baglam_kucuk = isabet.baglam.lower()
                if "yüklenici" in baglam_kucuk or "yuklenici" in baglam_kucuk:
                    taraf, renk = "YÜKLENİCİ", YESIL
                elif "idare" in baglam_kucuk:
                    taraf, renk = "İDARE", SARI
                else:
                    taraf, renk = "TANIMSIZ", KIRMIZI_R
                ws.cell(row=satir, column=1, value=sn.dosya_adi)
                ws.cell(row=satir, column=2, value=konu)
                h = ws.cell(row=satir, column=3, value=taraf)
                h.fill = _dolgu(renk)
                m = ws.cell(row=satir, column=4, value=isabet.madde)
                _yok_ise_boya(m, isabet.madde)
                ws.cell(row=satir, column=5, value=isabet.sayfa)
                ws.cell(row=satir, column=6, value=isabet.baglam[:400])
                satir += 1
    for etiket, deger, konum in (("YÜKLENİCİ", "YÜKLENİCİ", 1),
                                 ("İDARE", "İDARE", 2),
                                 ("TANIMSIZ", "TANIMSIZ", 3)):
        ws.cell(row=satir + konum, column=1, value=f"TOPLAM {etiket}").font = \
            Font(bold=True)
        ws.cell(row=satir + konum, column=2,
                value=f'=COUNTIF(C{ilk}:C{satir - 1},"{deger}")').font = \
            Font(bold=True)
    _genislik(ws, {"A": 30, "B": 16, "C": 14, "D": 10, "F": 90})


def _sayfa_sure_ceza(wb, sartnameler: list[Sartname]) -> None:
    ws = wb.create_sheet("Süre ve Ceza")
    satir = _lejant_yaz(ws, 1)
    satir = _baslik_yaz(ws, ["Dosya", "Alan", "Değer", "Madde", "Sayfa"], satir)
    for sn in sartnameler:
        kaynaklar = [("SÜRE", sn.sureler), ("CEZA", sn.cezalar)]
        for tur, sozluk in kaynaklar:
            for ad, deger in sozluk.items():
                if isinstance(deger, list):
                    deger = ", ".join(map(str, deger)) or YOK
                ws.cell(row=satir, column=1, value=sn.dosya_adi)
                ws.cell(row=satir, column=2, value=f"{tur} · {ad}")
                if isinstance(deger, dict):
                    ws.cell(row=satir, column=3, value=deger.get("ifade"))
                    m = ws.cell(row=satir, column=4, value=deger.get("madde"))
                    _yok_ise_boya(m, deger.get("madde"))
                    ws.cell(row=satir, column=5, value=deger.get("sayfa"))
                else:
                    h = ws.cell(row=satir, column=3,
                                value=deger if deger not in (None, "") else YOK)
                    _yok_ise_boya(h, deger)
                    ws.cell(row=satir, column=4, value=YOK).fill = \
                        _dolgu(KIRMIZI_R)
                satir += 1
    _genislik(ws, {"A": 30, "B": 26, "C": 60, "D": 10})


def _sayfa_belge_soru(wb, sartnameler: list[Sartname]) -> None:
    from openpyxl.styles import Font
    ws = wb.create_sheet("Belgeler ve Sorular")
    satir = _lejant_yaz(ws, 1)
    satir = _baslik_yaz(ws, ["Dosya", "Belge", "Madde", "Ne zaman",
                             "Yaptırım", "Bağlam"], satir)
    for sn in sartnameler:
        for b in sn.belgeler:
            ws.cell(row=satir, column=1, value=sn.dosya_adi)
            ws.cell(row=satir, column=2, value=b.ad)
            m = ws.cell(row=satir, column=3, value=b.madde)
            _yok_ise_boya(m, b.madde)
            ws.cell(row=satir, column=4, value=b.ne_zaman)
            h = ws.cell(row=satir, column=5, value=b.yaptirim)
            _yok_ise_boya(h, b.yaptirim)
            ws.cell(row=satir, column=6, value=b.baglam[:400])
            satir += 1

    satir += 2
    ws.cell(row=satir, column=1,
            value="CEVABI BU BELGEDE OLMAYAN SORULAR (C8)").font = \
        Font(bold=True, size=11)
    satir += 1
    satir = _baslik_yaz(ws, ["Dosya", "Soru", "Teknik şartnamede",
                             "Madde", "Cevap / bağlam", "Bakılacak kaynak"],
                        satir)
    for sn in sartnameler:
        for soru in sn.cevapsiz_sorular:
            ws.cell(row=satir, column=1, value=sn.dosya_adi)
            ws.cell(row=satir, column=2, value=soru["soru"])
            h = ws.cell(row=satir, column=3,
                        value="VAR" if soru["teknik_sartnamede"] else "YOK")
            h.fill = _dolgu(YESIL if soru["teknik_sartnamede"] else KIRMIZI_R)
            m = ws.cell(row=satir, column=4, value=soru["madde"])
            _yok_ise_boya(m, soru["madde"])
            ws.cell(row=satir, column=5, value=soru["cevap"])
            k = ws.cell(row=satir, column=6, value=soru["kaynak"])
            k.fill = _dolgu(SARI)
            k.font = Font(color=MAVI_YAZI, bold=True)
            satir += 1
    _genislik(ws, {"A": 30, "B": 34, "C": 16, "E": 60, "F": 28})


def _sayfa_uyari(wb, sartnameler: list[Sartname]) -> None:
    from openpyxl.styles import Font
    ws = wb.create_sheet("Uyarılar")
    from openpyxl.styles import Alignment
    ws.cell(row=1, column=1,
            value="⚠ RAPORU AÇAR AÇMAZ BURAYA BAKIN — her uyarı gözle "
                  "doğrulanmalıdır.").font = Font(bold=True, size=12,
                                                  color="FF9C0006")
    ws.cell(row=1, column=1).alignment = Alignment(wrap_text=False)
    satir = _lejant_yaz(ws, 3)
    satir = _baslik_yaz(ws, ["Dosya", "Seviye", "Tür", "Madde", "Sayfa",
                             "Mesaj", "Görsel", "Doğrulandı"], satir)
    ilk = satir
    for sn in sartnameler:
        for u in sorted(sn.uyarilar, key=lambda x: (x.seviye != KIRMIZI, x.tur)):
            ws.cell(row=satir, column=1, value=sn.dosya_adi)
            h = ws.cell(row=satir, column=2, value=u.seviye)
            h.fill = _dolgu(KIRMIZI_R if u.seviye == KIRMIZI else SARI)
            h.font = Font(bold=True)
            ws.cell(row=satir, column=3, value=u.tur)
            m = ws.cell(row=satir, column=4, value=u.madde)
            _yok_ise_boya(m, u.madde)
            ws.cell(row=satir, column=5, value=u.sayfa)
            ws.cell(row=satir, column=6, value=u.mesaj)
            ws.cell(row=satir, column=7, value=u.gorsel_kirpma or "—")
            d = ws.cell(row=satir, column=8, value="EVET" if u.dogrulandi
                        else "HAYIR")
            d.fill = _dolgu(YESIL if u.dogrulandi else SARI)
            d.font = Font(color=MAVI_YAZI, bold=True)
            satir += 1
    if satir == ilk:
        ws.cell(row=satir, column=1,
                value="Doğrulama gerekmiyor ✓").font = Font(bold=True,
                                                            color="FF006100")
        satir += 1
    ws.cell(row=satir + 1, column=1, value="KIRMIZI UYARI").font = Font(bold=True)
    ws.cell(row=satir + 1, column=2,
            value=f'=COUNTIF(B{ilk}:B{satir - 1},"KIRMIZI")').font = Font(bold=True)
    ws.cell(row=satir + 2, column=1, value="DOĞRULAMA BEKLEYEN").font = Font(bold=True)
    ws.cell(row=satir + 2, column=2,
            value=f'=COUNTIF(H{ilk}:H{satir - 1},"HAYIR")').font = Font(bold=True)
    _genislik(ws, {"A": 28, "B": 10, "C": 22, "D": 10, "F": 110, "G": 30})


def _sayfa_farklar(wb, sartnameler: list[Sartname]) -> None:
    from openpyxl.styles import Font
    ws = wb.create_sheet("Farklar")
    satir = _lejant_yaz(ws, 1)
    for o in karsilastir.coklu_ozet(sartnameler):
        ws.cell(row=satir, column=1,
                value=f"{o['a']}  ↔  {o['b']}   "
                      f"(benzerlik %{o['benzerlik_yuzdesi']})").font = \
            Font(bold=True, size=11)
        satir += 1
        for etiket, anahtar in (("Sadece A'da", "sadece_a"),
                                ("Sadece B'de", "sadece_b"),
                                ("Metni farklı", "farkli"),
                                ("Ek kalem A/B", None)):
            if anahtar:
                ws.cell(row=satir, column=1, value=f"{etiket}: {o[anahtar]}")
            else:
                ws.cell(row=satir, column=1,
                        value=f"{etiket}: {o['ek_kalem_a']} / {o['ek_kalem_b']}")
            satir += 1
        satir += 1

    a, b = sartnameler[0], sartnameler[1]
    satir = _baslik_yaz(ws, ["Durum", f"{a.dosya_adi} md.",
                             f"{b.dosya_adi} md.", "Benzerlik",
                             "Kelime bazlı fark"], satir)
    for f in karsilastir.farklar(a, b):
        h = ws.cell(row=satir, column=1, value=f["durum"])
        h.fill = _dolgu(TURUNCU if f["durum"] == karsilastir.FARKLI
                        else KIRMIZI_R)
        ws.cell(row=satir, column=2, value=f["a_madde"] or "—")
        ws.cell(row=satir, column=3, value=f["b_madde"] or "—")
        ws.cell(row=satir, column=4, value=f["benzerlik"])
        ws.cell(row=satir, column=5,
                value=(f["fark"] or f["a_metin"] or f["b_metin"])[:600])
        satir += 1
    _genislik(ws, {"A": 18, "B": 14, "C": 14, "D": 11, "E": 120})


# ══════════════════════════════════════════════════════════════════════════
def excel_yaz(sartnameler: list[Sartname], hedef: Path) -> Path:
    """E2'deki sayfalari uretir. Toplamlar formulle hesaplanir."""
    from openpyxl import Workbook
    hedef = Path(hedef)
    hedef.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    _sayfa_ozet(wb, sartnameler)
    _sayfa_uyari(wb, sartnameler)          # uyarilar hemen ozetin arkasinda
    _sayfa_cihaz(wb, sartnameler)
    _sayfa_standart(wb, sartnameler)
    _sayfa_sorumluluk(wb, sartnameler)
    _sayfa_sure_ceza(wb, sartnameler)
    _sayfa_belge_soru(wb, sartnameler)
    if len(sartnameler) > 1:
        _sayfa_farklar(wb, sartnameler)
    wb.save(str(hedef))
    return hedef


def json_yaz(sartnameler: list[Sartname], hedef: Path) -> Path:
    hedef = Path(hedef)
    hedef.parent.mkdir(parents=True, exist_ok=True)
    veri = [sn.sozluk() for sn in sartnameler]
    hedef.write_text(json.dumps(veri, ensure_ascii=False, indent=2),
                     encoding="utf-8")
    return hedef


def ham_metin_yaz(sn: Sartname, hedef: Path) -> Path:
    hedef = Path(hedef)
    hedef.parent.mkdir(parents=True, exist_ok=True)
    hedef.write_text(sn.ham_metin, encoding="utf-8")
    return hedef
