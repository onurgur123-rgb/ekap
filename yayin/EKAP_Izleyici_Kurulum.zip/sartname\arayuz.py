# -*- coding: utf-8 -*-
"""Sartname Okuma sekmesi (Spesifikasyon ASAMA 6).

Bu dosya paketin TEK tkinter'a bagimli parcasidir; cikarim/kurallar/rapor
katmanlari bunu hic tanimaz. Ana uygulama renk paletini ve buton fabrikasini
disaridan verir, boylece iki yonlu bagimlilik olusmaz.

Duzen (spesifikasyona gore):
    [PDF sec] [Indirilenlerden sec] [Analiz Et] ... [Excel] [Ham metin] [JSON]
    [ilerleme: sayfa n/N]
    [UYARI PANELI - EN USTTE, tek tek "dogruladim" isaretlenebilir]
    [sekmeli sonuc]
"""
from __future__ import annotations

import queue
import subprocess
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from . import analiz_et, karsilastir, ortam, rapor
from .model import KIRMIZI, Sartname


class SartnameSekmesi(tk.Frame):
    """Sartname okuma sekmesi. Ana uygulamadan bagimsiz calisir."""

    def __init__(self, parent, renkler: dict, btn_fabrika,
                 indirilenler: Path, cikti_klasoru: Path):
        super().__init__(parent, bg=renkler["BG"])
        self.R = renkler
        self._btn = btn_fabrika
        self._indirilenler = Path(indirilenler)
        self._cikti = Path(cikti_klasoru)
        self._dosyalar: list[Path] = []
        self._sonuclar: list[Sartname] = []
        self._kuyruk: queue.Queue = queue.Queue()
        self._calisiyor = False
        self._kur()
        self.after(200, self._kuyrugu_isle)

    # ── Kurulum ───────────────────────────────────────────────────────────
    def _kur(self) -> None:
        R = self.R
        ust = tk.Frame(self, bg=R["BG"], pady=6, padx=8)
        ust.pack(fill="x")
        self._btn(ust, "📄  PDF Seç…", self._dosya_sec, "primary",
                  bold=True).pack(side="left", padx=(0, 4))
        self._btn(ust, "📁  İndirilenlerden Seç", self._indirilenlerden_sec,
                  "ghost").pack(side="left", padx=(0, 4))
        self._btn(ust, "▶  Analiz Et", self._analiz_baslat, "success",
                  bold=True).pack(side="left", padx=(8, 4))

        self._btn(ust, "JSON", lambda: self._disa_aktar("json"),
                  "ghost").pack(side="right", padx=(4, 0))
        self._btn(ust, "Ham Metin", lambda: self._disa_aktar("metin"),
                  "ghost").pack(side="right", padx=(4, 0))
        self._btn(ust, "📊  Excel Raporu", lambda: self._disa_aktar("excel"),
                  "accent").pack(side="right", padx=(4, 0))

        # Secili dosyalar + ilerleme
        bilgi = tk.Frame(self, bg=R["BG"], padx=8)
        bilgi.pack(fill="x")
        self._dosya_lbl = tk.Label(bilgi, text="Dosya seçilmedi",
                                   bg=R["BG"], fg=R["MUTED"],
                                   font=("Segoe UI", 8), anchor="w")
        self._dosya_lbl.pack(side="left", fill="x", expand=True)
        self._ilerleme_lbl = tk.Label(bilgi, text="", bg=R["BG"],
                                      fg=R["ACCENT"],
                                      font=("Segoe UI", 8, "bold"))
        self._ilerleme_lbl.pack(side="right")

        # ── UYARI PANELI (spesifikasyon E3: ilk gorulen sey) ──────────────
        uyari_kutu = tk.Frame(self, bg=R["PANEL"], padx=10, pady=8,
                              highlightthickness=1,
                              highlightbackground=R["BORDER"])
        uyari_kutu.pack(fill="x", padx=8, pady=(6, 4))
        baslik = tk.Frame(uyari_kutu, bg=R["PANEL"])
        baslik.pack(fill="x")
        self._uyari_baslik = tk.Label(
            baslik, text="Henüz analiz yapılmadı", bg=R["PANEL"],
            fg=R["MUTED"], font=("Segoe UI", 10, "bold"))
        self._uyari_baslik.pack(side="left")
        self._btn(baslik, "✓  Doğruladım", self._dogrula_isaretle,
                  "ghost", pad=8).pack(side="right")
        self._btn(baslik, "🖼  Sayfayı Aç", self._gorsel_ac,
                  "ghost", pad=8).pack(side="right", padx=(0, 4))

        uyari_wrap = tk.Frame(uyari_kutu, bg=R["PANEL"])
        uyari_wrap.pack(fill="both", expand=True, pady=(6, 0))
        sutunlar = ("seviye", "tur", "madde", "sayfa", "mesaj", "durum")
        self._uyari_tree = ttk.Treeview(
            uyari_wrap, columns=sutunlar, show="headings",
            style="EKAP.Treeview", height=6, selectmode="extended")
        for ad, baslik_metni, en, hiza in (
                ("seviye", "Seviye", 80, "center"),
                ("tur", "Tür", 170, "w"),
                ("madde", "Madde", 70, "center"),
                ("sayfa", "Sayfa", 55, "center"),
                ("mesaj", "Uyarı", 700, "w"),
                ("durum", "Doğrulandı", 90, "center")):
            self._uyari_tree.heading(ad, text=baslik_metni, anchor="center")
            self._uyari_tree.column(ad, width=en, anchor=hiza,
                                    stretch=(ad == "mesaj"))
        uy_vsb = ttk.Scrollbar(uyari_wrap, orient="vertical",
                               command=self._uyari_tree.yview)
        self._uyari_tree.configure(yscrollcommand=uy_vsb.set)
        self._uyari_tree.pack(side="left", fill="both", expand=True)
        uy_vsb.pack(side="right", fill="y")
        self._uyari_tree.tag_configure("kirmizi", foreground=R["RED"])
        self._uyari_tree.tag_configure("sari", foreground=R["YELLOW"])
        self._uyari_tree.tag_configure("onayli", foreground=R["GREEN"])
        self._uyari_tree.bind("<Double-1>", lambda e: self._dogrula_isaretle())

        # ── Sekmeli sonuc ─────────────────────────────────────────────────
        self._sonuc_nb = ttk.Notebook(self)
        self._sonuc_nb.pack(fill="both", expand=True, padx=8, pady=(0, 6))
        self._tablolar: dict[str, ttk.Treeview] = {}
        for ad, sutunlar in (
                ("Özet", ("alan", "deger")),
                ("Maddeler", ("madde", "sayfa", "tam", "atif", "metin")),
                ("Cihazlar", ("kunye", "marka", "tip", "sayfa", "eksik")),
                ("Ek Liste", ("kod", "tanim", "nitelik", "sayfa")),
                ("Standartlar", ("standart", "durum", "madde", "marka",
                                 "baglam")),
                ("Sorumluluk", ("konu", "taraf", "madde", "sayfa", "baglam")),
                ("Süre ve Ceza", ("alan", "deger", "madde", "sayfa")),
                ("Belgeler", ("belge", "madde", "ne_zaman", "baglam")),
                ("Sorular", ("soru", "durum", "madde", "cevap", "kaynak")),
                ("Farklar", ("durum", "a", "b", "benzerlik", "fark"))):
            self._tablolar[ad] = self._tablo_ekle(ad, sutunlar)

    def _tablo_ekle(self, ad: str, sutunlar: tuple) -> ttk.Treeview:
        cerceve = tk.Frame(self._sonuc_nb, bg=self.R["BG"])
        self._sonuc_nb.add(cerceve, text=f"  {ad}  ")
        tree = ttk.Treeview(cerceve, columns=sutunlar, show="headings",
                            style="EKAP.Treeview")
        genislik = {"metin": 700, "baglam": 600, "mesaj": 700, "fark": 700,
                    "tanim": 320, "cevap": 380, "deger": 480, "marka": 220,
                    "soru": 260, "belge": 220, "kaynak": 200, "alan": 220}
        for s in sutunlar:
            tree.heading(s, text=s.replace("_", " ").title(), anchor="center")
            en = genislik.get(s, 110)
            tree.column(s, width=en, anchor=("w" if en > 200 else "center"),
                        stretch=(en > 200))
        vsb = ttk.Scrollbar(cerceve, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(cerceve, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        cerceve.rowconfigure(0, weight=1)
        cerceve.columnconfigure(0, weight=1)
        tree.tag_configure("tek", background=self.R["ROWALT"])
        tree.tag_configure("kirmizi", foreground=self.R["RED"])
        tree.tag_configure("yesil", foreground=self.R["GREEN"])
        return tree

    # ── Dosya secimi ──────────────────────────────────────────────────────
    def _dosya_sec(self) -> None:
        yollar = filedialog.askopenfilenames(
            title="Teknik şartname PDF'i seçin",
            filetypes=[("PDF dosyaları", "*.pdf"), ("Tüm dosyalar", "*.*")])
        if yollar:
            self._dosyalari_ayarla([Path(y) for y in yollar])

    def _indirilenlerden_sec(self) -> None:
        """Indirilen ihale dokumanlari icindeki PDF'leri listeler."""
        if not self._indirilenler.exists():
            messagebox.showinfo("Şartname Okuma",
                                f"İndirilenler klasörü yok:\n"
                                f"{self._indirilenler}")
            return
        pdfler = sorted((p for p in self._indirilenler.rglob("*.pdf")
                         if p.is_file()),
                        key=lambda p: p.stat().st_mtime, reverse=True)
        if not pdfler:
            messagebox.showinfo(
                "Şartname Okuma",
                "İndirilen belgeler arasında PDF bulunamadı.\n\n"
                "Önce Canlı İzleme veya Filtreleme sekmesinden bir ihaleye "
                "çift tıklayıp dokümanını indirin.")
            return
        self._secim_penceresi(pdfler)

    def _secim_penceresi(self, pdfler: list[Path]) -> None:
        R = self.R
        pen = tk.Toplevel(self)
        pen.title("İndirilen belgelerden seç")
        pen.configure(bg=R["BG"])
        pen.geometry("820x460")
        pen.transient(self.winfo_toplevel())
        tk.Label(pen, text="Analiz edilecek şartname PDF'lerini seçin "
                           "(birden çok seçim yapılabilir)",
                 bg=R["BG"], fg=R["TEXT"],
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=10,
                                                    pady=(10, 4))
        wrap = tk.Frame(pen, bg=R["BG"])
        wrap.pack(fill="both", expand=True, padx=10)
        liste = tk.Listbox(wrap, selectmode="extended", bg=R["PANEL"],
                           fg=R["TEXT"], relief="flat", bd=0,
                           font=("Segoe UI", 9), selectbackground=R["ACCENT"],
                           selectforeground="#ffffff", activestyle="none")
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=liste.yview)
        liste.configure(yscrollcommand=vsb.set)
        liste.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        for p in pdfler:
            try:
                bagil = p.relative_to(self._indirilenler)
            except ValueError:
                bagil = p
            liste.insert("end", f"{bagil}   ({p.stat().st_size / 1024:.0f} KB)")

        alt = tk.Frame(pen, bg=R["BG"], pady=8)
        alt.pack(fill="x", padx=10)

        def onayla():
            secili = [pdfler[i] for i in liste.curselection()]
            pen.destroy()
            if secili:
                self._dosyalari_ayarla(secili)

        self._btn(alt, "Seç", onayla, "primary", bold=True).pack(side="right")
        self._btn(alt, "Vazgeç", pen.destroy, "ghost").pack(side="right",
                                                            padx=(0, 6))
        liste.bind("<Double-1>", lambda e: onayla())

    def _dosyalari_ayarla(self, yollar: list[Path]) -> None:
        self._dosyalar = yollar
        if len(yollar) == 1:
            self._dosya_lbl.config(text=f"Seçili: {yollar[0].name}")
        else:
            self._dosya_lbl.config(
                text=f"Seçili: {len(yollar)} dosya — "
                     f"{', '.join(p.name for p in yollar[:3])}"
                     f"{' …' if len(yollar) > 3 else ''}   "
                     f"(karşılaştırma raporu da üretilecek)")

    # ── Analiz ────────────────────────────────────────────────────────────
    def _analiz_baslat(self) -> None:
        if self._calisiyor:
            messagebox.showinfo("Şartname Okuma", "Analiz zaten sürüyor.")
            return
        if not self._dosyalar:
            messagebox.showwarning("Şartname Okuma",
                                   "Önce en az bir PDF seçin.")
            return
        try:
            ortam.dogrula(ocr_gerekli=True)
        except ortam.OrtamHatasi as e:
            messagebox.showerror("Analiz başlatılamadı", str(e))
            return

        self._calisiyor = True
        self._ilerleme_lbl.config(text="hazırlanıyor…")
        threading.Thread(target=self._analiz_calis, daemon=True).start()

    def _analiz_calis(self) -> None:
        def ilerleme(dosya, sayfa, toplam, sira, dosya_sayisi):
            self._kuyruk.put(("ILERLEME",
                              f"{dosya}  ·  sayfa {sayfa}/{toplam}"
                              f"  ·  dosya {sira}/{dosya_sayisi}"))
        try:
            sonuc = analiz_et(self._dosyalar, ilerleme=ilerleme)
            self._kuyruk.put(("BITTI", sonuc))
        except Exception as e:                    # noqa: BLE001
            self._kuyruk.put(("HATA", str(e)))

    def _kuyrugu_isle(self) -> None:
        try:
            while True:
                tur, veri = self._kuyruk.get_nowait()
                if tur == "ILERLEME":
                    self._ilerleme_lbl.config(text=veri)
                elif tur == "BITTI":
                    self._calisiyor = False
                    self._ilerleme_lbl.config(text="tamamlandı ✓")
                    self._sonuclar = veri
                    self._sonuclari_goster()
                elif tur == "HATA":
                    self._calisiyor = False
                    self._ilerleme_lbl.config(text="hata")
                    messagebox.showerror("Analiz hatası", veri)
        except queue.Empty:
            pass
        self.after(200, self._kuyrugu_isle)

    # ── Sonuclari yaz ─────────────────────────────────────────────────────
    def _temizle(self) -> None:
        for tree in self._tablolar.values():
            for iid in tree.get_children():
                tree.delete(iid)
        for iid in self._uyari_tree.get_children():
            self._uyari_tree.delete(iid)

    def _ekle(self, tablo: str, degerler: tuple, etiket: str = "") -> None:
        tree = self._tablolar[tablo]
        n = len(tree.get_children())
        etiketler = ([etiket] if etiket else []) + (["tek"] if n % 2 else [])
        tree.insert("", "end", values=degerler, tags=tuple(etiketler))

    def _sonuclari_goster(self) -> None:
        self._temizle()
        self._uyarilari_yaz()
        for sn in self._sonuclar:
            self._ozet_yaz(sn)
            for m in sn.maddeler:
                self._ekle("Maddeler",
                           (m.numara, m.sayfa, "evet" if m.tam_cumle else "HAYIR",
                            ", ".join(m.atiflar) or "—",
                            " ".join(m.metin.split())[:400]),
                           "" if m.tam_cumle else "kirmizi")
            for c in sn.cihazlar:
                self._ekle("Cihazlar",
                           (c.kunye or "—", c.marka or "ŞARTNAMEDE YOK",
                            c.tip or "—", c.sayfa,
                            ", ".join(c.eksik_alanlar) or "—"),
                           "kirmizi" if c.eksik_alanlar else "")
            for k in sn.ek_kalemler:
                self._ekle("Ek Liste", (k.kod or "—", k.tanim, k.nitelik,
                                        k.sayfa))
            for ad, isabetler in sorted(sn.standartlar.items()):
                ilk = isabetler[0] if isabetler else None
                self._ekle("Standartlar",
                           (ad, "VAR" if isabetler else "YOK",
                            (ilk.madde if ilk else "—") or "—",
                            "EVET" if ilk and "[MARKA BAZLI BELGE ŞARTI]"
                            in ilk.baglam else "hayır",
                            (ilk.baglam[:400] if ilk else
                             "belgede geçmiyor — bu bilgi de değerlidir")),
                           "yesil" if isabetler else "kirmizi")
            for konu, isabetler in sn.sorumluluk.items():
                if not isabetler:
                    self._ekle("Sorumluluk",
                               (konu, "ŞARTNAMEDE YOK", "—", "—", "—"),
                               "kirmizi")
                for i in isabetler[:10]:
                    kucuk = i.baglam.lower()
                    taraf = ("YÜKLENİCİ" if "yüklenici" in kucuk
                             or "yuklenici" in kucuk
                             else "İDARE" if "idare" in kucuk else "TANIMSIZ")
                    self._ekle("Sorumluluk",
                               (konu, taraf, i.madde or "—", i.sayfa,
                                i.baglam[:400]),
                               "kirmizi" if taraf == "TANIMSIZ" else "")
            for kaynak, tur in ((sn.sureler, "SÜRE"), (sn.cezalar, "CEZA")):
                for ad, deger in kaynak.items():
                    if isinstance(deger, dict):
                        self._ekle("Süre ve Ceza",
                                   (f"{tur} · {ad}", deger.get("ifade", ""),
                                    deger.get("madde") or "—",
                                    deger.get("sayfa") or "—"))
                    else:
                        metin = (", ".join(map(str, deger))
                                 if isinstance(deger, list) else str(deger))
                        self._ekle("Süre ve Ceza",
                                   (f"{tur} · {ad}", metin or "ŞARTNAMEDE YOK",
                                    "—", "—"),
                                   "kirmizi" if not metin
                                   or metin == "ŞARTNAMEDE YOK" else "")
            for b in sn.belgeler:
                self._ekle("Belgeler", (b.ad, b.madde or "—", b.ne_zaman,
                                        b.baglam[:400]))
            for s in sn.cevapsiz_sorular:
                self._ekle("Sorular",
                           (s["soru"], "VAR" if s["teknik_sartnamede"] else "YOK",
                            s["madde"] or "—", s["cevap"], s["kaynak"]),
                           "yesil" if s["teknik_sartnamede"] else "kirmizi")

        if len(self._sonuclar) > 1:
            self._farklari_yaz()

    def _ozet_yaz(self, sn: Sartname) -> None:
        satirlar = [
            ("Dosya", sn.dosya_adi),
            ("Kurum", sn.kurum or "—"),
            ("Sayfa (PDF)", sn.sayfa_sayisi_pdf),
            ("Gövde sayfası", sn.sayfa_sayisi_govde or "—"),
            ("Ek sayfa", sn.ek_sayfa_sayisi),
            ("Metin katmanı", "VAR" if sn.metin_katmani else "YOK (OCR)"),
            ("OCR güveni", sn.ocr_guven or "—"),
            ("Telefon fotoğrafı", "EVET" if sn.telefon_fotografi else "hayır"),
            ("Madde sayısı", len(sn.maddeler)),
            ("Cihaz / künye", len([c for c in sn.cihazlar if c.kunye])),
            ("Ek liste kalemi", len(sn.ek_kalemler)),
            ("Nitelik dağılımı",
             ", ".join(f"{k}: {v}" for k, v in sn.nitelik_sayimi().items())
             or "—"),
            ("Kapsam", (sn.kapsam.dahil_haric or "ŞARTNAMEDE YOK").upper()),
            ("Kapsam maddesi", sn.kapsam.madde or "—"),
            ("Kırmızı uyarı", sn.kirmizi_sayisi),
            ("Toplam uyarı", len(sn.uyarilar)),
            ("Süre", f"{sn.sure_sn} sn"),
        ]
        for ad, deger in satirlar:
            self._ekle("Özet", (ad, deger))
        self._ekle("Özet", ("", ""))

    def _uyarilari_yaz(self) -> None:
        toplam = bekleyen = kirmizi = 0
        self._uyari_kaynak: list[tuple] = []
        for sn in self._sonuclar:
            for u in sorted(sn.uyarilar,
                            key=lambda x: (x.seviye != KIRMIZI, x.tur)):
                toplam += 1
                bekleyen += 0 if u.dogrulandi else 1
                kirmizi += 1 if u.seviye == KIRMIZI else 0
                etiket = ("onayli" if u.dogrulandi else
                          "kirmizi" if u.seviye == KIRMIZI else "sari")
                iid = self._uyari_tree.insert(
                    "", "end",
                    values=(u.seviye, u.tur, u.madde or "—", u.sayfa or "—",
                            " ".join(u.mesaj.split()),
                            "EVET" if u.dogrulandi else "hayır"),
                    tags=(etiket,))
                self._uyari_kaynak.append((iid, sn, u))

        R = self.R
        if toplam == 0:
            self._uyari_baslik.config(text="Doğrulama gerekmiyor ✓",
                                      fg=R["GREEN"])
        else:
            self._uyari_baslik.config(
                text=f"⚠  {bekleyen} adet doğrulama bekliyor   "
                     f"({kirmizi} kırmızı, {toplam - kirmizi} sarı)",
                fg=R["RED"] if kirmizi else R["YELLOW"])

    def _farklari_yaz(self) -> None:
        a, b = self._sonuclar[0], self._sonuclar[1]
        ozet = karsilastir.ozet(a, b)
        self._ekle("Farklar",
                   ("ÖZET", a.dosya_adi, b.dosya_adi,
                    f"%{ozet['benzerlik_yuzdesi']}",
                    f"aynı {ozet['ayni']} · farklı {ozet['farkli']} · "
                    f"sadece A {ozet['sadece_a']} · sadece B {ozet['sadece_b']}"
                    f"  |  ek kalem {ozet['ek_kalem_a']}/{ozet['ek_kalem_b']}"
                    f"  |  künye {ozet['kunye_a']}/{ozet['kunye_b']}"))
        for f in karsilastir.farklar(a, b):
            self._ekle("Farklar",
                       (f["durum"], f["a_madde"] or "—", f["b_madde"] or "—",
                        f["benzerlik"],
                        " ".join((f["fark"] or f["a_metin"]
                                  or f["b_metin"]).split())[:600]),
                       "kirmizi" if f["durum"] != karsilastir.FARKLI else "")

    # ── Uyari dogrulama ───────────────────────────────────────────────────
    def _dogrula_isaretle(self) -> None:
        secili = set(self._uyari_tree.selection())
        if not secili:
            messagebox.showinfo("Şartname Okuma",
                                "Doğrulanacak uyarıyı seçin.")
            return
        for iid, _sn, u in getattr(self, "_uyari_kaynak", []):
            if iid in secili:
                u.dogrulandi = not u.dogrulandi
        self._uyarilari_yaz_yenile()

    def _uyarilari_yaz_yenile(self) -> None:
        for iid in self._uyari_tree.get_children():
            self._uyari_tree.delete(iid)
        self._uyarilari_yaz()

    def _gorsel_ac(self) -> None:
        """Secili uyarinin sayfasini goruntu olarak acar (gozle dogrulama)."""
        secili = set(self._uyari_tree.selection())
        for iid, sn, u in getattr(self, "_uyari_kaynak", []):
            if iid not in secili or not u.sayfa:
                continue
            kaynak = next((p for p in self._dosyalar
                           if p.name == sn.dosya_adi), None)
            if not kaynak:
                continue
            from . import cikarim
            yol = cikarim.gorsel_kirp(kaynak, u.sayfa,
                                      self._cikti / "sayfa_goruntuleri")
            if yol:
                u.gorsel_kirpma = yol
                self._ac(Path(yol))
            return
        messagebox.showinfo("Şartname Okuma",
                            "Sayfa numarası olan bir uyarı seçin.")

    # ── Disa aktarma ──────────────────────────────────────────────────────
    def _disa_aktar(self, tur: str) -> None:
        if not self._sonuclar:
            messagebox.showwarning("Şartname Okuma", "Önce analiz yapın.")
            return
        self._cikti.mkdir(parents=True, exist_ok=True)
        kok = Path(self._sonuclar[0].dosya_adi).stem[:40]
        try:
            if tur == "excel":
                hedef = rapor.excel_yaz(self._sonuclar,
                                        self._cikti / f"{kok}_rapor.xlsx")
            elif tur == "json":
                hedef = rapor.json_yaz(self._sonuclar,
                                       self._cikti / f"{kok}_rapor.json")
            else:
                hedef = rapor.ham_metin_yaz(
                    self._sonuclar[0], self._cikti / f"{kok}_ham_metin.txt")
        except Exception as e:                    # noqa: BLE001
            messagebox.showerror("Dışa aktarma hatası", str(e))
            return
        self._ac(hedef)

    @staticmethod
    def _ac(yol: Path) -> None:
        try:
            import os
            os.startfile(str(yol))                # noqa: S606 (Windows)
        except Exception:
            try:
                subprocess.Popen(["explorer", "/select,", str(yol)])
            except Exception:
                pass
