# -*- coding: utf-8 -*-
"""Sartname karsilastirma / diff (Spesifikasyon BOLUM D).

Ayni kurumun sartnameleri ayni govdeden kopyalanir; FARK OLAN YER RISK OLAN
YERDIR. Iki sartname %95 ayni olup tuzak %5'te olabilir.

Hizalama madde NUMARASINA gore degil METIN BENZERLIGINE gore yapilir: bir
sartnamede bir madde eksikse sonraki tum maddeler bir kayar ve numara bazli
hizalama butun belgeyi "farkli" gosterir.
"""
from __future__ import annotations

import difflib
import re

from .model import Sartname

# Iki madde metninin "ayni madde" sayilmasi icin gereken en dusuk benzerlik.
# 0.60'in altinda farkli konular birbirine eslesmeye basliyor; 0.85 uzeri ise
# kucuk kelime degisikliklerinde ayni maddeyi iki ayri madde sayiyor.
ESLESME_ESIGI = 0.62

# "Metni farkli" sayilmasi icin gereken ust sinir: bunun uzerindekiler
# yalnizca bosluk/noktalama farkidir, rapora girmez.
AYNI_ESIGI = 0.995

SADECE_A = "SADECE A'DA VAR"
SADECE_B = "SADECE B'DE VAR"
FARKLI = "METNİ FARKLI"
AYNI = "AYNI"


def _sadelestir(metin: str) -> str:
    """Karsilastirma icin metni normalize eder (bosluk/noktalama gurultusu)."""
    return re.sub(r"[^\wçğıöşüÇĞİÖŞÜ]+", " ", metin or "").strip().lower()


def _benzerlik(a: str, b: str) -> float:
    return difflib.SequenceMatcher(None, _sadelestir(a), _sadelestir(b)).ratio()


def _kelime_farki(a: str, b: str) -> str:
    """Kelime bazli fark: [-cikan-] {+eklenen+} gosterimi."""
    ak, bk = (a or "").split(), (b or "").split()
    parcalar = []
    for etiket, i1, i2, j1, j2 in difflib.SequenceMatcher(
            None, ak, bk).get_opcodes():
        if etiket == "equal":
            parcalar.append(" ".join(ak[i1:i2]))
        elif etiket == "delete":
            parcalar.append(f"[-{' '.join(ak[i1:i2])}-]")
        elif etiket == "insert":
            parcalar.append(f"{{+{' '.join(bk[j1:j2])}+}}")
        else:
            parcalar.append(f"[-{' '.join(ak[i1:i2])}-]")
            parcalar.append(f"{{+{' '.join(bk[j1:j2])}+}}")
    return " ".join(p for p in parcalar if p)


def hizala(a: Sartname, b: Sartname) -> list[dict]:
    """Iki sartnamenin maddelerini metin benzerligine gore eslestirir.

    Once ayni numarali maddeler denenir (hizli ve dogru yol); metinleri
    birbirini tutmuyorsa eslesme bozulur ve o maddeler serbest havuzda
    en benzer karsiligini arar. Boylece numaralandirma kaymasi yakalanir.
    """
    a_maddeler = {m.numara: m for m in a.maddeler}
    b_maddeler = {m.numara: m for m in b.maddeler}
    eslesmis_b: set[str] = set()
    sonuc: list[dict] = []

    for numara, ma in a_maddeler.items():
        mb = b_maddeler.get(numara)
        if mb is not None and _benzerlik(ma.metin, mb.metin) >= ESLESME_ESIGI:
            eslesmis_b.add(numara)
            sonuc.append(_kayit(ma, mb, numara, numara))
            continue

        # Numara tutmadi -> metin benzerligiyle ara (numara kaymasi)
        en_iyi, en_oran = None, 0.0
        for b_no, aday in b_maddeler.items():
            if b_no in eslesmis_b:
                continue
            oran = _benzerlik(ma.metin, aday.metin)
            if oran > en_oran:
                en_iyi, en_oran = (b_no, aday), oran
        if en_iyi and en_oran >= ESLESME_ESIGI:
            b_no, aday = en_iyi
            eslesmis_b.add(b_no)
            sonuc.append(_kayit(ma, aday, numara, b_no))
        else:
            sonuc.append({
                "durum": SADECE_A, "a_madde": numara, "b_madde": None,
                "benzerlik": 0.0, "a_metin": ma.metin, "b_metin": "",
                "fark": "", "a_sayfa": ma.sayfa, "b_sayfa": None,
            })

    for numara, mb in b_maddeler.items():
        if numara in eslesmis_b:
            continue
        sonuc.append({
            "durum": SADECE_B, "a_madde": None, "b_madde": numara,
            "benzerlik": 0.0, "a_metin": "", "b_metin": mb.metin,
            "fark": "", "a_sayfa": None, "b_sayfa": mb.sayfa,
        })

    sonuc.sort(key=_sira_anahtari)
    return sonuc


def _kayit(ma, mb, a_no: str, b_no: str) -> dict:
    oran = _benzerlik(ma.metin, mb.metin)
    ayni = oran >= AYNI_ESIGI
    return {
        "durum": AYNI if ayni else FARKLI,
        "a_madde": a_no, "b_madde": b_no,
        "benzerlik": round(oran, 3),
        "a_metin": ma.metin, "b_metin": mb.metin,
        "fark": "" if ayni else _kelime_farki(ma.metin, mb.metin),
        "a_sayfa": ma.sayfa, "b_sayfa": mb.sayfa,
    }


def _sira_anahtari(kayit: dict):
    numara = kayit["a_madde"] or kayit["b_madde"] or "0"
    try:
        return [int(p) for p in numara.split(".")]
    except ValueError:
        return [999]


def farklar(a: Sartname, b: Sartname, ayni_dahil: bool = False) -> list[dict]:
    """Sadece anlamli farklari dondurur (varsayilan: ayni maddeler haric)."""
    tumu = hizala(a, b)
    return tumu if ayni_dahil else [k for k in tumu if k["durum"] != AYNI]


def ozet(a: Sartname, b: Sartname) -> dict:
    """Karsilastirmanin sayisal ozeti + yapisal farklar."""
    tumu = hizala(a, b)
    sayac = {AYNI: 0, FARKLI: 0, SADECE_A: 0, SADECE_B: 0}
    for k in tumu:
        sayac[k["durum"]] = sayac.get(k["durum"], 0) + 1

    kayma = [k for k in tumu
             if k["durum"] == FARKLI and k["a_madde"] != k["b_madde"]]
    return {
        "a": a.dosya_adi, "b": b.dosya_adi,
        "toplam_madde_a": len(a.maddeler),
        "toplam_madde_b": len(b.maddeler),
        "ayni": sayac[AYNI], "farkli": sayac[FARKLI],
        "sadece_a": sayac[SADECE_A], "sadece_b": sayac[SADECE_B],
        "benzerlik_yuzdesi": (round(100 * sayac[AYNI] / len(tumu), 1)
                              if tumu else 0.0),
        "numara_kaymasi": [(k["a_madde"], k["b_madde"]) for k in kayma],
        # Ek liste ve kunye sayisi da karsilastirilir: govde ayni olup ek
        # liste farkli olabilir, bu da fiyati dogrudan degistirir.
        "ek_kalem_a": len(a.ek_kalemler), "ek_kalem_b": len(b.ek_kalemler),
        "nitelik_a": a.nitelik_sayimi(), "nitelik_b": b.nitelik_sayimi(),
        "kunye_a": len([c for c in a.cihazlar if c.kunye]),
        "kunye_b": len([c for c in b.cihazlar if c.kunye]),
        "kapsam_a": a.kapsam.dahil_haric, "kapsam_b": b.kapsam.dahil_haric,
    }


def coklu_ozet(sartnameler: list[Sartname]) -> list[dict]:
    """Ikiden fazla dosya icin tum ikili karsilastirmalar."""
    cikti = []
    for i in range(len(sartnameler)):
        for j in range(i + 1, len(sartnameler)):
            cikti.append(ozet(sartnameler[i], sartnameler[j]))
    return cikti
